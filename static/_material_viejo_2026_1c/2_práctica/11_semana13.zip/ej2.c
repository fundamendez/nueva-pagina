#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define COLOR_AMARILLO "\033[1;33m"
#define COLOR_CIAN     "\033[1;36m"
#define COLOR_VERDE    "\033[1;32m"
#define COLOR_ROJO     "\033[1;31m"
#define COLOR_RESET    "\033[0m"


#define MAX_NOMBRE 100
#define MAX_USO    150

#define ARCHIVO_NUEVOS_INVENTOS "inventos_nuevos.csv"
#define ARCHIVO_INVENTOS_DENUNCIADOS "inventos_denunciados.csv"

#define FORMATO_HOMERO " %[^;];%[^\n]\n"
#define FORMATO_EXISTENTES "%[^;];%[^;];%i\n"
#define FORMATO_ESCRITURA "%s;%s\n"

const int CANTIDAD_ARGUMENTOS = 3;  
const int EXITO = 0;
const int ERROR_ARGUMENTOS = -1;
const int ERROR_ARCHIVO = -2;
const int ARGUMENTO_ARCHIVO_HOMERO = 1;
const int ARGUMENTO_ARCHIVO_EXISTENTES = 2;


typedef struct invento {
    char nombre[MAX_NOMBRE];
    char uso[MAX_USO];
} invento_t;



void mostrar_inventos(const char *ruta_homero, const char *ruta_existentes) {
    FILE *archivo_homero = fopen(ruta_homero, "r");
    FILE *archivo_existentes = fopen(ruta_existentes, "r");
    invento_t invento;

    if(!archivo_homero){
        printf("No se pudo abrir el archivo de Homero: %s\n", ruta_homero);
    }

    if(!archivo_existentes){
        fclose(archivo_homero); 
        printf("No se pudo abrir el archivo de inventos existentes: %s\n", ruta_existentes);
    }

    printf("=====================================================================\n");
    printf("%s🍩  INVENTOS DE HOMERO SIMPSON (Por patentar)  🍩%s\n", COLOR_AMARILLO, COLOR_RESET);
    printf("=====================================================================\n");


    int leidos_homero = fscanf(archivo_homero, FORMATO_HOMERO, invento.nombre, invento.uso);
    while (leidos_homero != EOF) {
        printf("  %s %-30s%s  %s\n", COLOR_AMARILLO, invento.nombre, COLOR_RESET, invento.uso);
        leidos_homero = fscanf(archivo_homero, FORMATO_HOMERO, invento.nombre, invento.uso);
    }
    fclose(archivo_homero);
    printf("\n");

    printf("=====================================================================\n");
    printf("%s📜  INVENTOS EXISTENTES EN LA HISTORIA  📜%s\n", COLOR_CIAN, COLOR_RESET);
    printf("=====================================================================\n");

  
    int anio;
    int leidos_existentes = fscanf(archivo_existentes, FORMATO_EXISTENTES, invento.nombre, invento.uso, &anio);
    while (leidos_existentes != EOF) {
        printf("  %s %-30s%s  %-70s [%s📅 %-4d%s]\n", 
                COLOR_CIAN, invento.nombre, COLOR_RESET, invento.uso, 
                COLOR_VERDE, anio, COLOR_RESET);
        leidos_existentes = fscanf(archivo_existentes, FORMATO_EXISTENTES, invento.nombre, invento.uso, &anio);
    }
    fclose(archivo_existentes);
    printf("=====================================================================\n");
}

void mostrar_resultados() {
    FILE *archivo_nuevos = fopen(ARCHIVO_NUEVOS_INVENTOS, "r");
    FILE *archivo_denuncias = fopen(ARCHIVO_INVENTOS_DENUNCIADOS, "r");
    invento_t invento;

    printf("=====================================================================\n");
    printf("%s🚀  INVENTOS REVOLUCIONARIOS DE HOMERO  🚀%s\n", COLOR_VERDE, COLOR_RESET);
    printf("=====================================================================\n");

    int leidos_nuevos = fscanf(archivo_nuevos, FORMATO_HOMERO, invento.nombre, invento.uso);
    while (leidos_nuevos != EOF) {
        printf("  %s %-30s%s %s\n", COLOR_VERDE, invento.nombre, COLOR_RESET, invento.uso);
        leidos_nuevos = fscanf(archivo_nuevos, FORMATO_HOMERO, invento.nombre, invento.uso);
    }
    fclose(archivo_nuevos);
    printf("\n");

    printf("=====================================================================\n");
    printf("%s🚨  INVENTOS CON DENUNCIA POR INTENTO DE PLAGIO  🚨%s\n", COLOR_ROJO, COLOR_RESET);
    printf("=====================================================================\n");

    int leidos_denuncias = fscanf(archivo_denuncias, FORMATO_HOMERO, invento.nombre, invento.uso);
    while (leidos_denuncias != EOF) {
        printf("  %s %-30s%s  %s\n", COLOR_ROJO, invento.nombre, COLOR_RESET, invento.uso);
        leidos_denuncias = fscanf(archivo_denuncias, FORMATO_HOMERO, invento.nombre, invento.uso);
    }
    fclose(archivo_denuncias);

    printf("=====================================================================\n");
}

/*
Pre: archivo_homero y archivo_existentes deben estar correctamente abiertos en formato lectura y además estar ordenados.
Post: Crea los archivos inventos_nuevos.csv con los inventos que son originales de Homero y inventos_denunciados.csv con los inventos que Homero está repitiendo. En caso de error al abrir los nuevos archivos devuelve -2.
*/
int procesar_archivos(FILE* archivo_homero, FILE* archivo_existentes){
    FILE* archivo_inventos_nuevos = fopen(ARCHIVO_NUEVOS_INVENTOS, "w");
    if(!archivo_inventos_nuevos){
        printf("Error al abrir el archivo de inventos nuevos");
        return ERROR_ARCHIVO;
    }
    FILE* archivo_inventos_denunciados = fopen(ARCHIVO_INVENTOS_DENUNCIADOS, "w");
    if(!archivo_inventos_denunciados){
        fclose(archivo_inventos_nuevos);
        printf("Error al abrir el archivo de inventos nuevos");
        return ERROR_ARCHIVO;
    }
    invento_t invento_homero;
    invento_t invento_existente;
    int anio;

    int leido_homero = fscanf(archivo_homero, FORMATO_HOMERO, invento_homero.nombre, invento_homero.uso);
    int leido_existentes = fscanf(archivo_existentes, FORMATO_EXISTENTES, invento_existente.nombre, invento_existente.uso, &anio);

    while(leido_homero != EOF && leido_existentes != EOF){
        if(strcmp(invento_homero.nombre, invento_existente.nombre) == 0){
            fprintf(archivo_inventos_denunciados, FORMATO_ESCRITURA, invento_homero.nombre, invento_homero.uso);
            leido_homero = fscanf(archivo_homero, FORMATO_HOMERO, invento_homero.nombre, invento_homero.uso);
            leido_existentes = fscanf(archivo_existentes, FORMATO_EXISTENTES, invento_existente.nombre, invento_existente.uso, &anio);
        }else if (strcmp(invento_homero.nombre, invento_existente.nombre) > 0){
            leido_existentes = fscanf(archivo_existentes, FORMATO_EXISTENTES, invento_existente.nombre, invento_existente.uso, &anio);
        }else{
            fprintf(archivo_inventos_nuevos, FORMATO_ESCRITURA, invento_homero.nombre, invento_homero.uso);
            leido_homero = fscanf(archivo_homero, FORMATO_HOMERO, invento_homero.nombre, invento_homero.uso);
        }
    }
    
    while(leido_homero != EOF){
        fprintf(archivo_inventos_nuevos, FORMATO_ESCRITURA, invento_homero.nombre, invento_homero.uso);
        leido_homero = fscanf(archivo_homero, FORMATO_HOMERO, invento_homero.nombre, invento_homero.uso);
    }

    fclose(archivo_inventos_denunciados);
    fclose(archivo_inventos_nuevos);
    return EXITO;
}


int main(int argc, char *argv[]) {
    
    if(argc != CANTIDAD_ARGUMENTOS){
        printf("Uso: ./ej2 <archivo_homero> <archivo_existentes>");
        return ERROR_ARGUMENTOS;
    }

    mostrar_inventos(argv[ARGUMENTO_ARCHIVO_HOMERO], argv[ARGUMENTO_ARCHIVO_EXISTENTES]);

    FILE* archivo_homero = fopen(argv[ARGUMENTO_ARCHIVO_HOMERO], "r");
    if(!archivo_homero){
        printf("Error al abrir archivo Homero");
        return ERROR_ARCHIVO;
    }
    FILE* archivo_existentes = fopen(argv[ARGUMENTO_ARCHIVO_EXISTENTES], "r");
    if(!archivo_existentes){
        fclose(archivo_homero);
        printf("Error al abrir archivo de inventos existentes");
        return ERROR_ARCHIVO;
    }

    if(procesar_archivos(archivo_homero, archivo_existentes) == ERROR_ARCHIVO){
        fclose(archivo_homero);
        fclose(archivo_existentes);
        return ERROR_ARCHIVO;
    } 

    mostrar_resultados();

    fclose(archivo_homero);
    fclose(archivo_existentes);
    
    return 0;
}