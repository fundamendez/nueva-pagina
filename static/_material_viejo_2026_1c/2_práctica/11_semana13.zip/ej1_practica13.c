#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

const char* CARTA_NUEVA = "carta_nueva.csv";
const char* CARTA_VIEJA = "carta_vieja.csv";
const char* CARTA_ACTUALIZADA = "carta_actualizada.csv";
const char* ESCRITURA = "w";
const char* LEER = "r";
#define FORMATO_LECTURA "%[^;];%i;%s\n" 
#define FORMATO_ESCRITURA "%s;%i;%s\n" 
#define MAX_NOMBRE 100

typedef struct Bebida {
    char nombre[MAX_NOMBRE];
    int cantidad;
    char es_alcoholica[MAX_NOMBRE];
}bebida_t;


void leer_e_imprimir_archivo(const char *nombre_archivo) {
    FILE *archivo = fopen(nombre_archivo, LEER);
    
    if (archivo == NULL) {
        printf("Error: No se pudo abrir el archivo '%s'\n", nombre_archivo);
        return;
    }

    struct Bebida bebida;
    size_t ancho_maximo = 25;

    printf("========================================================\n");
    printf("               BAR de MOE - %s\n", nombre_archivo);
    printf("========================================================\n");
    printf("%-28s | %-10s | %-10s\n", "Bebida", "Cantidad", "¿Alcohol?");
    printf("--------------------------------------------------------\n");

    while (fscanf(archivo, FORMATO_LECTURA , bebida.nombre, &bebida.cantidad, bebida.es_alcoholica) != EOF) {
        const char *emoji = (strcmp(bebida.es_alcoholica, "Si") == 0) ? "🍹" : "🥤";
    
        size_t largo_nombre = strlen(bebida.nombre);
        size_t espacios_relleno = ancho_maximo - largo_nombre;
        if (espacios_relleno < 1) espacios_relleno = 1; 
        printf("%s", bebida.nombre);
        for (int i = 0; i < espacios_relleno; i++) {
            printf(" ");
        }
        printf("%s | %4d ml   | %-10s\n", emoji, bebida.cantidad, bebida.es_alcoholica);
    }

    printf("========================================================\n\n");
    
    fclose(archivo);
}

void imprimir_carta_vieja() {
    leer_e_imprimir_archivo(CARTA_VIEJA);
}

void imprimir_carta_nueva() {
    leer_e_imprimir_archivo(CARTA_NUEVA);
}

void imprimir_carta_actualizada() {
    leer_e_imprimir_archivo(CARTA_ACTUALIZADA);
}

void escribir_en_carta(FILE* carta_actualizada, bebida_t bebida){
    fprintf(carta_actualizada, FORMATO_ESCRITURA, bebida.nombre, bebida.cantidad, bebida.es_alcoholica);
}

//Pre: Los archivos estan abiertos en el formato esperado (r). Carta vieja y carta nueva tienen que estar ordenados alfabeticamente.
//Post: Devuelve la union de los archivos carta vieja y carta nueva escrita dentro de carta actualizada con el formato esperado.
void unificar_cartas(FILE* carta_vieja, FILE* carta_nueva, FILE* carta_actualizada){
    bebida_t bebida_nueva;
    bebida_t bebida_vieja;
    int leido_nueva = 0;
    int leido_vieja = 0;

    leido_nueva = fscanf(carta_nueva, FORMATO_LECTURA, bebida_nueva.nombre, &bebida_nueva.cantidad, bebida_nueva.es_alcoholica);
    leido_vieja = fscanf(carta_vieja, FORMATO_LECTURA, bebida_vieja.nombre, &bebida_vieja.cantidad, bebida_vieja.es_alcoholica);

    while (leido_nueva != EOF && leido_vieja != EOF){
        if(strcmp(bebida_nueva.nombre, bebida_vieja.nombre) == 0){
            escribir_en_carta(carta_actualizada, bebida_nueva);

            leido_nueva = fscanf(carta_nueva, FORMATO_LECTURA, bebida_nueva.nombre, &bebida_nueva.cantidad, bebida_nueva.es_alcoholica);
            leido_vieja = fscanf(carta_vieja, FORMATO_LECTURA, bebida_vieja.nombre, &bebida_vieja.cantidad, bebida_vieja.es_alcoholica);
        }
        else if(strcmp(bebida_nueva.nombre, bebida_vieja.nombre) > 0){
            escribir_en_carta(carta_actualizada, bebida_vieja);

            leido_vieja = fscanf(carta_vieja, FORMATO_LECTURA, bebida_vieja.nombre, &bebida_vieja.cantidad, bebida_vieja.es_alcoholica);            
        }
        else{
            escribir_en_carta(carta_actualizada, bebida_nueva);

            leido_nueva = fscanf(carta_nueva, FORMATO_LECTURA, bebida_nueva.nombre, &bebida_nueva.cantidad, bebida_nueva.es_alcoholica);            
        }
    }
    
    while (leido_nueva != EOF){
        escribir_en_carta(carta_actualizada, bebida_nueva);

        leido_nueva = fscanf(carta_nueva, FORMATO_LECTURA, bebida_nueva.nombre, &bebida_nueva.cantidad, bebida_nueva.es_alcoholica); 
    }

    while (leido_vieja != EOF){
        escribir_en_carta(carta_actualizada, bebida_vieja);

        leido_vieja = fscanf(carta_vieja, FORMATO_LECTURA, bebida_vieja.nombre, &bebida_vieja.cantidad, bebida_vieja.es_alcoholica);         
    }
    
}



int main(int argc, char *argv[]) {
    imprimir_carta_vieja();
    imprimir_carta_nueva();

    FILE* carta_vieja = fopen(CARTA_VIEJA, LEER);
    if(!carta_vieja){
        printf("No se pudo abrir el archivo de la carta vieja");
        return -1;
    }

    FILE* carta_nueva = fopen(CARTA_NUEVA, LEER);
    if(!carta_nueva){
        fclose(carta_vieja);
        printf("No se pudo abrir el archivo de la carta nueva");
        return -1; 
    }

    FILE* carta_actualizada = fopen(CARTA_ACTUALIZADA, ESCRITURA);
    if(!carta_actualizada){
        fclose(carta_nueva);
        fclose(carta_vieja);
        printf("No se pudo crear el archivo de la carta actualizada");
        return -1; 
    }

    unificar_cartas(carta_vieja, carta_nueva, carta_actualizada);
    fclose(carta_actualizada);

    imprimir_carta_actualizada();
    fclose(carta_vieja);
    fclose(carta_nueva);
    return 0;
}