#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX_ARCH 50
#define MAX_SABOR 50
#define MAX_DONAS 10
#define MAX_NOMBRE 50
#define FORMATO_ESCRITURA_RANKING "%s;%i\n"
#define NOMBRE_RANKING_AUX "ranking_aux.csv"
#define FORMATO_LECTURA_RANKING "%[^;];%i\n"
#define FORMATO_LECTURA_CIUDADANOS "%[^;];%[^\n]\n"
const int ERROR = -1;
const int EXITO = 0;

typedef struct dona{
    char sabor[MAX_SABOR];
    int cantidad;
} dona_t;

// pre: el tope debe ser consecuente con la cantidad de elementos en el vector, sabor tiene que ser un string (terminar en \0).
// post: busca en el vector el sabor recibido y le suma uno a la cantidad.
void procesar_sabor(dona_t donas_ranking[MAX_DONAS], int tope, char sabor[MAX_SABOR]){
    bool encontrado = false;
    int i = 0;
    while(i < tope && !encontrado){
        if(strcmp(donas_ranking[i].sabor, sabor) == 0){
            encontrado = true;
            donas_ranking[i].cantidad++;
        }
        i++;
    }
}

// pre: el tope debe ser consecuente con la cantidad de elementos en el vector.
// post: ordena donas_ranking de manera descendente.
void ordenar_ranking(dona_t donas_ranking[MAX_DONAS], int tope){
    dona_t aux;
    for(int i = 0; i < tope - 1; i++){
        for(int j = 0; j < tope - 1 - i; j++){
            if(donas_ranking[j].cantidad < donas_ranking[j+1].cantidad){
                aux = donas_ranking[j];
                donas_ranking[j] = donas_ranking[j+1];
                donas_ranking[j+1] = aux;
            }
        }
    }
}

// pre: el archivo ranking_aux debe estar abierto en formato escritura. El tope debe ser consecuente con la cantidad de elementos en el vector.
// post: escribe en ranking_aux la información que está en donas_ranking.
void escribir_ranking(dona_t donas_ranking[MAX_DONAS], int tope, FILE* ranking_aux){
    for(int i = 0; i < tope; i++){
        fprintf(ranking_aux, FORMATO_ESCRITURA_RANKING, donas_ranking[i].sabor, donas_ranking[i].cantidad);
    }
}

// pre: -
// post: lee el archivo de ciudadanos y actualiza el archivo de ranking dependiendo de los sabores que eligió cada ciudadano. El archivo de ranking queda ordenado por cantidad de mayor a menor. Devuelve ERROR si hay un error en la apertura de los archivos, EXITO en caso contrario.
int actualizar_ranking(char nombre_arch_ranking[MAX_ARCH], char nombre_arch_ciudadanos[MAX_ARCH]){
    FILE* arch_ranking = fopen(nombre_arch_ranking, "r");
    if(!arch_ranking){
        printf("Hubo un error al abrir el archivo de ranking");
        return ERROR;
    }

    FILE* arch_ciudadanos = fopen(nombre_arch_ciudadanos, "r");
    if(!arch_ciudadanos){
        printf("Hubo un error al abrir el archivo de ciudadanos");
        fclose(arch_ranking);
        return ERROR;
    }

    dona_t donas_ranking[MAX_DONAS];
    int tope = 0;
    int leido_ranking = fscanf(arch_ranking, FORMATO_LECTURA_RANKING, donas_ranking[tope].sabor, &donas_ranking[tope].cantidad);
    
    while(leido_ranking != EOF){
        tope++;
        leido_ranking = fscanf(arch_ranking, FORMATO_LECTURA_RANKING, donas_ranking[tope].sabor, &donas_ranking[tope].cantidad);
    }

    char nombre[MAX_NOMBRE];
    char sabor[MAX_SABOR];
    int leido_ciudadanos = fscanf(arch_ciudadanos, FORMATO_LECTURA_CIUDADANOS, nombre, sabor);
    while(leido_ciudadanos != EOF){
        procesar_sabor(donas_ranking, tope, sabor);
        leido_ciudadanos = fscanf(arch_ciudadanos, FORMATO_LECTURA_CIUDADANOS, nombre, sabor);
    }

    FILE* ranking_aux = fopen(NOMBRE_RANKING_AUX, "w");
    if(!ranking_aux){
        printf("Hubo un error al abrir el archivo aux");
        fclose(arch_ciudadanos);
        fclose(arch_ranking);
        return ERROR;
    }
    ordenar_ranking(donas_ranking, tope);
    escribir_ranking(donas_ranking, tope, ranking_aux);

    fclose(arch_ciudadanos);
    fclose(arch_ranking);
    fclose(ranking_aux);

    rename(NOMBRE_RANKING_AUX, nombre_arch_ranking);
    return EXITO;
}

int main(){
    actualizar_ranking("ranking.csv", "ciudadanos.csv");
    return 0;
}


