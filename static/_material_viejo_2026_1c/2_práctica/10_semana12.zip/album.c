#include "album.h"

#include <stdio.h>
#include <stdlib.h>
#include <time.h>


album_t* album_crear() {

    album_t* album = malloc(sizeof(album_t));

    if (!album) return NULL;

    album->figuritas = NULL;
    album->cantidad_figuritas = 0;

    srand((unsigned)time(NULL));

    return album;
}


bool agregar_figurita(album_t* album, figurita_t figurita) {

    if (!album) return false;

    figurita_t* nuevas = realloc(
        album->figuritas,
        (album->cantidad_figuritas + 1) * sizeof(figurita_t)
    );

    if (!nuevas) return false;

    album->figuritas = nuevas;

    album->figuritas[album->cantidad_figuritas] = figurita;

    album->cantidad_figuritas++;

    return true;
}


bool obtener_figurita(album_t* album, int numero, figurita_t* figurita) {

    if (!album) return false;

    bool encontrada = false;

    for (int i = 0; i < album->cantidad_figuritas && !encontrada; i++) {
        if (album->figuritas[i].numero == numero) {
            if (figurita) *figurita = album->figuritas[i];
            encontrada = true;
        }
    }

    return encontrada;
}



int cantidad_figuritas(album_t* album) {

    if (!album) return 0;

    return album->cantidad_figuritas;
}


bool quitar_figurita(album_t* album, figurita_t* figurita) {

    if (!album || album->cantidad_figuritas == 0) return false;

    int ultima = album->cantidad_figuritas - 1;

    if (figurita) *figurita = album->figuritas[ultima];

    album->cantidad_figuritas--;

    if (album->cantidad_figuritas == 0) {
        free(album->figuritas);
        album->figuritas = NULL;
        return true;
    }

    figurita_t* nuevas = realloc(
        album->figuritas,
        album->cantidad_figuritas * sizeof(figurita_t)
    );

    if (nuevas) album->figuritas = nuevas;

    return true;
}


void album_destruir(album_t* album) {

    if (!album) return;

    free(album->figuritas);

    free(album);
}