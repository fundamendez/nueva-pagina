#ifndef ALBUM_FIGURITAS_H
#define ALBUM_FIGURITAS_H

#include <stdbool.h>

#define MAX_NOMBRE 100
#define MAX_EQUIPO 100


typedef struct figurita {
    int numero;
    char nombre_jugador[MAX_NOMBRE];
    char equipo[MAX_EQUIPO];
} figurita_t;


typedef struct album {
    figurita_t* figuritas;
    int cantidad_figuritas;
} album_t;


/*
Post: Crea un álbum vacío.
      Devuelve un puntero al álbum o NULL en caso de error.
*/
album_t* album_crear();


/*
Pre: `album` fue creado usando album_crear().
Post: Agrega una figurita al álbum.
      Devuelve true si se pudo agregar,
      false en caso contrario.
*/
bool agregar_figurita(album_t* album, figurita_t figurita);


/*
Pre: `album` fue creado usando album_crear().
Post: Busca en el álbum la figurita con el `numero` indicado.
      Si `figurita` no es NULL y existe, guarda en él una copia.
      Devuelve true si la figurita está en el album, false en caso contrario.
*/
bool obtener_figurita(album_t* album, int numero, figurita_t* figurita);


/*
Pre: `album` fue creado usando album_crear().
Post: Elimina del álbum la última figurita agregada y, si
      `figurita` no es NULL, guarda en él una copia de la figurita quitada.
      Devuelve true si se eliminó, false si el álbum está vacío o hubo error.
*/
bool quitar_figurita(album_t* album, figurita_t* figurita);


/*
Pre: `album` fue creado usando album_crear().
Post: Destruye el álbum y libera toda la memoria utilizada.
*/
void album_destruir(album_t* album);


#endif