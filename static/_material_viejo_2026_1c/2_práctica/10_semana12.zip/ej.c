#include "album.h"
#include "sobre.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define ARCH_REPES "repes_bart.csv"
#define LECTURA "r"
#define ESCRITURA "w"
#define FORMATO_LECTURA_FIGUS "%i;%[^;];%[^\n]\n"
#define FORMATO_LECTURA_SOBRES  "%i;%c\n"
#define FORMATO_ESCRITURA_FIGUS "%i;%s;%s\n"


const int CANT_ARGS_MIN = 2;
const int CANT_ARGS_MAX = 3;
const int ERROR_ARGS = 4;
const int ERROR_APERTURA = 3; 
const int ERROR = -1;
const int POS_RUTA_FIGUS = 1;
const int POS_RUTA_SOBRES = 2;

const int EXITO = 0;
const char CERRADO = 'C';

// Pre: recibe el album creado correctamente con album_crear()
// Post: guarda las figuritas del archivo recibido en el álbum. Devuelve ERROR_APERTURA en caso de error y EXITO en caso contrario.
int guardar_figuritas_en_album(char* archivo_figus_bart, album_t* album){
    FILE * arch_figuritas_bart = fopen(archivo_figus_bart, LECTURA);
    if(!arch_figuritas_bart){
        printf("Error abriendo el archivo de figus de Bart\n");
        return ERROR_APERTURA;
    }

    figurita_t figurita;
    int leidos = fscanf(arch_figuritas_bart, FORMATO_LECTURA_FIGUS, &figurita.numero, figurita.nombre_jugador, figurita.equipo);
    bool se_guardo =  true;
    
    while(leidos != EOF && se_guardo){
        se_guardo = agregar_figurita(album, figurita);
        
        leidos = fscanf(arch_figuritas_bart, FORMATO_LECTURA_FIGUS, &figurita.numero, figurita.nombre_jugador, figurita.equipo);
    }

    fclose(arch_figuritas_bart);
    return EXITO;
}

// Pre: recibe un album inicializado con album_crear y la cantidad de figuritas coincide correctamente con la cantidad de figuritas del vector de sobre. El archivo fue abierto correctamente para escritura.
// Post: guarda las figus del sobre en el album si no están repetidas o las escribe en el archivo recibido si lo están.
void guardar_figuritas_de_sobre(sobre_t sobre, album_t* album, FILE* archivo_repetidas){
    for(int i = 0; i < sobre.cantidad_figuritas; i++){
        figurita_t figu = {};
        if(!obtener_figurita(album, sobre.figuritas[i].numero, &figu)){
            agregar_figurita(album, sobre.figuritas[i]);
        } 
        else {
            fprintf(archivo_repetidas, FORMATO_ESCRITURA_FIGUS, figu.numero, figu.nombre_jugador, figu.equipo);
        }
    }
}


// Pre: el album está creado correctamente con album_crear()
// Post: abre los sobres y guarda las figuritas que no estén repetidas en el álbum y aquellas que sí estén repetidas las guarda en el archivo ARCH_REPES. Devuelve ERROR_APERTURA si no se pueden abrir alguno de los archivos, y EXITO en caso contrario.
int guardar_sobres_en_album(album_t* album, char* nombre_arch_sobres){
    FILE * arch_sobres = fopen(nombre_arch_sobres, LECTURA);
    if(!arch_sobres){
        printf("Error abriendo el archivo de sobres de la tia Selma\n");
        return ERROR_APERTURA;
    }

    FILE * arch_figus_repe = fopen(ARCH_REPES, ESCRITURA);
    if(!arch_figus_repe){
        printf("Error abriendo el archivo de figuritas repetidas\n");
        fclose(arch_sobres);
        return ERROR_APERTURA;
    }

    char estado;
    int cant_figus;
    int leidos = fscanf(arch_sobres, FORMATO_LECTURA_SOBRES, &cant_figus, &estado);


    while(leidos != EOF){
        if(estado == CERRADO && cant_figus > 0){
            sobre_t sobre;
            sobre.abierto = false;
            sobre.cantidad_figuritas = cant_figus;
            if(abrir_sobre(&sobre)){
                guardar_figuritas_de_sobre(sobre, album, arch_figus_repe);
                free(sobre.figuritas);
            }
        }

        leidos = fscanf(arch_sobres, FORMATO_LECTURA_SOBRES, &cant_figus, &estado);
    }

    fclose(arch_figus_repe);
    fclose(arch_sobres);
    return EXITO;
}


int guardar_figus_en_archivo(album_t* album, char* archivo_figus_bart){
    FILE * arch_figuritas_bart = fopen(archivo_figus_bart, ESCRITURA);
    if(!arch_figuritas_bart){
        printf("Error abriendo el archivo de figus de Bart\n");
        return ERROR_APERTURA;
    }

    figurita_t figu;
    while(quitar_figurita(album, &figu)){
        fprintf(arch_figuritas_bart, FORMATO_ESCRITURA_FIGUS, figu.numero, figu.nombre_jugador, figu.equipo);
    }

    fclose(arch_figuritas_bart);
    return EXITO;
}


int quitar_figus_equipo(album_t** album, char* equipo_a_eliminar){
    album_t* album_aux = album_crear();
    if(!album_aux){
        printf("No se pudo crear el album auxiliar para quitar las figus del equipo\n");
        return ERROR;
    }

    figurita_t figu;
    bool se_pudo_guardar = true;
    while(quitar_figurita(*album, &figu) && se_pudo_guardar){
        if(strcmp(figu.equipo, equipo_a_eliminar) != 0){
            se_pudo_guardar = agregar_figurita(album_aux, figu);
        }
    }

    album_destruir(*album);
    *album = album_aux;

    return EXITO;
}


album_t* quitar_figus_equipo(album_t* album, char* equipo_a_eliminar){
    album_t* album_aux = album_crear();
    if(!album_aux){
        printf("No se pudo crear el album auxiliar para quitar las figus del equipo\n");
        return NULL;
    }

    figurita_t figu;
    bool se_pudo_guardar = true;
    while(quitar_figurita(album, &figu) && se_pudo_guardar){
        if(strcmp(figu.equipo, equipo_a_eliminar) != 0){
            se_pudo_guardar = agregar_figurita(album_aux, figu);
        }
    }

    album_destruir(album);

    return album_aux;
}


int main(int argc, char* argv[]) {
    if (argc < CANT_ARGS_MIN) {
        printf("Se debe ingresar el nombre del archivo de figuritas de Bart ./ejecutable <nombre_archivo>\n");
        return ERROR_ARGS;
    }

    album_t* album_bart = album_crear();
    if(!album_bart){
        printf("Hubo un error creando el TDA del album de Bart\n");
        return ERROR;
    }

    int resultado_guardar = guardar_figuritas_en_album(argv[POS_RUTA_FIGUS], album_bart);
    if(resultado_guardar != EXITO){
        album_destruir(album_bart);
        return ERROR;
    }

    if(argc == CANT_ARGS_MAX) {
        int resultado_sobres = guardar_sobres_en_album(album_bart, argv[POS_RUTA_SOBRES]);
        if (resultado_sobres != EXITO) {
            printf("No se pudieron guardar las figus de los sobres de la tia Selma D: \n");
        }
    }
    
    quitar_figus_equipo(album_bart, "Canada");
    
    guardar_figus_en_archivo(album_bart, argv[POS_RUTA_FIGUS]);
    album_destruir(album_bart);

    return 0;
}
