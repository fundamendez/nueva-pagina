#ifndef SOBRE_H
#define SOBRE_H

#include <stdbool.h>
#include "album.h"

typedef struct sobre {
    figurita_t* figuritas;
    int cantidad_figuritas;
    bool abierto;
} sobre_t;

/*
Pre: `sobre` fue inicializado con `cantidad_figuritas` > 0 y `abierto` en false.
Post: Abre el sobre y carga en el vector `figuritas` una cantidad de figuritas
      igual a la indicada en `cantidad_figuritas`.

      Las figuritas se obtienen aleatoriamente desde un archivo
      csv interno.

      El sobre debe estar cerrado para poder abrirse.

      Devuelve true si se pudieron cargar las figuritas,
      false en caso contrario.

      Se debe liberar la memoria de las figuritas usando free.
*/
bool abrir_sobre(sobre_t* sobre);


#endif
