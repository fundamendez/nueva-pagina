#include "sobre.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define RUTA_FIGURITAS "figuritas.csv"

typedef struct jugador_csv {
    int numero;
    char nombre[MAX_NOMBRE];
    char equipo[MAX_EQUIPO];
} jugador_csv_t;


/*
Pre: `archivo` está abierto correctamente.
Post: Lee un jugador del csv.
      Devuelve true si pudo leerlo, false en caso contrario.
*/
bool leer_jugador(FILE* archivo, jugador_csv_t* jugador) {

    int leidos = fscanf(
        archivo,
        "%d;%99[^;];%99[^\n]\n",
        &jugador->numero,
        jugador->nombre,
        jugador->equipo
    );

    return leidos == 3;
}

/*
Pre: -
Post: Devuelve un jugador aleatorio del csv.
*/
jugador_csv_t obtener_jugador_random() {

    FILE* archivo = fopen(RUTA_FIGURITAS, "r");

    jugador_csv_t jugador;
    jugador.numero = -1;

    if (!archivo) return jugador;

    int cantidad_jugadores = 0;

    jugador_csv_t auxiliar;

    fscanf(archivo, "%*[^\n]\n");

    while (leer_jugador(archivo, &auxiliar)) {
        cantidad_jugadores++;
    }

    if (cantidad_jugadores == 0) {
        fclose(archivo);
        return jugador;
    }

    int posicion_random = rand() % cantidad_jugadores;

    rewind(archivo);

    fscanf(archivo, "%*[^\n]\n");

    for (int i = 0; i <= posicion_random; i++) {
        leer_jugador(archivo, &jugador);
    }

    fclose(archivo);

    return jugador;
}

bool abrir_sobre(sobre_t* sobre) {

    if (!sobre) return false;

    if (sobre->abierto) return false;

    if (sobre->cantidad_figuritas <= 0) return false;

    figurita_t* figuritas = malloc((size_t)sobre->cantidad_figuritas * sizeof(figurita_t));

    if (!figuritas) return false;

    for (int i = 0; i < sobre->cantidad_figuritas; i++) {

        jugador_csv_t jugador = obtener_jugador_random();

        if (jugador.numero == -1) {
            free(figuritas);
            return false;
        }

        figuritas[i].numero = jugador.numero;
        strcpy(figuritas[i].nombre_jugador, jugador.nombre);
        strcpy(figuritas[i].equipo, jugador.equipo);
    }

    sobre->figuritas = figuritas;
    sobre->abierto = true;

    return true;
}