#include <stdio.h>
#include <string.h>
#define MAX 9

int main() {
    char mascotas[MAX];
    strcpy(mascotas, "Ayud");
    strcat(mascotas, "ante");

    int edades[3] = {10, 1, 8};
    int* edad_santa = edades; // apunta a pos 0 (que es 10)
    int* edad_ayudante = edades + 3; // posicion 3 (mem inválida)

    printf("%i", (int)strlen(mascotas) + *edad_santa + *edad_ayudante); // 8 + 10 + 8
}

// edades + 1 es &(edades[1])
// *(edades + 1) es edades[1]