#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX_NOMBRE 100

typedef struct premio {
    char nombre[MAX_NOMBRE];
    int  anio;
} premio_t;

typedef struct episodio {
    char      titulo[MAX_NOMBRE];
    premio_t* premios;
    int       cantidad_premios;
} episodio_t;

const int ERROR = -1;
const int EXITO = 0;

void ingresar_premio(premio_t* p) {
    printf("Nombre del premio: ");
    scanf(" %99[^\n]", p->nombre);
    printf("Año: ");
    scanf("%d", &p->anio);
}

void pedir_episodio(episodio_t* e){
    printf("Titulo del episodio: ");
    scanf(" %99[^\n]", e->titulo);

    printf("Cantidad de premios: ");
    scanf("%d", &e->cantidad_premios);
}

void imprimir_conjunto(episodio_t* episodios, int cantidad_episodios) {
    printf("\n--- Episodios registrados (%d) ---\n", cantidad_episodios);
    for (int i = 0; i < cantidad_episodios; i++) {
        printf("[%d] %s (%d premios)\n", i + 1, episodios[i].titulo, episodios[i].cantidad_premios);
        for (int j = 0; j < episodios[i].cantidad_premios; j++) {
            printf("     - %s (%d)\n", episodios[i].premios[j].nombre, episodios[i].premios[j].anio);
        }
    }
    printf("\n");
}

void eliminar_episodios(episodio_t* conjunto_episodios, int cantidad_episodios){
    //free(conjunto_episodios); // NO! pierdo la referencia de los premios
    for(int i=0; i<cantidad_episodios; i++){
        free(conjunto_episodios[i].premios);
    }
    free(conjunto_episodios);
}

int inicializar_episodio(episodio_t* episodio){
    pedir_episodio(episodio);

    premio_t* premios = malloc(sizeof(premio_t)*(episodio->cantidad_premios));
    if(!premios){
        printf("No se pudo reservar memoria para los premios\n");
        return ERROR;
    }

    for(int i = 0; i<episodio->cantidad_premios; i++){
        ingresar_premio(premios + i); // es como hacer &premios[i]
    }

    return EXITO;
}

episodio_t* inicializar_conjunto_episodios(int* tope_episodios, int cantidad_episodios){
    episodio_t* episodios = malloc(sizeof(episodio_t)*cantidad_episodios);
    if(!episodios){
        printf("Hubo un error al reservar memoria para los episodios\n");
        return NULL;
    }

    int i = 0;
    bool hubo_error = false;
    while(i < cantidad_episodios && !hubo_error){
        int resultado = inicializar_episodio(episodios + i);
        if(resultado == ERROR){
            hubo_error = true;
        }
        (*tope_episodios)++;
        i++;
    }

    if(hubo_error){
        eliminar_episodios(episodios, *tope_episodios);
        return NULL;
    }

    return episodios;
}

int main(){

    return 0;
}