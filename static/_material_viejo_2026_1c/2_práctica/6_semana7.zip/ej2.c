#include <stdio.h>
#include <stdlib.h>

#define MAX_TITULO 100

const int ERROR = -1;

typedef struct historieta{
    char titulo[MAX_TITULO];
    int numero_edicion;
} historieta_t;


// pre: -
// post: carga el nombre de la historieta con lo que ingresa el usuario
void preguntar_titulo_historieta(char *titulo_historieta){
    printf("Ingrese el titulo de la historieta: ");
    scanf("%s", titulo_historieta);
}

// pre: -
// post: carga el numero de edicion con lo que ingresa el usuario
void preguntar_numero_edicion(int *numero_edicion){
    printf("Ingrese el numero de edición: ");
    scanf("%i", numero_edicion);
}

void preguntar_cantidad_historietas(int *cantidad_historietas){
    printf("Hola señor cuántas historietas vas a cargar: ");
    scanf("%i", cantidad_historietas);
    while(*cantidad_historietas <= 0){
        printf("Ingrese una cantidad válida: ");
        scanf("%i", cantidad_historietas);
    }
}

// PRE: La cantidad de historietas debe ser > 0
// POST: Reserva memoria para la cantidad de historietas recibida por parametro, inicializa las historietas y devuelve el puntero. En caso de error devuelve null

historieta_t* inicializar_caja_historietas(int cant_historietas){
    historieta_t* caja_historietas = malloc(sizeof(historieta_t) * cant_historietas);
    if(!caja_historietas){
        printf("No se pudo reservar el espacio de memoria para la caja de historietas.\n");
        return NULL;
    }

    for (int i = 0; i < cant_historietas; i++){
        preguntar_numero_edicion(&caja_historietas[i].numero_edicion);
        preguntar_titulo_historieta(caja_historietas[i].titulo);
    }

    return caja_historietas;
}

historieta_t* agregar_historieta_extra(historieta_t* caja_historietas, int* cant_historietas, historieta_t historieta_extra){
    historieta_t* caja_agrandada = realloc(caja_historietas, (sizeof(historieta_t)* (*cant_historietas+1)));
    if(!caja_agrandada){
        printf("No se pudo reservar el espacio de memoria para la caja de historietas.\n");
        return NULL;
    }

    caja_agrandada[(*cant_historietas)+1] = historieta_extra; //== *(caja_agrandada + (*cant_historietas + 1)) = historieta_extra

    (*cant_historietas)++;

    return caja_agrandada;
}

int main(){

    int cant_historietas = -1;
    preguntar_cantidad_historietas(&cant_historietas);
    historieta_t* caja_historietas = inicializar_caja_historietas(cant_historietas);
    if(!caja_historietas) return ERROR;
    
    historieta_t historieta_extra;
    caja_historietas = agregar_historieta_extra(caja_historietas, &cant_historietas, historieta_extra);
    if(!caja_historietas) return ERROR;

    free(caja_historietas);


    return 0;
}