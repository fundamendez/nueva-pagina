#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define RESET   "\x1b[0m"
#define CELESTE    "\x1b[36m"
#define AMARILLO  "\x1b[33m"
#define VERDE   "\x1b[32m"
#define ROJO     "\x1b[31m"
#define ROSA "\x1b[35m"
#define BOLD    "\x1b[1m"
#define MAX_NOMBRE 50
#define MAX_CATEGORIA 100
#define ARCHIVO_AUX "proyectos_aux.csv"
#define ARCHIVO_PROYECTOS "proyectos.csv"
#define FORMATO_LECTURA "%[^;];%[^;];%c;%i\n"
#define FORMATO_ESCRITURA "%s;%s;%c;%i\n"
#define CANT_CATEGORIAS 4
#define ARCHIVO_CATEGORIAS "categorias_proyectos.txt"
#define FORMATO_ESCRITURA_CATEGORIAS "%s: %i\n"

const int ERROR = -1;
const int EXITO = 0;
const char NO_FUNCIONA = 'N';
const int ANIO_ACTUAL = 2026;
const int ANIO_MINIMO = 5;
const char CATEGORIAS[CANT_CATEGORIAS][MAX_CATEGORIA] = {"robotica", "quimica", "astronomia", "ecologia"};

typedef struct proyecto{
    char nombre[MAX_NOMBRE];
    char categoria[MAX_CATEGORIA];
    char funciona;
    int anio;
} proyecto_t;

bool es_descartable(proyecto_t proyecto){
    return (proyecto.funciona == NO_FUNCIONA && ANIO_ACTUAL - proyecto.anio > ANIO_MINIMO);
}

void contar_categorias(int contador_categorias[CANT_CATEGORIAS], char categoria[MAX_CATEGORIA]){
    for(int i = 0; i < CANT_CATEGORIAS; i++){
        if(strcmp(categoria, CATEGORIAS[i]) == 0){
            contador_categorias[i]++;
        }
    }
}

int escribir_arch_categorias(int contador[CANT_CATEGORIAS]){
    FILE* arch_categorias = fopen(ARCHIVO_CATEGORIAS, "w");
    if(!arch_categorias){
        printf("no se pudo abrir el archivo de categorias\n");
        return ERROR;
    }

    for(int i = 0; i < CANT_CATEGORIAS; i++){
        fprintf(arch_categorias, FORMATO_ESCRITURA_CATEGORIAS, CATEGORIAS[i], contador[i]);
    }

    fclose(arch_categorias);
    return EXITO;
}

int procesar_archivo(FILE* proyectos, FILE* aux){
    proyecto_t proyecto_leido;
    int contador_categorias[CANT_CATEGORIAS] = {0, 0, 0, 0};
    
    int leidos = fscanf(proyectos, FORMATO_LECTURA, proyecto_leido.nombre, proyecto_leido.categoria, &proyecto_leido.funciona, &proyecto_leido.anio);
    while(leidos != EOF){
        if(!es_descartable(proyecto_leido)){
            if(proyecto_leido.funciona != NO_FUNCIONA){
                contar_categorias(contador_categorias, proyecto_leido.categoria);
            }
            fprintf(aux, FORMATO_ESCRITURA, proyecto_leido.nombre, proyecto_leido.categoria, proyecto_leido.funciona, proyecto_leido.anio);
        }
        leidos = fscanf(proyectos, FORMATO_LECTURA, proyecto_leido.nombre, proyecto_leido.categoria, &proyecto_leido.funciona, &proyecto_leido.anio);
    }

    if(escribir_arch_categorias(contador_categorias) == ERROR){
        return ERROR;
    }
    return EXITO;
}

int mostrar_inventario_proyectos(const char *nombre_archivo, const char *titulo) {
    FILE *archivo = fopen(nombre_archivo, "r");
    if (!archivo) {
        printf(ROJO "\n❌ No se pudo abrir el archivo %s.\n" RESET, nombre_archivo);
        return 0;
    }

    printf("\n" CELESTE "=======================================================================" RESET "\n");
    printf(BOLD AMARILLO "  %s " RESET "\n", titulo);
    printf(CELESTE "=======================================================================" RESET "\n");
    printf(BOLD "%-33s | %-15s | %-4s | %-5s\n" RESET, "PROYECTO", "CATEGORÍA", "EST.", "AÑO");
    printf("----------------------------------+----------------+------+--------\n");

    proyecto_t proyecto;
    int total_proyectos = 0;

    while (fscanf(archivo, " %[^;];%[^;];%c;%d", proyecto.nombre, proyecto.categoria, &proyecto.funciona, &proyecto.anio) != EOF) {
        char emoji[5] = "📦"; 
        if (strcmp(proyecto.categoria, "robotica") == 0) strcpy(emoji, "🤖");
        else if (strcmp(proyecto.categoria, "quimica") == 0) strcpy(emoji, "🧪");
        else if (strcmp(proyecto.categoria, "astronomia") == 0) strcpy(emoji, "🔭");
        else if (strcmp(proyecto.categoria, "ecologia") == 0) strcpy(emoji, "🌿");

        char *color_func = (proyecto.funciona == 'S') ? VERDE : ROJO;
        char check_emoji[5];
        strcpy(check_emoji, (proyecto.funciona == 'S') ? "✅" : "❌");

        printf("%s %-30s | %-14s | %s%c %s" RESET " | " AMARILLO "%d" RESET "\n", 
               emoji, proyecto.nombre, proyecto.categoria, color_func, proyecto.funciona, check_emoji, proyecto.anio);
        
        total_proyectos++;
    }

    printf(CELESTE "=======================================================================" RESET "\n");
    printf(BOLD ROSA "📊 Total de proyectos: %d\n" RESET, total_proyectos);
    printf(CELESTE "=======================================================================" RESET "\n\n");

    fclose(archivo);
    return total_proyectos;
}

void mostrar_resumen_categorias(const char *nombre_archivo) {
    FILE *archivo = fopen(nombre_archivo, "r");
    if (!archivo) {
        printf(ROJO "\n❌ No se pudo abrir el archivo %s.\n" RESET, nombre_archivo);
        return;
    }

    printf(CELESTE "=======================================================================" RESET "\n");
    printf(BOLD AMARILLO "  RESUMEN POR CATEGORÍAS (Proyectos Utilizables) " RESET "\n");
    printf(CELESTE "=======================================================================" RESET "\n");

    char categoria[MAX_CATEGORIA];
    int cantidad;

    while (fscanf(archivo, " %[^:]: %d", categoria, &cantidad) != EOF) {
        char emoji[5] = "📦"; 
        if (strcmp(categoria, "robotica") == 0) strcpy(emoji, "🤖");
        else if (strcmp(categoria, "quimica") == 0) strcpy(emoji, "🧪");
        else if (strcmp(categoria, "astronomia") == 0) strcpy(emoji, "🔭");
        else if (strcmp(categoria, "ecologia") == 0) strcpy(emoji, "🌿");

        printf(" %s %-20s : " BOLD VERDE "%d" RESET "\n", emoji, categoria, cantidad);
    }

    printf(CELESTE "=======================================================================" RESET "\n\n");
    fclose(archivo);
}

int main() {
    int total_inicial = mostrar_inventario_proyectos("proyectos.csv", "INVENTARIO INICIAL");
    
    if (total_inicial == 0) {
        return ERROR; 
    }

    FILE* proyectos = fopen(ARCHIVO_PROYECTOS, "r");
    if(!proyectos){
        printf("error al abrir el archivo de proyectos\n");
        return ERROR;
    }

    FILE* aux = fopen(ARCHIVO_AUX, "w");
    if(!aux){
        printf("error al abrir el archivo de proyectos auxiliar\n");
        fclose(proyectos);
        return ERROR;
    }

    if(procesar_archivo(proyectos, aux) == ERROR){
        fclose(proyectos);
        fclose(aux);
        rename(ARCHIVO_AUX, ARCHIVO_PROYECTOS);
        return ERROR;
    }

    fclose(proyectos);
    fclose(aux);
    rename(ARCHIVO_AUX, ARCHIVO_PROYECTOS);

    
    int total_final = mostrar_inventario_proyectos("proyectos.csv", "INVENTARIO FINAL ACTUALIZADO");
    mostrar_resumen_categorias("categorias_proyectos.txt");

    printf("Se descartaron " BOLD "%d" RESET " proyectos obsoletos del inventario\n", total_inicial - total_final);

    return 0;
}