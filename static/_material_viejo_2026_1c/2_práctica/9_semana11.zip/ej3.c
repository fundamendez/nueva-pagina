#include <stdio.h>
#include <string.h>

#define MAX_NOMBRE 100
#define MAX_MOTIVO 150
#define MAX_EVIDENCIA 100

#define PUNTOS_SIN_COARTADA 20
#define SIN_COARTADA 'N'

#define LECTURA "r"
#define ESCRITURA "w"

#define ARCHIVO_SOSPECHOSOS "sospechosos.csv"
#define ARCHIVO_EVIDENCIAS "evidencias.csv"
#define ARCHIVO_REPORTE "reporte_investigacion.csv"

#define FORMATO_LECTURA_SOSPECHOSO "%[^;];%[^;];%c\n"
#define FORMATO_LECTURA_EVIDENCIA "%[^;];%[^;];%i\n"
#define FORMATO_ESCRITURA_REPORTE "%s;%s;%i\n"

#define ENCABEZADO_REPORTE "nombre;motivo;sospecha\n"

const int ERROR = -1;

typedef struct sospechoso {
    char nombre[MAX_NOMBRE];
    char motivo[MAX_MOTIVO];
    char coartada;
} sospechoso_t;

typedef struct evidencia {
    char nombre_sospechoso[MAX_NOMBRE];
    char tipo[MAX_EVIDENCIA];
    int peso;
} evidencia_t;

int leidos_sospechosos(FILE* archivo_sospechosos, sospechoso_t* sospechoso){
    return fscanf(archivo_sospechosos, FORMATO_LECTURA_SOSPECHOSO, sospechoso->nombre, sospechoso->motivo, &(sospechoso->coartada));
}

int cantidad_peso(FILE* archivo_evidencia, char sospechoso[MAX_NOMBRE]){
    evidencia_t evidencia;
    int peso_total = 0;
    int leidos_e = fscanf(archivo_evidencia, FORMATO_LECTURA_EVIDENCIA,evidencia.nombre_sospechoso, evidencia.tipo, &(evidencia.peso));
    while (leidos_e != EOF){
        if (strcmp(evidencia.nombre_sospechoso, sospechoso) == 0){
            peso_total += evidencia.peso;
        }
        leidos_e = fscanf(archivo_evidencia, FORMATO_LECTURA_EVIDENCIA,evidencia.nombre_sospechoso, evidencia.tipo, &(evidencia.peso));
    }
    rewind(archivo_evidencia);

    return peso_total;
}

void generar_reporte(FILE* archivo_sospechosos, FILE* archivo_evidencia, FILE* archivo_reporte){
    sospechoso_t sospechoso;
    int leidos_s = leidos_sospechosos(archivo_sospechosos, &sospechoso);
    int cantidad_peso_s = 0;
    while(leidos_s != EOF){
        cantidad_peso_s = cantidad_peso(archivo_evidencia, sospechoso.nombre);
        fprintf(archivo_reporte, FORMATO_ESCRITURA_REPORTE, sospechoso.nombre, sospechoso.motivo, cantidad_peso_s);
        leidos_s = leidos_sospechosos(archivo_sospechosos, &sospechoso);
    }
    
}

int main() {
    FILE* archivo_sospechosos = fopen(ARCHIVO_SOSPECHOSOS, LECTURA);
    if(!archivo_sospechosos){
        printf("No se pudo abrir el archivo de sospehosos.");
        return ERROR;
    }

    FILE* archivo_evidencias = fopen(ARCHIVO_EVIDENCIAS, LECTURA);
    if(!archivo_evidencias){
        printf("No se pudo abrir el archivo de evidencia.");
        fclose(archivo_sospechosos);
        return ERROR;
    }

    FILE* archivo_reporte = fopen(ARCHIVO_REPORTE,ESCRITURA);
    if(!archivo_reporte){
        printf("No se pudo crear el archivo reporte");
        fclose(archivo_evidencias);
        fclose(archivo_sospechosos);
        return ERROR;
    }

    generar_reporte(archivo_sospechosos, archivo_evidencias, archivo_reporte);

    fclose(archivo_evidencias);
    fclose(archivo_reporte);
    fclose(archivo_sospechosos);
    return 0;
}