#include <stdio.h>

#define MAX_FIL_PUNTAJE 4
#define MAX_COL_PUNTAJE 3

void sumar_puntaje(int puntajes[MAX_FIL_PUNTAJE][MAX_COL_PUNTAJE]){
    int suma = 0;
    for (int i = 0; i < MAX_FIL_PUNTAJE; i++){
        suma = 0;
        for (int j = 0; j < MAX_COL_PUNTAJE; j++){
            suma += puntajes[i][j];
        } 
        printf("El puntaje del JUGADOR N%i es : %i\n", i+1, suma);   
    }
}

void buscar_mayor_puntaje(int puntajes[MAX_FIL_PUNTAJE][MAX_COL_PUNTAJE], int* jugador, int* juego){
    int max_puntaje = 0;
    for (int i = 0; i < MAX_FIL_PUNTAJE; i++){
        for (int j = 0; j < MAX_COL_PUNTAJE; j++){
            if(puntajes[i][j] > max_puntaje){
                max_puntaje = puntajes[i][j];
                (*jugador) = i;
                (*juego) = j;
            }
        }
    }
}

int main(){
    // Asi NO se inicializa una matrix XD
    int puntajes[MAX_FIL_PUNTAJE][MAX_COL_PUNTAJE] = {
        {13,22,53},
        {41,52,69},
        {34,78,100},
        {12,45,70},
    };
    //int tope_fil = 4; --> USAMOS LOS MAX
    //int tope_col = 3; --> USAMOS LOS MAX

    sumar_puntaje(puntajes/*No mando maximos*/);

    int jugador = 0;
    int juego = 0;
    buscar_mayor_puntaje(puntajes, &jugador, &juego);

    printf("EL JUGADOR ES %i Y EL JUEGO ES %i\n", jugador,juego);

    return 0;
}