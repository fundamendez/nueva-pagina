#include <stdio.h>

int main() {
    int numero, otro_numero;

    printf("Ingresá dos números separados por un guion (ej: 10-20): ");
    scanf("%i-%i", &numero, &otro_numero);

    printf("Primer número: %i\n", numero);
    printf("Segundo número: %i\n", otro_numero);

    return 0;
}
