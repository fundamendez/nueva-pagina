#include <stdio.h>

typedef struct credencial {
    int numero;
    int nivel_acceso;
} credencial_t;

typedef struct empleado {
    int legajo;
    char sector;
    float sueldo;
    credencial_t credencial;
} empleado_t;

void cargar_empleado(empleado_t* empleado){
    printf("Ingresa el formato: legajo-sector: \n");
    scanf("%i-%c",&((*empleado).legajo), &((*empleado).sector));
    printf("ingresaste legajo-sector:\n %i-%c", empleado->legajo, empleado->sector);
}

int main(){
    empleado_t empleado;
    cargar_empleado(&empleado);
    return 0;
}
