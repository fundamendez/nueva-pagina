
typedef struct corrector{
    int codigo;
}corrector_t;

typedef struct alumno{
    int curso;
    char division;
    float promedio;
    corrector_t corrector;
}alumno_t;

// SINTAXIS
alumno_t martu;
martu.curso;
martu.division;
martu.promedio = -10000;


void cargar_alumno(alumno_t* martu){
    // no lo hacemos asi: (*martu).curso = ...;
    martu->curso = ...; // lo hacemos asi (es lo mismo pero tkm flechita)
}

alumno_t martu;
cargar_alumno(&martu);

//SINTAXIS
alumno_1.curso
alumno_1->curso; //acceso x referencia




alumno_t alumno_2;