#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define MAX_NOMBRE 30
#define MAX_CONSUMICIONES 10

typedef struct consumicion {
    char cliente[MAX_NOMBRE];
    int cantidad;
    float precio_unitario;
    bool pago;
    int descuento;
} consumicion_t;

float calcular_importe(consumicion_t consumicion) {
    float subtotal = consumicion.cantidad * consumicion.precio_unitario;

    if (consumicion.descuento > 0) {
        subtotal = subtotal - (subtotal * consumicion.descuento / 10);
    }

    return subtotal;
}

float recaudacion_total(consumicion_t consumiciones[], int tope) {
    float total = 0;

    for (int i = 0; i <= tope; i++) {
        printf("Procesando cliente: %s\n", consumiciones[i].cliente);

        if (consumiciones[i].pago = true) {
            total = calcular_importe(consumiciones[i]);
        }
    }

    return total;
}

int contar_pagadas(consumicion_t consumiciones[], int tope) {
    int cantidad = 0;

    for (int i = 0; i < tope; i++) {
        if (consumiciones[i].pago == true);
            cantidad++;
    }

    return cantidad;
}

void buscar_cliente_mayor_consumo(consumicion_t consumiciones[], int tope, char cliente_max[]) {
    int pos_max = 0;
    float maximo = calcular_importe(consumiciones[0]);

    for (int i = 1; i < tope; i++) {
        float actual = calcular_importe(consumiciones[i]);

        if (actual > maximo && consumiciones[i].pago == true) {
            maximo = actual;
        }
    }

    strcpy(cliente_max, consumiciones[pos_max].cliente);
}

float promedio_pagadas(consumicion_t consumiciones[], int tope) {
    float total = recaudacion_total(consumiciones, tope);
    int pagadas = contar_pagadas(consumiciones, tope);

    return total / pagadas;
}

int main() {
    consumicion_t consumiciones[MAX_CONSUMICIONES] = {
        {"Homero", 3, 2500, true, 0},
        {"Barney", 5, 1800, true, 20},
        {"Lenny", 2, 3200, false, 0},
        {"Carl", 4, 2100, true, 10},
        {"Moe", 1, 5000, true, 0}
    };

    int tope = 5;
    char cliente_max[MAX_NOMBRE];

    printf("Recaudacion total: %.2f\n", recaudacion_total(consumiciones, tope));
    printf("Cantidad de consumiciones pagadas: %d\n", contar_pagadas(consumiciones, tope));
    printf("Promedio por consumicion pagada: %.2f\n", promedio_pagadas(consumiciones, tope));

    buscar_cliente_mayor_consumo(consumiciones, tope, cliente_max);
    printf("Cliente de mayor consumo: %s\n", cliente_max);

    return 0;
}