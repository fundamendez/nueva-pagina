#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX_SECTOR 10
#define MAX_NOMBRE 10
#define MAX_TABLEROS 10
#define MAX_FILA 10

const int MINIMO_LUCES_ROJAS = 3;
const int MINIMA_TEMPERATURA = 80;
const int MINIMO_LUCES_ROJAS_RUIDO = 1;

typedef struct tablero {
    char sector[MAX_SECTOR];
    int temperatura;
    int luces_rojas;
    bool hace_ruido;
} tablero_t;

//"Sector A"
//"sector H"
//
//


//tiene más de 3 luces rojas,
//o su temperatura es mayor a 80,
//o hace ruido y además tiene al menos 1 luz roja.

//PRE: Tablero debe estar correctamente inicializado.
//POST: devuelve true si se cumple alguna de las condiciones:tiene más de 3 luces rojas o su temperatura es mayor a 80, o hace ruido y además tiene al menos 1 luz roja. False en caso contrario.
bool es_tablero_urgente(tablero_t tablero){
    return (tablero.luces_rojas > MINIMO_LUCES_ROJAS || tablero.temperatura > MINIMA_TEMPERATURA || (tablero.hace_ruido && tablero.luces_rojas >= MINIMO_LUCES_ROJAS_RUIDO));
}


//PRE: El tope tiene que ser consecuente con el vector, tableros tiene que estar correctamente inicializado, tanto i como tope nombres urgentes deben estar inicializados en 0, nombres_tableros_urgentes debe estar inicializado.
//POST: Almacena recursivamente en nombre_tableros_urgentes los nombres de los tableros que cumplan con los requisitos pedidos (tiene más de 3 luces rojas, o su temperatura es mayor a 80, o hace ruido y además tiene al menos 1 luz roja.).
void almacenar_tableros_urgentes(tablero_t tableros[MAX_TABLEROS], int tope_tableros, int i, char nombres_tableros_urgentes[MAX_FILA][MAX_NOMBRE], int* tope_nombres_urgentes){
    if(i >= tope_tableros){
        return;
    }

    if(es_tablero_urgente(tableros[i])){
        strcpy(nombres_tableros_urgentes[*tope_nombres_urgentes], tableros[i].sector);
        (*tope_nombres_urgentes)++;
    }

    i++;
    almacenar_tableros_urgentes(tableros, tope_tableros, i, nombres_tableros_urgentes, tope_nombres_urgentes);
}


int main () {
    int tope_tableros = 8;
    tablero_t tableros[MAX_TABLEROS] = {
        {"Sector A", 85, 4, true},
        {"Sector B", 75, 2, false},
        {"Sector C", 90, 1, true},
        {"Sector D", 70, 0, false},
        {"Sector E", 80, 3, true},
        {"Sector F", 60, 5, false},
        {"Sector G", 95, 0, true}
    };

    int i = 0;
    int tope_nombres_urgentes = 0;
    char nombres_tableros_urgentes[MAX_FILA][MAX_NOMBRE];

    almacenar_tableros_urgentes(tableros, tope_tableros, i, nombres_tableros_urgentes, &tope_nombres_urgentes);

    for (int i = 0; i < tope_nombres_urgentes; i++) {
        printf("%s\n", nombres_tableros_urgentes[i]);
    }
    return 0;
}
