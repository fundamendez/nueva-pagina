#include <string.h>
#include <stdbool.h>

#define SECTOR_BUSCADO "PLATEA"
const int MAX_PRECIO_ENTRADA = 120000;
const int MIN_PRECIO_ENTRADA = 80000;
#define MAX_FIL 3
#define MAX_COL 3
#define MAX_LETRAS 300
#define MAX_ASIENTOS 500

/*
# Ejercicio 3

1. ¿Qué te están dando?

- matriz de sectores

2. ¿Qué te piden?
- funcion recursiva
- recorrer la matriz
- contar las entradas que pueden vender
El sector debe ser platea
    ● y las entradas que venda tienen que estar entre $80.000 y $120.000
    (ambos inclusive).
    ● y el asiento debe ser par
    ● y estar desocupado.


3. Por recursividad hay que definir
A. Caso base (condición de corte)
B. Resolución del problema
C. Llamado recursivo
*/

typedef struct asiento {
    bool esta_ocupado;
    int numero_asiento;
} asiento_t;

typedef struct sector {
    char nombre_sector[MAX_LETRAS];
    asiento_t asientos[MAX_ASIENTOS];
    int cantidad_asientos;
    int precio;
} sector_t;

// PRE: ... fil y col deberían ser 0
// POST: ...
bool es_sector_valido(sector_t sector) {

	return strcmp(sector.nombre_sector, SECTOR_BUSCADO) == 0 && sector.precio >= MIN_PRECIO_ENTRADA && sector.precio <= MAX_PRECIO_ENTRADA;

}

bool es_asiento_comerciable(asiento_t asiento) {
    return !asiento.esta_ocupado && asiento.numero_asiento % 2 == 0;
}


int cantidad_asientos_comerciables(asiento_t asientos[MAX_ASIENTOS], int cantidad_asientos) {
    int contador = 0;
    for (int i = 0; i < cantidad_asientos; i++) {
        if (es_asiento_comerciable(asientos[i])) {
            contador++;
        }
    }
    return contador;
}

void contar_asientos_validos(sector_t sectores[MAX_FIL][MAX_COL], int fil, int col, int* contador) {
	// M(3x3):
	// [(0,0), (0,1), (0,2)] (0, 3)
	// [(1,0), (1,1), (1,2)]
	// [(2,0), (2,1), (2,2)]
	// -

	// A. Caso base (condición de corte)
	if (fil >= MAX_FIL) {
		return;
	}

	// B. Resolución del problema
	// Contar para un solo sector los asientos que Bart puede vender
	sector_t sector = sectores[fil][col];
	if (es_sector_valido(sector)) {
		*contador += cantidad_asientos_comerciables(sector.asientos, sector.cantidad_asientos);
	}

	// C. Llamado recursivo
	if (col + 1 < MAX_COL) {
		col = col + 1;
		contar_asientos_validos(sectores, fil, col, contador);
	} else {
		fil = fil + 1;
		col = 0;
		contar_asientos_validos(sectores, fil, col, contador);
	}
}

/*
Notas: faltan pre y post en todas las funciones!
*/
