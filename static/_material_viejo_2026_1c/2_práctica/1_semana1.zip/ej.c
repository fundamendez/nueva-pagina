#include <stdio.h>
#include <stdbool.h>

const char AMARILLO = 'A';
const char AZUL = 'Z';
const char ROJO = 'R';

const int NUMERO_AMARILLO = 1;
const int NUMERO_AZUL = 2;
const int NUMERO_ROJO = 3;

// pre: color debe ser AMARILLO, ROJO o AZUL
// post: devuelve el número del cubo del color ingresado
int numero_cubo_por_color(char color){
    if(color == AMARILLO){
        return NUMERO_AMARILLO;
    }else if(color == AZUL){
        return NUMERO_AZUL;
    }else if(color == ROJO){
        return NUMERO_ROJO;
    }
}

// pre: - 
// post: devuelve true si color es AMARILLO, AZUL O ROJO. False en caso contrario
bool es_color_valido(char color){
    return (color == AMARILLO || color == AZUL || color == ROJO);
}

// pre: -
// post: guarda en color_dado el color ingresado por el usuario
void pedir_color(char* color_dado){
    printf("¿De qué color es el cubo? Las opciones son A para amarillo, Z para azul y R para rojo\n");
    scanf(" %c", color_dado);
    while(!es_color_valido(*color_dado)){
        printf("Esa no es una opción válida, ¿De qué color es el cubo? Recorda que las opciones son A para amarillo, Z para azul y R para rojo\n");
        scanf(" %c", color_dado);
    }
}

int main(){
    char color = ' ';
    pedir_color(&color);

    int numero_color = numero_cubo_por_color(color);

    printf("El número del cubo de color %c es %i \n", color, numero_color);

    return 0;
}