#include <stdio.h>
#include <stdbool.h>

typedef struct empleado {
    int legajo;
    char sector;
    float sueldo;
} empleado_t;

const char SEGURIDAD = 'S';
const char MANTENIMIENTO = 'M';
const char CONTROL = 'C';


// PRE: -
// POST: Devuelve true si el sector es valido (SEGURIDAD, MANTENIMIENTO, CONTROL), false en caso contrario
bool es_sector_valido(char sector){
    return sector == SEGURIDAD || sector == MANTENIMIENTO || sector == CONTROL;
}

// PRE: -
// POST: Pide al usuario que ingrese el legajo y el sector, y luego de asegurarse que el sector sea valido guarda ambos atributos en las variables pasadas por referencia.
void pedir_legajo_sector(int* legajo, char* sector){
    printf("Ingresa el formato: legajo-sector: \n");
    scanf("%i-%c", legajo, sector);
    while(!es_sector_valido(*sector)){
        printf("Sector invalido. Ingresa nuevamente: \n");
        scanf("%i-%c", legajo, sector);
    }
}

// pre: el sector es valido (SEGURIDAD, MANTENIMIENTO, CONTROL). Legajo y sueldo deben ser mayores a cero.
// post: inicializa un empleado con los atributos recibidos por parametro
void cargar_empleado(empleado_t* empleado, char sector, int legajo, float sueldo){
    (*empleado).legajo = legajo;
    // empleado->legajo = legajo;
    (*empleado).sector = sector;
    (*empleado).sueldo = sueldo;
}

// pre: -
// post: muestra los datos del empleado por pantalla
void mostrar_empleado(empleado_t empleado){
    printf("Legajo del empleado: %i\n", empleado.legajo);
    printf("Sector del empleado: %c\n", empleado.sector);
    printf("Sueldo del empleado: %i\n", empleado.sueldo);
}

int main(){
    int legajo = -1;
    char sector = -1;
    empleado_t empleado;
    pedir_legajo_sector(&legajo, &sector);
    cargar_empleado(&empleado, sector, legajo, 100000);
    mostrar_empleado(empleado);
    return 0;
}
