#include <stdio.h>
#include <stdbool.h>

#define MAX_FILAS 3
#define MAX_COLUMNAS 3

const int CALIDAD_MINIMA = 5;

typedef struct camara {
	int oficina;
	char piso;
	bool prendida;
	int calidad;
} camara_t;

/* A partir de una matriz de camaras:

	a) Prender camaras impares cuya calidad sea mayor igual a 5.

	b) Apagar todas las que apunten a una oficina par.
*/

//pre: -
//post: inicializa la matriz de camaras junto a sus topes.
void inicializar_camaras(camara_t matriz_camaras[MAX_FILAS][MAX_COLUMNAS], int* tope_filas, int* tope_columnas){
	matriz_camaras[0][0] = (camara_t){1, 'A', true, 6};
    matriz_camaras[0][1] = (camara_t){2, 'A', true, 4};
    matriz_camaras[0][2] = (camara_t){3, 'A', false, 7};

    matriz_camaras[1][0] = (camara_t){4, 'B', false, 3};
    matriz_camaras[1][1] = (camara_t){5, 'B', false, 8};
    matriz_camaras[1][2] = (camara_t){6, 'B', true, 5};

    matriz_camaras[2][0] = (camara_t){7, 'C', true, 2};
    matriz_camaras[2][1] = (camara_t){8, 'C', false, 9};
    matriz_camaras[2][2] = (camara_t){9, 'C', true, 6};

	(*tope_filas) = 3;
	(*tope_columnas) = 3;
}

//pre: recibe una matriz de camaras inicializada, con topes de filas y columnas mayores a 0 y menores al maximo
//post: imprime las camaras prendidas o apagadas según el booleano que se recibe por parametro
void imprimir_camaras(camara_t matriz_camaras[MAX_FILAS][MAX_COLUMNAS], int tope_filas, int tope_columnas, bool prendidas){
	for (int i = 0; i < tope_filas; i++){
		for (int j = 0; j < tope_columnas; j++){
			camara_t camara = matriz_camaras[i][j];
			if (camara.prendida == prendidas){
				printf("El numero de la camara es: %i, y su calidad es: %i.\n", camara.oficina, camara.calidad);
				if (camara.prendida) printf("La camara esta prendida.\n\n");
				else printf("La camara está apagada.\n\n");
			}
		}
	}
}

// pre: recibe una matriz de camaras inicializada, con topes de filas y columnas mayores a 0 y menores al maximo
// post: prende las camaras de las oficinas impares y de calidad mayor a CALIDAD_MINIMA y apaga el resto
void prender_camaras(camara_t camaras[MAX_FILAS][MAX_COLUMNAS], int tope_filas, int tope_columnas){
	for(int i = 0; i < tope_filas; i++){
		for(int j = 0; j < tope_columnas; j++){
			camara_t camara = camaras[i][j];
			if(camara.oficina % 2 != 0 && camara.calidad >= CALIDAD_MINIMA){
				camaras[i][j].prendida = true;
			}else{
				camaras[i][j].prendida = false;
			}
		}
	}
}

int main()
{
	camara_t camaras[MAX_FILAS][MAX_COLUMNAS];
	int tope_filas = 0;
	int tope_columnas = 0;

	inicializar_camaras(camaras, &tope_filas, &tope_columnas);
	imprimir_camaras(camaras, tope_filas, tope_columnas, true);

	printf("------DESPUES DE PRENDER-------\n\n");

	prender_camaras(camaras, tope_filas, tope_columnas);
	imprimir_camaras(camaras, tope_filas, tope_columnas, true);

	return 0;
}