#include <stdio.h>
#include <stdbool.h>

#define MAX_EMPLEADOS 10

typedef struct credencial {
   int numero;
   int nivel_acceso;
} credencial_t;

typedef struct empleado {
   int legajo;
   char sector;
   float sueldo;
   credencial_t credencial;
} empleado_t;

const char SEGURIDAD = 'S';
const char MANTENIMIENTO = 'M';
const char CONTROL = 'C';
const int EMPLEADO_NO_ENCONTRADO = -1;

/*
 * PRE: -
 * POST:
 * - Se inicializan 5 empleados en el vector empleados.
 * - tope_empleados queda actualizado con la cantidad de empleados cargados (5).
 */
void inicializar_empleados(empleado_t empleados[MAX_EMPLEADOS], int* tope_empleados) {
    (*tope_empleados) = 0;
    empleados[(*tope_empleados)].legajo = 100;
    empleados[(*tope_empleados)].sector = 'S';
    empleados[(*tope_empleados)].sueldo = 250000;
    empleados[(*tope_empleados)].credencial.numero = 501;
    empleados[(*tope_empleados)].credencial.nivel_acceso = 2;
    (*tope_empleados)++;

    empleados[(*tope_empleados)].legajo = 101;
    empleados[(*tope_empleados)].sector = 'M';
    empleados[(*tope_empleados)].sueldo = 280000;
    empleados[(*tope_empleados)].credencial.numero = 502;
    empleados[(*tope_empleados)].credencial.nivel_acceso = 3;
    (*tope_empleados)++;

    empleados[(*tope_empleados)].legajo = 102;
    empleados[(*tope_empleados)].sector = 'C';
    empleados[(*tope_empleados)].sueldo = 270000;
    empleados[(*tope_empleados)].credencial.numero = 503;
    empleados[(*tope_empleados)].credencial.nivel_acceso = 1;
    (*tope_empleados)++;

    empleados[(*tope_empleados)].legajo = 103;
    empleados[(*tope_empleados)].sector = 'S';
    empleados[(*tope_empleados)].sueldo = 260000;
    empleados[(*tope_empleados)].credencial.numero = 504;
    empleados[(*tope_empleados)].credencial.nivel_acceso = 2;
    (*tope_empleados)++;
    
    empleados[(*tope_empleados)].legajo = 104;
    empleados[(*tope_empleados)].sector = 'M';
    empleados[(*tope_empleados)].sueldo = 300000;
    empleados[(*tope_empleados)].credencial.numero = 505;
    empleados[(*tope_empleados)].credencial.nivel_acceso = 3;
    (*tope_empleados)++;
}

void mostrar_empleado(empleado_t empleado){
   printf("Legajo del empleado: %i\n", empleado.legajo);
   printf("Sector del empleado: %c\n", empleado.sector);
   printf("Sueldo del empleado: %.2f\n", empleado.sueldo);
   printf("Credencial nro: %i, nivel de acceso: %i\n", empleado.credencial.numero, empleado.credencial.nivel_acceso);
}

// pre: el tope_empleados debe estar entre 0 y MAX_EMPLEADOS y se debe corresponder con la cantidad de elementos del vector. El empleado debe tener todos sus campos inicializados.
// post: agrega el empleado que se recibe al vector y aumenta en 1 el tope.
void agregar_empleado(empleado_t empleados[MAX_EMPLEADOS], int* tope_empleados, empleado_t empleado){
   empleados[(*tope_empleados)] = empleado;
   (*tope_empleados)++;
}

// pre: el tope_empleados debe estar entre 0 y MAX_EMPLEADOS y se debe corresponder con la cantidad de elementos del vector.
// post: devuelve el indice del empleado cuya credencial es igual a credencial_buscada. Si no lo encuentra, devuelve EMPLEADO_NO_ENCONTRADO
int posicion_empleado_buscado(empleado_t empleados[MAX_EMPLEADOS], int tope_empleados, credencial_t credencial_buscada){
   int i = 0;
   bool empleado_encontrado = false;
   int posicion_encontrada = EMPLEADO_NO_ENCONTRADO;
   while(i < tope_empleados && !empleado_encontrado){
      if((empleados[i].credencial.numero == credencial_buscada.numero) && (empleados[i].credencial.nivel_acceso == credencial_buscada.nivel_acceso)){
         empleado_encontrado = true;
         posicion_encontrada = i;
      }
      i++;
   }
   return posicion_encontrada;
}

int main(){
   empleado_t empleados[MAX_EMPLEADOS];
   int tope_empleados = 0;
   empleado_t empleado;
   empleado.legajo = 578;
   empleado.sector = 'S';
   empleado.sueldo = 6666666;

   credencial_t credencial;
   credencial.numero = 501;
   credencial.nivel_acceso = 1;

   empleado.credencial = credencial;

   inicializar_empleados(empleados, &tope_empleados);

   agregar_empleado(empleados, &tope_empleados, empleado);

   for(int i = 0; i < tope_empleados; i++){
      printf("empleado %i\n", i+1);
      mostrar_empleado(empleados[i]);
      printf("\n\n");
   }

   credencial_t credencial_buscada = {8888888, 1};

   int posicion_buscada = posicion_empleado_buscado(empleados, tope_empleados, credencial_buscada);

   if(posicion_buscada == EMPLEADO_NO_ENCONTRADO){
      printf("El empleado no se encontro\n");
   }else{
      printf("El empleado buscado esta en %i\n", posicion_buscada);
      mostrar_empleado(empleados[posicion_buscada]);
   }

   return 0;
}