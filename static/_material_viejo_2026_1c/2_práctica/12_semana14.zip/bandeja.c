#include "bandeja.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

struct bandeja {
    pedido_mail_t* primero;
    pedido_mail_t* ultimo;
};

pedido_mail_t* crear_nodo(pedido_mail_t pedido)
{
    pedido_mail_t* nodo = malloc(sizeof(pedido_mail_t));
    if (!nodo)
        return NULL;

    *nodo = pedido;
    nodo->siguiente = NULL;

    return nodo;
}

bandeja_t* bandeja_crear()
{
    bandeja_t* bandeja = malloc(sizeof(bandeja_t));
    if (!bandeja)
        return NULL;

    bandeja->primero = NULL;
    bandeja->ultimo = NULL;

    return bandeja;
}

void bandeja_destruir(bandeja_t* bandeja)
{
    if (!bandeja)
        return;

    pedido_mail_t* actual = bandeja->primero;
    while (actual) {
        pedido_mail_t* siguiente = actual->siguiente;
        free(actual);
        actual = siguiente;
    }

    free(bandeja);
}

void bandeja_agregar_al_inicio(bandeja_t* bandeja, pedido_mail_t pedido)
{
    pedido_mail_t* nodo = crear_nodo(pedido);
    if (!nodo)
        return;

    nodo->siguiente = bandeja->primero;
    bandeja->primero = nodo;
    if (!bandeja->ultimo)
        bandeja->ultimo = nodo;
}

void bandeja_agregar_al_final(bandeja_t* bandeja, pedido_mail_t pedido)
{
    pedido_mail_t* nodo = crear_nodo(pedido);
    if (!nodo)
        return;

    if (bandeja->ultimo)
        bandeja->ultimo->siguiente = nodo;
    else
        bandeja->primero = nodo;
    bandeja->ultimo = nodo;
}

pedido_mail_t* bandeja_quitar_primero(bandeja_t* bandeja)
{
    pedido_mail_t* nodo = bandeja->primero;
    bandeja->primero = nodo->siguiente;
    if (!bandeja->primero)
        bandeja->ultimo = NULL;

    nodo->siguiente = NULL;
    return nodo;
}

pedido_mail_t* bandeja_primero(bandeja_t* bandeja)
{
    return bandeja->primero;
}

void bandeja_responder_cliente(
        char* mail_cliente,
        char* mensaje)
{
    printf("Para: %s\n%s\n\n", mail_cliente, mensaje);
}
