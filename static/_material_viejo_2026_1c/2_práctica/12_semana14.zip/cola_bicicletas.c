// cola_bicicletas.c
#include "cola_bicicletas.h"
#include <stdlib.h>

typedef struct nodo {
    bicicleta_t bicicleta;
    struct nodo* siguiente;
} nodo_t;

struct cola_bicicletas {
    nodo_t* frente;
    nodo_t* fondo;
};

cola_bicicletas_t* cola_bicicletas_crear() {
    cola_bicicletas_t* cola = malloc(sizeof(cola_bicicletas_t));
    if (!cola) return NULL;
    cola->frente = NULL;
    cola->fondo  = NULL;
    return cola;
}

void cola_bicicletas_destruir(cola_bicicletas_t* cola) {
    nodo_t* actual = cola->frente;
    while (actual) {
        nodo_t* siguiente = actual->siguiente;
        free(actual);
        actual = siguiente;
    }
    free(cola);
}

void cola_bicicletas_encolar(cola_bicicletas_t* cola, bicicleta_t bicicleta) {
    nodo_t* nodo = malloc(sizeof(nodo_t));
    if (!nodo) return;
    nodo->bicicleta = bicicleta;
    nodo->siguiente = NULL;

    if (!cola->fondo) {
        // Cola vacía: el nodo es frente y fondo a la vez
        cola->frente = nodo;
        cola->fondo  = nodo;
    } else {
        cola->fondo->siguiente = nodo;
        cola->fondo = nodo;
    }
}

bicicleta_t* cola_bicicletas_desencolar(cola_bicicletas_t* cola) {
    if (!cola->frente) return NULL;

    nodo_t* nodo = cola->frente;
    bicicleta_t* bicicleta = malloc(sizeof(bicicleta_t));
    if (!bicicleta) return NULL;

    *bicicleta = nodo->bicicleta;
    cola->frente = nodo->siguiente;

    // Si la cola quedó vacía, actualizar también fondo
    if (!cola->frente)
        cola->fondo = NULL;

    free(nodo);
    return bicicleta;
}

bicicleta_t* cola_bicicletas_frente(cola_bicicletas_t* cola) {
    if (!cola->frente) return NULL;
    return &cola->frente->bicicleta;
}

bool cola_bicicletas_vacia(cola_bicicletas_t* cola) {
    return cola->frente == NULL;
}