#ifndef PILA_DONAS_H
#define PILA_DONAS_H

#include <stdbool.h>
#include <stddef.h>

#define MAX_SABOR 500

typedef struct dona {
    char* sabor[MAX_SABOR]; // "frutilla", "chocolate", "glaseada"
    bool con_glaseado;
    int tentacion;
} dona_t;

typedef struct pila_donas pila_donas_t;

/*
 * Crea una pila de donas vacía.
 * Devuelve un puntero a la pila creada, o NULL en caso de error.
 */
pila_donas_t* pila_donas_crear();

/*
 * Destruye la pila liberando todos los recursos de la misma.
 */
void pila_donas_destruir(pila_donas_t* pila);

/*
 * Apila una dona. Devuelve true en éxito, false en error (por ejemplo, memoria insuficiente).
 */
bool pila_donas_apilar(pila_donas_t* pila, dona_t* dona);

/*
 * Desapila y devuelve la dona del tope. Devuelve NULL si la pila está vacía.
 */
dona_t* pila_donas_desapilar(pila_donas_t* pila);

/*
 * Indica si la pila está vacía.
 */
bool pila_donas_esta_vacia(const pila_donas_t* pila);


#endif /* PILA_DONAS_H */

