#include "pila_donas.h"

#include <stdlib.h>

typedef struct nodo {
    dona_t* dona;
    struct nodo* siguiente;
} nodo_t;

struct pila_donas {
    nodo_t* tope;
};

pila_donas_t* pila_donas_crear()
{
    pila_donas_t* pila = malloc(sizeof(pila_donas_t));

    if (!pila)
        return NULL;

    pila->tope = NULL;

    return pila;
}

void pila_donas_destruir(pila_donas_t* pila)
{
    if (!pila)
        return;

    while (!pila_donas_esta_vacia(pila))
        pila_donas_desapilar(pila);

    free(pila);
}

bool pila_donas_apilar(pila_donas_t* pila, dona_t* dona)
{
    if (!pila)
        return false;

    nodo_t* nuevo = malloc(sizeof(nodo_t));

    if (!nuevo)
        return false;

    nuevo->dona = dona;
    nuevo->siguiente = pila->tope;

    pila->tope = nuevo;

    return true;
}

dona_t* pila_donas_desapilar(pila_donas_t* pila)
{
    if (!pila || pila_donas_esta_vacia(pila))
        return NULL;

    nodo_t* nodo_a_borrar = pila->tope;
    dona_t* dona = nodo_a_borrar->dona;

    pila->tope = nodo_a_borrar->siguiente;

    free(nodo_a_borrar);

    return dona;
}

bool pila_donas_esta_vacia(const pila_donas_t* pila)
{
    return !pila || pila->tope == NULL;
}