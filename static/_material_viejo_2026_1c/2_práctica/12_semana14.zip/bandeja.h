#ifndef MAILS_PEDIDOS_H
#define MAILS_PEDIDOS_H


#include <stdbool.h>


#define MAX_MAIL 100


// Nodo de la lista enlazada (pedido recibido por mail)
typedef struct pedido_mail {
   int id_bicicleta;
   int id_repuesto;
   char mail_cliente[MAX_MAIL];
   bool es_spam;


   struct pedido_mail* siguiente;
} pedido_mail_t;


typedef struct bandeja bandeja_t;


/**
* Pre: -
* Post: Devuelve una bandeja vacía reservada en el heap,
*       o NULL si la reserva falla.
*       La bandeja devuelta debe liberarse con bandeja_destruir().
*/
bandeja_t* bandeja_crear();


/**
* Pre: bandeja válida (puede estar vacía).
* Post: Libera la bandeja y TODOS los pedidos que sigan dentro de ella.
*       Luego de esta llamada el puntero 'bandeja' queda invalidado y no
*       debe usarse. No libera los pedidos que el usuario haya sacado
*       previamente con bandeja_quitar_primero(): esos son responsabilidad
*       de quien los quitó.
*/
void bandeja_destruir(bandeja_t* bandeja);


/**
* Pre: bandeja válida.
* Post: Crea un nuevo pedido (copiando los datos del struct recibido,
*       ignorando su campo 'siguiente') y lo agrega al comienzo. El pedido
*       queda en posesión de la bandeja: NO debe liberarse por separado
*       mientras siga dentro de ella.
*/
void bandeja_agregar_al_inicio(bandeja_t* bandeja, pedido_mail_t pedido);

/**
* Pre: bandeja válida.
* Post: Crea un nuevo pedido (copiando los datos del struct recibido,
*       ignorando su campo 'siguiente') y lo agrega al final. El pedido
*       queda en posesión de la bandeja: NO debe liberarse por separado
*       mientras siga dentro de ella.
*/
void bandeja_agregar_al_final(bandeja_t* bandeja, pedido_mail_t pedido);


/**
* Pre: bandeja válida y no vacía.
* Post: Saca el primer pedido de la lista y lo devuelve.
*       La bandeja deja de ser dueña del pedido: a partir de acá la
*       memoria del pedido pasa a ser responsabilidad de quien llama, que
*       DEBE liberarlo con free() cuando termine de usarlo. El campo
*       'siguiente' del pedido devuelto queda en NULL.
*/
pedido_mail_t* bandeja_quitar_primero(bandeja_t* bandeja);


/**
* Pre: bandeja válida.
* Post: Devuelve un puntero al primer pedido sin sacarlo de la lista, o
*       NULL si la bandeja está vacía. El pedido sigue siendo propiedad de
*       la bandeja: NO debe liberarse ni modificarse su campo 'siguiente'.
*/
pedido_mail_t* bandeja_primero(bandeja_t* bandeja);


/**
* Pre: mail_cliente y mensaje son strings válidos.
*
* Post:
*  Simula el envío de una respuesta al cliente. No reserva ni libera
*  memoria: solo lee las cadenas recibidas (no toma posesión de ellas).
*/
void bandeja_responder_cliente(char* mail_cliente, char* mensaje);


#endif
