#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "caja_repuestos.h"
const char* obtener_emoji(const char* nombre) {
    if (strstr(nombre, "Tornillo") || strstr(nombre, "tornillo")) return "🔩";
    if (strstr(nombre, "Tuerca")    || strstr(nombre, "tuerca"))    return "🔩";
    if (strstr(nombre, "Cadena")    || strstr(nombre, "cadena"))    return "🔗";
    if (strstr(nombre, "Manubrio")  || strstr(nombre, "manubrio"))  return "🚲";
    if (strstr(nombre, "Pedal")     || strstr(nombre, "pedal"))     return "🔧";
    if (strstr(nombre, "Asiento")   || strstr(nombre, "asiento"))   return "💺";
    if (strstr(nombre, "Rueda")     || strstr(nombre, "rueda"))     return "🛞";
    if (strstr(nombre, "Freno")     || strstr(nombre, "freno"))     return "🛑";
    if (strstr(nombre, "Luz")       || strstr(nombre, "luz"))       return "💡";
    if (strstr(nombre, "Bomba")     || strstr(nombre, "bomba"))     return "💨";
    
    return "🛠️";
}
#define TORNILLO "Tornillo"
const int CODIGO_MAXIMO = 13000;
const int TAMANIO_MAXIMO = 50;

caja_repuestos_t* inicializar_caja_ejemplo() {
    caja_repuestos_t* caja = caja_repuestos_crear();
    if (!caja) return NULL;
    repuesto_t r1 = {"Tornillo", 15000, 20, false, 1};
    caja_repuestos_apilar(caja, r1);
    repuesto_t r2 = {"Tornillo", 14500, 45, false, 2};
    caja_repuestos_apilar(caja, r2);
    repuesto_t r3 = {"Manubrio playero", 1000, 150, false, 3};
    caja_repuestos_apilar(caja, r3);
    repuesto_t r4 = {"Cadena oxidada", 5500, 80, true, 4};
    caja_repuestos_apilar(caja, r4);
    repuesto_t r5 = {"Tuerca vieja", 3000, 55, true, 5};
    caja_repuestos_apilar(caja, r5);
    repuesto_t r6 = {"Pedal roto", 20000, 100, false, 6};
    caja_repuestos_apilar(caja, r6);
    repuesto_t r7 = {"Asiento desgastado", 25000, 60, true, 7};
    caja_repuestos_apilar(caja, r7);
    repuesto_t r8 = {"Rueda pinchada", 40000, 500, false, 8};
    caja_repuestos_apilar(caja, r8);
    repuesto_t r9 = {"Freno Nuevo", 15000, 50, false, 9};
    caja_repuestos_apilar(caja, r9);
    repuesto_t r10 = {"Luz trasera", 8000, 30, false, 10};
    caja_repuestos_apilar(caja, r10);
    repuesto_t r11 = {"Luz delantera", 12000, 30, false, 11};
    caja_repuestos_apilar(caja, r11);
    repuesto_t r12 = {"Bomba de aire", 18000, 40, false, 12};
    caja_repuestos_apilar(caja, r12);

    return caja;
}

void imprimir_repuesto_formateado(repuesto_t rep) {
    const char* emoji = obtener_emoji(rep.nombre);
    printf("| %s | ID: %-3d | %-20s | Cód: %-5d | Tam: %-3d mm | Oxidado: %-3s |\n",
           emoji,
           rep.id_repuesto, 
           rep.nombre, 
           rep.codigo, 
           rep.tamanio, 
           rep.oxidado ? "SI" : "NO");
}

void imprimir_caja(caja_repuestos_t* caja) {
    if (!caja || caja_repuestos_vacia(caja)) {
        printf("\n[!] La caja de repuestos está vacía o no existe.\n\n");
        return;
    }
    caja_repuestos_t* caja_aux = caja_repuestos_crear();
    if (!caja_aux) return;

    printf("\n=========================== CAJA DE REPUESTOS ===========================\n");
    while (!caja_repuestos_vacia(caja)) {
        repuesto_t* rep = caja_repuestos_desapilar(caja);
        if (rep != NULL) {
            imprimir_repuesto_formateado(*rep);
            caja_repuestos_apilar(caja_aux, *rep);
            free(rep);
        }
    }
    printf("========================================================================================\n\n");
    while (!caja_repuestos_vacia(caja_aux)) {
        repuesto_t* rep_aux = caja_repuestos_desapilar(caja_aux);
        if (rep_aux != NULL) {
            caja_repuestos_apilar(caja, *rep_aux);
            free(rep_aux);
        }
    }
    caja_repuestos_destruir(caja_aux);
}

//Pre: El campo nombre tiene que ser un string.
//Post: devuelve true si el repuesto no es un tornillo o no tiene un codigo mayor a 13000
bool tornillo_valido(repuesto_t repuesto){
    return !((strcmp(repuesto.nombre, TORNILLO) == 0) && repuesto.codigo > CODIGO_MAXIMO);
}

//Pre: -
//Post: devuelve true si el repuesto no tiene mas de 50mm o no esta oxidado.
bool repuesto_valido(repuesto_t repuesto){
    return !(repuesto.tamanio > TAMANIO_MAXIMO && repuesto.oxidado);
}

//Pre: caja nelson tiene que estar creado con caja_repuestos_crear.
//Post: Actualiza la caja de nelson descartando los repuestos que no son validos para repuesto valido y tornillo valido. Se libera la memoria de los repuestos invalidos.

void actualizar_repuestos(caja_repuestos_t* caja_nelson){
    caja_repuestos_t* caja_aux = caja_repuestos_crear();

    while (!caja_repuestos_vacia(caja_nelson)){
        repuesto_t* repuesto_actual = caja_repuestos_desapilar(caja_nelson);

        if(tornillo_valido(*repuesto_actual) && repuesto_valido(*repuesto_actual)){
            caja_repuestos_apilar(caja_aux, *repuesto_actual);
        }
        else{
            free(repuesto_actual);
        }
    }

    while (!caja_repuestos_vacia(caja_aux)){
        repuesto_t* repuesto_actual = caja_repuestos_desapilar(caja_aux);
        caja_repuestos_apilar(caja_nelson, *repuesto_actual);
    }
    
    caja_repuestos_destruir(caja_aux);
}





int main(){
    caja_repuestos_t* caja_nelson = inicializar_caja_ejemplo();
    if (!caja_nelson) {
        printf("Error al crear la caja de repuestos.\n");
        return -1;
    }

    printf("--- ESTADO INICIAL DE LA CAJA ---");
    imprimir_caja(caja_nelson);

    actualizar_repuestos(caja_nelson);

    printf("--- ESTADO FINAL DE LA CAJA ---");
    imprimir_caja(caja_nelson);

    return 0;
}