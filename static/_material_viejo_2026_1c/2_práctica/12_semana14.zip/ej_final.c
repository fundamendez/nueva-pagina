#include <stdio.h>
#include <string.h>

#include "pila_donas.h"

#define SABOR_FEO "frutilla"

const int ERROR = 1;
const int EXITO = 0;


void mostrar_y_vaciar_pila(pila_donas_t* pila)
{
    while (!pila_donas_esta_vacia(pila)) {

        dona_t* dona = pila_donas_desapilar(pila);

        printf("Sabor: %-12s | Glaseado: %s | Tentacion: %d\n",
               dona->sabor,
               dona->con_glaseado ? "Si" : "No",
               dona->tentacion);

        dona_destruir(dona);
    }
}


int procesar_donas(pila_donas_t* pila){
    pila_donas_t* pila_donas_feas = pila_donas_crear();
    if(!pila_donas_feas) {
        printf("Hubo un error creando la pila de donas feas");
        return ERROR;
    }

    pila_donas_t* pila_donas_ricas = pila_donas_crear();
    if(!pila_donas_ricas){
        printf("Hubo un error creando la pila de donas ricas");
        pila_donas_destruir(pila_donas_feas);
        return ERROR;
    }

    while(!pila_donas_esta_vacia(pila)) {
        dona_t* dona = pila_donas_desapilar(pila);
        if(strcmp(dona->sabor, SABOR_FEO) == 0){
            pila_donas_apilar(pila_donas_feas, dona);
        }
        else {
            pila_donas_apilar(pila_donas_ricas, dona);
        }
    }

    while(!pila_donas_esta_vacia(pila_donas_ricas)) {
        dona_t* dona = pila_donas_desapilar(pila_donas_ricas);
        pila_donas_apilar(pila, dona);
    }

    while(!pila_donas_esta_vacia(pila_donas_feas)) {
        dona_t* dona = pila_donas_desapilar(pila_donas_feas);
        pila_donas_apilar(pila, dona);
    }

    pila_donas_destruir(pila_donas_feas);
    pila_donas_destruir(pila_donas_ricas);
    
    return EXITO;
}


int main()
{
    pila_donas_t* pila = pila_donas_crear();

    if (!pila){
        printf("Hubo un error al crear la pila\n");
        return ERROR;
    }

    pila_donas_apilar(pila, dona_crear("frutilla", true, 9));
    pila_donas_apilar(pila, dona_crear("glaseada", true, 5));
    pila_donas_apilar(pila, dona_crear("frutilla", false, 7));
    pila_donas_apilar(pila, dona_crear("chocolate", true, 10));

    printf("Pila procesada:\n\n");

    procesar_donas(pila);

    mostrar_y_vaciar_pila(pila);


    pila_donas_destruir(pila);

    return 0;
}