#include "bandeja.h"
#include <stdlib.h>
#include <stdio.h>


#define RESPUESTA_AUTOMATICA "Su bicicleta será atendida por Nelson a la brevedad."

const int ERROR = -1;
const int MIN_REPUESTO = 0;


// Pre: recibe una bandeja válida creada con bandeja_crear()
// Post: carga pedidos en la bandeja
void cargar_pedidos(bandeja_t* bandeja){
    pedido_mail_t pedidos[] = {
        {1, 10, "ana@mail.com", false, NULL},
        {2, 5, "spam@mail.com", true, NULL},
        {3, -1, "luis@mail.com", false, NULL},
        {4, 7, "marta@mail.com", false, NULL},
    };

    for (int i = 0; i < 4; i++)
        bandeja_agregar_al_final(bandeja, pedidos[i]);
}



bool mail_valido(pedido_mail_t* mail){
    return !mail->es_spam && mail->id_repuesto > MIN_REPUESTO;
}

// PRE: bandeja fue creada correctamente con bandeja_crear()
// POST: descarta los mails que sean spam o que tengan un id de repuesto inválido y contesta los que son válidos. Devuelve una bandeja con los mails válidos y NULL en caso de error.
bandeja_t* administrar_mails(bandeja_t* bandeja) {

    bandeja_t* bandeja_aux = bandeja_crear();
    if (!bandeja_aux){
        printf("Hubo un error creando la bandea auxiliar\n");
        return NULL;
    }

    while(bandeja_primero(bandeja)) {
        pedido_mail_t* mail = bandeja_quitar_primero(bandeja);

        if(mail_valido(mail)){
            bandeja_responder_cliente(mail->mail_cliente, RESPUESTA_AUTOMATICA);
            bandeja_agregar_al_final(bandeja_aux, *mail);
        }

        free(mail);
    }

    bandeja_destruir(bandeja);

    return bandeja_aux;
}


int main()
{
    bandeja_t* bandeja = bandeja_crear();
    if (!bandeja){
        printf("Hubo un error creando una bandeja nueva\n");
        return ERROR;
    }

    cargar_pedidos(bandeja);

    bandeja = administrar_mails(bandeja);
    if(!bandeja) {
        printf("Hubo un error al administrar los mails\n");
        return ERROR;
    }

    bandeja_destruir(bandeja);
    return 0;
}
