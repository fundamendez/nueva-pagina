#ifndef COLA_BICICLETAS_H
#define COLA_BICICLETAS_H

#include <stdbool.h>

typedef struct bicicleta {
    int id_bicicleta;
    int id_repuesto;
    bool arreglada;
} bicicleta_t;

typedef struct cola_bicicletas cola_bicicletas_t;

/*
 * Pre: -
 * Post: Crea una cola vacía reservada en el heap,
 *       o NULL si falla la reserva.
 */
cola_bicicletas_t* cola_bicicletas_crear();

/*
 * Pre: cola válida.
 * Post: Libera toda la memoria asociada.
 */
void cola_bicicletas_destruir(cola_bicicletas_t* cola);

/*
 * Pre: cola válida.
 * Post: Encola una bicicleta al final.
 */
void cola_bicicletas_encolar(cola_bicicletas_t* cola, bicicleta_t bicicleta);

/*
 * Pre: cola válida y no vacía.
 * Post: Desencola la primera bicicleta y la devuelve.
 */
bicicleta_t* cola_bicicletas_desencolar(cola_bicicletas_t* cola);

/*
 * Pre: cola válida.
 * Post: Devuelve la primera bicicleta sin quitarla, o NULL si está vacía.
 */
bicicleta_t* cola_bicicletas_frente(cola_bicicletas_t* cola);

/*
 * Pre: cola válida.
 * Post: Devuelve true si la cola está vacía.
 */
bool cola_bicicletas_vacia(cola_bicicletas_t* cola);

#endif
