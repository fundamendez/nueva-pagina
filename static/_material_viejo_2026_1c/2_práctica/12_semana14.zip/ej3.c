#include "cola_bicicletas.h"
#include "bandeja.h"
#include "caja_repuestos.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define TORNILLO "Tornillo"
#define RESPUESTA_AUTOMATICA "Su bicicleta será atendida por Nelson a la brevedad."

const int CODIGO_MAXIMO = 13000;
const int TAMANIO_MAXIMO = 50;
const int ERROR = -1;
const int MIN_REPUESTO = 0;
const int EXITO = 0;

void imprimir_bicicletas(cola_bicicletas_t* cola, const char* titulo) {
    printf("\n╔══════════════════════════════════════╗\n");
    printf("║  %-36s║\n", titulo);
    printf("╠══════════════════════════════════════╣\n");

    cola_bicicletas_t* temp = cola_bicicletas_crear();
    int numero = 1;

    while (!cola_bicicletas_vacia(cola)) {
        bicicleta_t* bici = cola_bicicletas_desencolar(cola);

        printf("║  #%-3d  Bici: %-6d  Repuesto: %-4d  ║\n",
               numero++, bici->id_bicicleta, bici->id_repuesto);
        printf("║         Estado: %-21s║\n",
               bici->arreglada ? "✓ Arreglada" : "✗ Pendiente");
        printf("╠══════════════════════════════════════╣\n");

        cola_bicicletas_encolar(temp, *bici);
        free(bici);
    }

    if (numero == 1) {
        printf("║  (sin bicicletas)                    ║\n");
        printf("╠══════════════════════════════════════╣\n");
    }

    printf("║  Total: %-29d║\n", numero - 1);
    printf("╚══════════════════════════════════════╝\n\n");

    // Restaurar la cola
    while (!cola_bicicletas_vacia(temp)) {
        bicicleta_t* bici = cola_bicicletas_desencolar(temp);
        cola_bicicletas_encolar(cola, *bici);
        free(bici);
    }
    cola_bicicletas_destruir(temp);
}

const char* obtener_emoji(const char* nombre) {
    if (strstr(nombre, "Tornillo") || strstr(nombre, "tornillo")) return "🔩";
    if (strstr(nombre, "Tuerca")    || strstr(nombre, "tuerca"))    return "🔩";
    if (strstr(nombre, "Cadena")    || strstr(nombre, "cadena"))    return "🔗";
    if (strstr(nombre, "Manubrio")  || strstr(nombre, "manubrio"))  return "🚲";
    if (strstr(nombre, "Pedal")     || strstr(nombre, "pedal"))     return "🔧";
    if (strstr(nombre, "Asiento")   || strstr(nombre, "asiento"))   return "💺";
    if (strstr(nombre, "Rueda")     || strstr(nombre, "rueda"))     return "🛞";
    if (strstr(nombre, "Freno")     || strstr(nombre, "freno"))     return "🛑";
    if (strstr(nombre, "Luz")       || strstr(nombre, "luz"))       return "💡";
    if (strstr(nombre, "Bomba")     || strstr(nombre, "bomba"))     return "💨";
    
    return "🛠️";
}

caja_repuestos_t* inicializar_caja_ejemplo() {
    caja_repuestos_t* caja = caja_repuestos_crear();
    if (!caja) return NULL;
    repuesto_t r1 = {"Tornillo", 15000, 20, false, 1};
    caja_repuestos_apilar(caja, r1);
    repuesto_t r2 = {"Tornillo", 14500, 45, false, 2};
    caja_repuestos_apilar(caja, r2);
    repuesto_t r3 = {"Manubrio playero", 1000, 150, false, 3};
    caja_repuestos_apilar(caja, r3);
    repuesto_t r4 = {"Cadena oxidada", 5500, 80, true, 4};
    caja_repuestos_apilar(caja, r4);
    repuesto_t r5 = {"Tuerca vieja", 3000, 55, true, 5};
    caja_repuestos_apilar(caja, r5);
    repuesto_t r6 = {"Pedal roto", 20000, 100, false, 6};
    caja_repuestos_apilar(caja, r6);
    repuesto_t r7 = {"Asiento desgastado", 25000, 60, true, 7};
    caja_repuestos_apilar(caja, r7);
    repuesto_t r8 = {"Rueda pinchada", 40000, 500, false, 8};
    caja_repuestos_apilar(caja, r8);
    repuesto_t r9 = {"Freno Nuevo", 15000, 50, false, 9};
    caja_repuestos_apilar(caja, r9);
    repuesto_t r10 = {"Luz trasera", 8000, 30, false, 10};
    caja_repuestos_apilar(caja, r10);
    repuesto_t r11 = {"Luz delantera", 12000, 30, false, 11};
    caja_repuestos_apilar(caja, r11);
    repuesto_t r12 = {"Bomba de aire", 18000, 40, false, 12};
    caja_repuestos_apilar(caja, r12);

    return caja;
}

void imprimir_repuesto_formateado(repuesto_t rep) {
    const char* emoji = obtener_emoji(rep.nombre);
    printf("| %s | ID: %-3d | %-20s | Cód: %-5d | Tam: %-3d mm | Oxidado: %-3s |\n",
           emoji,
           rep.id_repuesto, 
           rep.nombre, 
           rep.codigo, 
           rep.tamanio, 
           rep.oxidado ? "SI" : "NO");
}

void imprimir_caja(caja_repuestos_t* caja) {
    if (!caja || caja_repuestos_vacia(caja)) {
        printf("\n[!] La caja de repuestos está vacía o no existe.\n\n");
        return;
    }
    caja_repuestos_t* caja_aux = caja_repuestos_crear();
    if (!caja_aux) return;

    printf("\n=========================== CAJA DE REPUESTOS ===========================\n");
    while (!caja_repuestos_vacia(caja)) {
        repuesto_t* rep = caja_repuestos_desapilar(caja);
        if (rep != NULL) {
            imprimir_repuesto_formateado(*rep);
            caja_repuestos_apilar(caja_aux, *rep);
            free(rep);
        }
    }
    printf("========================================================================================\n\n");
    while (!caja_repuestos_vacia(caja_aux)) {
        repuesto_t* rep_aux = caja_repuestos_desapilar(caja_aux);
        if (rep_aux != NULL) {
            caja_repuestos_apilar(caja, *rep_aux);
            free(rep_aux);
        }
    }
    caja_repuestos_destruir(caja_aux);
}

//Pre: El campo nombre tiene que ser un string.
//Post: devuelve true si el repuesto no es un tornillo o no tiene un codigo mayor a 13000
bool tornillo_valido(repuesto_t repuesto){
    return !((strcmp(repuesto.nombre, TORNILLO) == 0) && repuesto.codigo > CODIGO_MAXIMO);
}

//Pre: -
//Post: devuelve true si el repuesto no tiene mas de 50mm o no esta oxidado.
bool repuesto_valido(repuesto_t repuesto){
    return !(repuesto.tamanio > TAMANIO_MAXIMO && repuesto.oxidado);
}

//Pre: caja nelson tiene que estar creado con caja_repuestos_crear.
//Post: Actualiza la caja de nelson descartando los repuestos que no son validos para repuesto valido y tornillo valido. Se libera la memoria de los repuestos invalidos.

void actualizar_repuestos(caja_repuestos_t* caja_nelson){
    caja_repuestos_t* caja_aux = caja_repuestos_crear();

    while (!caja_repuestos_vacia(caja_nelson)){
        repuesto_t* repuesto_actual = caja_repuestos_desapilar(caja_nelson);

        if(tornillo_valido(*repuesto_actual) && repuesto_valido(*repuesto_actual)){
            caja_repuestos_apilar(caja_aux, *repuesto_actual);
        }
        else{
            free(repuesto_actual);
        }
    }

    while (!caja_repuestos_vacia(caja_aux)){
        repuesto_t* repuesto_actual = caja_repuestos_desapilar(caja_aux);
        caja_repuestos_apilar(caja_nelson, *repuesto_actual);
    }
    
    caja_repuestos_destruir(caja_aux);
}


// Pre: recibe una bandeja válida creada con bandeja_crear()
// Post: carga pedidos en la bandeja
void cargar_pedidos(bandeja_t* bandeja){
    pedido_mail_t pedidos[] = {
        {1, 10, "ana@mail.com",    false, NULL},  // válido, repuesto 10 EN caja   → se repara
        {2, 5,  "spam@mail.com",   true,  NULL},  // spam                          → descartado
        {3, -1, "luis@mail.com",   false, NULL},  // id_repuesto inválido           → descartado
        {4, 9,  "carlos@mail.com", false, NULL},  // válido, repuesto 9 EN caja    → se repara
        {5, 7,  "marta@mail.com",  false, NULL},  // válido, repuesto 7 NO en caja → no se repara
        {6, 6,  "pedro@mail.com",  false, NULL},  // válido, repuesto 6 EN caja    → se repara
    };

    for (int i = 0; i < 6; i++)
        bandeja_agregar_al_final(bandeja, pedidos[i]);
}


bool mail_valido(pedido_mail_t* mail){
    return !mail->es_spam && mail->id_repuesto > MIN_REPUESTO;
}

// PRE: bandeja fue creada correctamente con bandeja_crear()
// POST: descarta los mails que sean spam o que tengan un id de repuesto inválido y contesta los que son válidos. Devuelve una bandeja con los mails válidos y NULL en caso de error.
bandeja_t* administrar_mails(bandeja_t* bandeja) {

    bandeja_t* bandeja_aux = bandeja_crear();
    if (!bandeja_aux){
        printf("Hubo un error creando la bandea auxiliar\n");
        return NULL;
    }

    while(bandeja_primero(bandeja)) {
        pedido_mail_t* mail = bandeja_quitar_primero(bandeja);

        if(mail_valido(mail)){
            bandeja_responder_cliente(mail->mail_cliente, RESPUESTA_AUTOMATICA);
            bandeja_agregar_al_final(bandeja_aux, *mail);
        }

        free(mail);
    }

    bandeja_destruir(bandeja);

    return bandeja_aux;
}

// pre: bandeja creada con bandeja_crear y bicicletas creada con cola_bicicletas_crear y no pueden ser NULL.
// post: agrega los pedidos de la bandeja en ´bicicletas´
void procesar_pedidos(bandeja_t* bandeja, cola_bicicletas_t* bicicletas){
    pedido_mail_t* mail = bandeja_primero(bandeja);
    while(mail){
        bicicleta_t bici;
        bici.arreglada = false;
        bici.id_bicicleta = mail->id_bicicleta;
        bici.id_repuesto = mail->id_repuesto;

        cola_bicicletas_encolar(bicicletas, bici);
        mail = mail->siguiente;
    }
}

// pre: caja creada con caja_repuestos_crear, no puede ser NULL.
// post: devuelve true si hay un repuesto en la caja que coincida con el repuesto que necesita la bicicleta, si lo hay lo saca de la caja. False si no.
bool hay_repuesto(caja_repuestos_t* caja, bicicleta_t bici){
    caja_repuestos_t* aux = caja_repuestos_crear();
    if(!aux){
        return false;
    }
    bool repuesto_encontrado = false;
    while(!caja_repuestos_vacia(caja) && !repuesto_encontrado){
        repuesto_t* repuesto = caja_repuestos_desapilar(caja);
        if(repuesto->id_repuesto == bici.id_repuesto){
            repuesto_encontrado = true;
            free(repuesto);
        }else{
            caja_repuestos_apilar(aux, *repuesto);
        }
    }

    while(!caja_repuestos_vacia(aux)){
        repuesto_t* repuesto = caja_repuestos_desapilar(aux);
        caja_repuestos_apilar(caja, *repuesto);
    }

    caja_repuestos_destruir(aux);

    return repuesto_encontrado;
}

// pre: bicicletas creada con cola_bicicletas_crear y caja creada con caja_repuestos_crear, no pueden ser NULL.
// post: marca como arregladas las bicicletas si hay el repuesto que necesita.
int arreglar_bicicletas(cola_bicicletas_t* bicicletas, caja_repuestos_t* caja){
    cola_bicicletas_t* aux = cola_bicicletas_crear();
    if(!aux){
        printf("Hubo un error al crear la cola de bicicletas auxiliar");
        return ERROR;
    }

    while(!cola_bicicletas_vacia(bicicletas)){
        bicicleta_t* bici = cola_bicicletas_desencolar(bicicletas);
        if(hay_repuesto(caja, *bici)){
            bici->arreglada = true;
        }

        cola_bicicletas_encolar(aux, *bici);
    }

    while(!cola_bicicletas_vacia(aux)){
        bicicleta_t* bici = cola_bicicletas_desencolar(aux);
        cola_bicicletas_encolar(bicicletas, *bici);
    }

    cola_bicicletas_destruir(aux);
    return EXITO;
}

int main(){
    caja_repuestos_t* caja_nelson = inicializar_caja_ejemplo();
    if (!caja_nelson) {
        printf("Error al crear la caja de repuestos.\n");
        return -1;
    }

    actualizar_repuestos(caja_nelson);

    bandeja_t* bandeja = bandeja_crear();
    if (!bandeja){
        printf("Hubo un error creando una bandeja nueva\n");
        return ERROR;
    }

    cargar_pedidos(bandeja);

    bandeja = administrar_mails(bandeja);

    cola_bicicletas_t* bicicletas = cola_bicicletas_crear();
    if(!bicicletas){
        printf("Error al crear la cola de bicicletas.\n");
        return -1;
    }

    procesar_pedidos(bandeja, bicicletas);

    imprimir_bicicletas(bicicletas, "Antes de la reparación");

    arreglar_bicicletas(bicicletas, caja_nelson);

    imprimir_bicicletas(bicicletas, "Después de la reparación");

    cola_bicicletas_destruir(bicicletas);
    bandeja_destruir(bandeja);
    caja_repuestos_destruir(caja_nelson);

    return 0;
}