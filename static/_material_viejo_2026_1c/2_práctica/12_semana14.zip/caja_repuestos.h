#ifndef CAJA_REPUESTOS_H
#define CAJA_REPUESTOS_H


#include <stdbool.h>

#define MAX_NOMBRE 50

typedef struct repuesto {
   char nombre[MAX_NOMBRE];
   int codigo;
   int tamanio;      // en mm
   bool oxidado;
   int id_repuesto;
} repuesto_t;


typedef struct caja_repuestos caja_repuestos_t;


/*
* Pre: -
* Post: Crea una caja de repuestos vacía.
*/
caja_repuestos_t* caja_repuestos_crear();


/*
* Pre: caja válida.
* Post: Libera toda la memoria utilizada.
*/
void caja_repuestos_destruir(caja_repuestos_t* caja);


/*
* Pre: caja válida.
* Post: Apila un repuesto.
*/
void caja_repuestos_apilar(caja_repuestos_t* caja, repuesto_t repuesto);


/*
* Pre: caja válida y no vacía.
* Post: Desapila el repuesto del tope y devuelve un
* puntero reservado dinámicamente.
*/
repuesto_t* caja_repuestos_desapilar(caja_repuestos_t* caja);


/*
* Pre: caja válida.
* Post: Devuelve el repuesto del tope o NULL.
*/
repuesto_t* caja_repuestos_tope(caja_repuestos_t* caja);


/*
* Pre: caja válida.
* Post: Devuelve true si está vacía.
*/
bool caja_repuestos_vacia(caja_repuestos_t* caja);


#endif
