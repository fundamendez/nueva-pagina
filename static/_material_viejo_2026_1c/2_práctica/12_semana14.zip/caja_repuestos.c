// caja_repuestos.c
#include "caja_repuestos.h"
#include <stdlib.h>
#include <string.h>

typedef struct nodo {
    repuesto_t repuesto;
    struct nodo* anterior;
} nodo_t;

struct caja_repuestos {
    nodo_t* tope;
};

caja_repuestos_t* caja_repuestos_crear() {
    caja_repuestos_t* caja = malloc(sizeof(caja_repuestos_t));
    if (!caja) return NULL;
    caja->tope = NULL;
    return caja;
}

void caja_repuestos_destruir(caja_repuestos_t* caja) {
    nodo_t* actual = caja->tope;
    while (actual) {
        nodo_t* anterior = actual->anterior;
        free(actual);
        actual = anterior;
    }
    free(caja);
}

void caja_repuestos_apilar(caja_repuestos_t* caja, repuesto_t repuesto) {
    nodo_t* nodo = malloc(sizeof(nodo_t));
    if (!nodo) return;
    nodo->repuesto = repuesto;
    nodo->anterior = caja->tope;
    caja->tope = nodo;
}

repuesto_t* caja_repuestos_desapilar(caja_repuestos_t* caja) {
    if (!caja->tope) return NULL;
    nodo_t* nodo = caja->tope;
    repuesto_t* repuesto = malloc(sizeof(repuesto_t));
    if (!repuesto) return NULL;
    *repuesto = nodo->repuesto;
    caja->tope = nodo->anterior;
    free(nodo);
    return repuesto;
}

repuesto_t* caja_repuestos_tope(caja_repuestos_t* caja) {
    if (!caja->tope) return NULL;
    return &caja->tope->repuesto;
}

bool caja_repuestos_vacia(caja_repuestos_t* caja) {
    return caja->tope == NULL;
}