#include "vector_din.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// --- Definición interna del TDA ---
struct vector_din {
    producto_tomacco_t* datos;
    size_t cantidad;
    size_t capacidad;
};

// --- Implementación básica del TDA ---

vector_din_t* vec_crear() {
    vector_din_t* vec = malloc(sizeof(vector_din_t));
    if (!vec) return NULL;
    vec->datos = malloc(sizeof(producto_tomacco_t) * 4);
    if (!vec->datos) {
        free(vec);
        return NULL;
    }
    vec->cantidad = 0;
    vec->capacidad = 4;
    return vec;
}

void vec_destruir(vector_din_t* vec) {
    if (!vec) return;
    free(vec->datos);
    free(vec);
}

bool vec_guardar(vector_din_t* vec, producto_tomacco_t producto) {
    if (!vec) return false;
    if (vec->cantidad == vec->capacidad) {
        size_t nueva_cap = vec->capacidad * 2;
        producto_tomacco_t* nuevo = realloc(vec->datos, nueva_cap * sizeof(producto_tomacco_t));
        if (!nuevo) return false;
        vec->datos = nuevo;
        vec->capacidad = nueva_cap;
    }
    vec->datos[vec->cantidad++] = producto;
    return true;
}

producto_tomacco_t* vec_obtener(vector_din_t* vec, size_t pos) {
    if (!vec || pos >= vec->cantidad) return NULL;
    return &vec->datos[pos];
}

bool vec_eliminar(vector_din_t* vec, size_t pos) {
    if (!vec || pos >= vec->cantidad) return false;
    for (size_t i = pos; i < vec->cantidad - 1; i++) {
        vec->datos[i] = vec->datos[i + 1];
    }
    vec->cantidad--;
    return true;
}

size_t vec_largo(vector_din_t* vec) {
    return vec ? vec->cantidad : 0;
}

void vec_imprimir(vector_din_t* vec) {
    if (!vec) return;
    for (size_t i = 0; i < vec->cantidad; i++) {
        producto_tomacco_t p = vec->datos[i];
        printf("[%zu] %s | Adiccion: %d",
               i, p.nombre, p.nivel_adiccion);
        if (p.aprobado_por_lisa) printf(" | Aprobado por Lisa \n");
        else printf(" | Sin aprobar\n");
    }
}