#ifndef VECTOR_DIN_H
#define VECTOR_DIN_H

#include <stdbool.h>
#include <stddef.h>

#define MAX_NOMBRE 100

typedef struct producto_tomacco {
     char nombre[MAX_NOMBRE];
     int nivel_adiccion; // 1-10
     bool aprobado_por_lisa;
} producto_tomacco_t;

/* Interfaz de un vector dinámico de pedidos.
Las posiciones del vector se numeran desde 0. */
struct vector_din;
typedef struct vector_din vector_din_t;

// Post: Crea un vector dinámico de pedidos. Devuelve un puntero a un vector vacío.
// Al terminar de usarlo este vector debe ser destruido con vec_destruir().
// Devuelve NULL si no se pudo crear el vector.
vector_din_t* vec_crear();

// Pre: `vec` fue creado usando vec_crear().
// Post: Destruye el vector.
void vec_destruir(vector_din_t* vec);

// Pre: `vec` fue creado usando vec_crear().
// Post: Agrega un pedido al final del vector.
// Devuelve true si se pudo agregar, false en caso contrario.
bool vec_guardar(vector_din_t* vec, producto_tomacco_t producto);

// Pre: `vec` fue creado usando vec_crear().
// Post: Devuelve un puntero al elemento en la posición `pos` del vector.
// Si `pos` es inválida, devuelve NULL.
// Una posición es inválida si es mayor o igual al largo del vector.
producto_tomacco_t* vec_obtener(vector_din_t* vec, size_t pos);

// Pre: `vec` fue creado usando vec_crear().
// Post: Elimina el pedido en la posición `pos` del vector.
// Devuelve true si se pudo eliminar, false si la posición es inválida.
bool vec_eliminar(vector_din_t* vec, size_t pos);

// Pre: `vec` fue creado usando vec_crear().
// Post: Devuelve la cantidad de elementos en el vector.
size_t vec_largo(vector_din_t* vec);

// Pre: `vec` fue creado usando vec_crear().
// Post: Imprime los elementos del vector en orden.
void vec_imprimir(vector_din_t* vec);

#endif