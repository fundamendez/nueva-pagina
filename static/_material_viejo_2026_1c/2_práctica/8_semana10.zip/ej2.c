#include <stdio.h>
#include "vector_din.h"

const int ERROR = -1;
const int CAPACIDAD_ADICCION_MAX = 3;

bool se_vende_legalmente(bool aprobado_por_lisa, int nivel_adiccion) {
    return nivel_adiccion <= CAPACIDAD_ADICCION_MAX && aprobado_por_lisa;
}   

// Precondiciones: productos debe estar creado con vec_crear e inicializado correctamente.
// Postcondiciones: Devuelve la cantidad de productos vendibles en productos.
int cantidad_productos_vendibles(vector_din_t* productos){
    int productos_vendibles = 0;
    size_t tope = vec_largo(productos);
    int posicion = 0;
    bool es_producto_valido = true;

    while(posicion < tope && es_producto_valido) {
        producto_tomacco_t* producto_actual = vec_obtener(productos, posicion);
        if (!producto_actual) {
            es_producto_valido = false;
        } else {
            if (se_vende_legalmente(producto_actual->aprobado_por_lisa, producto_actual->nivel_adiccion)){
                productos_vendibles++;
            }
        }
        posicion++;
    }
    return productos_vendibles;
}


// Precondiciones: productos debe estar creado con vec_crear e inicializado correctamente.
// Postcondiciones: elimina los productos peligrosos de productos.
void eliminar_productos_peligrosos(vector_din_t* productos, int adiccion_peligrosa) {
    int posicion = 0;
    bool es_producto_valido = true;
    bool se_pudo_eliminar = true;

    while(posicion < vec_largo(productos) && es_producto_valido && se_pudo_eliminar) {
        producto_tomacco_t* producto_actual = vec_obtener(productos, posicion);
        if (!producto_actual) {
            es_producto_valido = false;
        } else {
            if (producto_actual->nivel_adiccion <= adiccion_peligrosa) {
                se_pudo_eliminar = vec_eliminar(productos, posicion);
            } else {
                posicion++;
            }
        }
    }
}

void agregar_productos(vector_din_t* productos, int tope_productos, vector_din_t* productos_concatenados) {
    int posicion = 0;
    bool es_producto_valido = true;
    bool se_pudo_agregar = true;

    while(posicion < tope_productos && es_producto_valido) {
        producto_tomacco_t* producto_actual = vec_obtener(productos, posicion);
        if (!producto_actual) {
            es_producto_valido = false;
        } else {
            producto_tomacco_t producto_a_agregar = (*producto_actual); 
            se_pudo_agregar = vec_guardar(productos_concatenados, producto_a_agregar);
        }
        posicion++;
    }
}

// Precondiciones: productos1 y productos2 deben estar creados con vec_crear e inicializados correctamente.
// Postcondiciones: devuelve un nuevo vector dinámico con todos los productos de productos1 y productos2.
vector_din_t* concatenar_productos(vector_din_t* productos1, vector_din_t* productos2) {
    vector_din_t* productos_concatenados = vec_crear();
    if (!productos_concatenados) {
        printf("Ocurrio un error al crear el vector dinámico\n");
        return NULL;
    }

    int tope_productos1 = vec_largo(productos1);
    int tope_productos2 = vec_largo(productos2);
    
    agregar_productos(productos1, tope_productos1, productos_concatenados);
    agregar_productos(productos2, tope_productos2, productos_concatenados);
    
    return productos_concatenados;
}

int main() {
    // ================== PRIMER PUNTO ==================
    /*
    vector_din_t* productos = vec_crear();
    if(!productos){ //productos == NULL
        return ERROR;
    }

    producto_tomacco_t p1 = {"Tomacco simple", 1, true};
    producto_tomacco_t p2 = {"Salsa de tomacco", 2, false};
    producto_tomacco_t p3 = {"Chicle de tomacco", 8, false};
    producto_tomacco_t p4 = {"Jugo de tomacco", 6, true};
    producto_tomacco_t p5 = {"Mermelada de tomacco", 3, true};

    vec_guardar(productos, p1);
    vec_guardar(productos, p2);
    vec_guardar(productos, p3);
    vec_guardar(productos, p4);
    vec_guardar(productos, p5);

    printf("=== Productos originales ===\n");
    vec_imprimir(productos);

    printf("\nHomero puede vender %i productos.\n", cant_productos_vendibles(productos));
    */


	// ================== SEGUNDO PUNTO ==================
	/*
    if(!eliminar_productos_peligrosos(productos, 5)){
        printf("No se pudieron borrar los productos peligrosos\n");
    }
    printf("\n=== Productos sin peligrosos ===\n");
    vec_imprimir(productos);
    */


    // ================== TERCER PUNTO ==================
	/*
    vector_din_t* otros_productos = vec_crear();
    if(!otros_productos){ //otros_productos == NULL
        vec_destruir(productos);
        return ERROR;
    }

    producto_tomacco_t p6 = {"Tomacco premium", 1, true};
    producto_tomacco_t p7 = {"Salsa de tomacco premium", 2, false};

    vec_guardar(otros_productos, p6);
    vec_guardar(otros_productos, p7);

    printf("\n=== Otros productos ===\n");
    vec_imprimir(otros_productos);

    vector_din_t* productos_unidos = unir_vectores_productos(productos, otros_productos);
    if (!productos_unidos){
        vec_destruir(productos);
        vec_destruir(otros_productos);
        return ERROR;
    }
    printf("\n=== Productos unidos ===\n");
    vec_imprimir(productos_unidos);

    vec_destruir(productos);
    vec_destruir(otros_productos);
    vec_destruir(productos_unidos);
    */
    return 0;
}