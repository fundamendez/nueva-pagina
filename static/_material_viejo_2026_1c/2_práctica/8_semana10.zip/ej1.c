#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

#define MAX_DESCRIPCION 100
#define MAX_NOMBRE 100
const int CANTIDAD_INICIAL_ZONAS =  10;
const int NIVEL_RIESGO_MIN = 5;
const int REPORTES_INVALIDOS = -1;

typedef struct reporte {
    char descripcion[MAX_DESCRIPCION];
     int nivel_riesgo; // 1-10
    bool confirmado;
} reporte_t;

typedef struct zona {
    char nombre_zona[MAX_NOMBRE];
    reporte_t* reportes;
    int cantidad_reportes;
    bool vigilancia_activa;
} zona_t;

//Pre: nombre es un string
//Post: Crea una zona nueva sin reportes y con reportes en null.
zona_t reservar_zona(char nombre_zona[MAX_NOMBRE], bool vigilancia_activa) {
    zona_t zona;
    strcpy(zona.nombre_zona, nombre_zona);
    zona.vigilancia_activa = vigilancia_activa;
    zona.reportes = NULL;
    zona.cantidad_reportes = 0;
    return zona;
}

// Pre: zona y reporte deben estar correctamente inicializados.
// Post: 
void registrar_reporte(zona_t* zona, reporte_t reporte) {
    reporte_t* nuevos_reportes = realloc(zona->reportes,  sizeof(reporte_t) * (zona->cantidad_reportes + 1));
    if (nuevos_reportes == NULL) {
        return;
    }

    zona->reportes = nuevos_reportes;
    zona->reportes[zona->cantidad_reportes] = reporte;
    zona->cantidad_reportes++;
}

// Pre:
// Post:
zona_t* crear_zonas() {
    zona_t* zonas = malloc(sizeof(zona_t)*CANTIDAD_INICIAL_ZONAS);
    if (zonas == NULL) {
        return NULL;
    }
    return zonas;
}

// Pre: 
// Post: 
void zona_mas_conflictiva(zona_t* zonas, int cantidad_zonas, char nombre_zona_mas_conflictiva[MAX_NOMBRE]) {
    int mayor_reportes_confirmados = REPORTES_INVALIDOS;
    for(int i = 0; i < cantidad_zonas; i++){
        int cantidad_reportes_confirmados = 0;
        for (int j = 0; j < zonas[i].cantidad_reportes; j++){
            if (zonas[i].reportes[j].confirmado && zonas[i].reportes[j].nivel_riesgo > NIVEL_RIESGO_MIN){
                cantidad_reportes_confirmados++;
            }
        }
        if (cantidad_reportes_confirmados > mayor_reportes_confirmados) {
            mayor_reportes_confirmados = cantidad_reportes_confirmados;
            strcpy(nombre_zona_mas_conflictiva, zonas[i].nombre_zona);
        }
    }
}

// Pre:
// Post:
void destruir_zonas(zona_t* zonas, int cantidad_zonas) {
    for (int i = 0; i < cantidad_zonas; i ++) {
        if (zonas[i].reportes != NULL) {
            free(zonas[i].reportes);
        }
    }
    free(zonas);
}

int main() {
    zona_t* zonas = crear_zonas();

    zonas[0] = reservar_zona("Planta Nuclear", true);
    zonas[1] = reservar_zona("Taberna de Moe", true);
    zonas[2] = reservar_zona("Escuela Primaria de Springfield", false);

    zonas[0].reportes = malloc(sizeof(reporte_t) * 3);
    zonas[1].reportes = malloc(sizeof(reporte_t) * 3);
    zonas[2].reportes = malloc(sizeof(reporte_t) * 2);

    
    reporte_t reporte1 = {"Fuga radioactiva", 8, true};
    reporte_t reporte2 = {"Homero durmiendo en el trabajo", 9, true};
    reporte_t reporte3 = {"Pez de tres ojos encontrado", 10, false};

    zonas[0].reportes[0] = reporte1;
    zonas[0].reportes[1] = reporte2;
    zonas[0].reportes[2] = reporte3;
    zonas[0].cantidad_reportes = 3;

    
    reporte_t reporte4 = {"Pelea entre Barney y Homero", 6, true};
    reporte_t reporte5 = {"Lenny rompio una mesa", 7, true};
    reporte_t reporte6 = {"Moe amenaza a un cliente", 8, true};

    zonas[1].reportes[0] = reporte4;
    zonas[1].reportes[1] = reporte5;
    zonas[1].reportes[2] = reporte6;
    zonas[1].cantidad_reportes = 3;

    
    reporte_t reporte7 = {"Bart hizo sonar la alarma", 4, true};
    reporte_t reporte8 = {"Skinner encontro petardos", 9, true};

    zonas[2].reportes[0] = reporte7;
    zonas[2].reportes[1] = reporte8;
    zonas[2].cantidad_reportes = 2;

    char nombre_zona_mas_conflictiva[MAX_NOMBRE];

    zona_mas_conflictiva(zonas, 3, nombre_zona_mas_conflictiva);

    printf("=== SISTEMA DE MONITOREO DE SPRINGFIELD ===\n\n");

    printf("Se crean las zonas vigiladas por la policia de Springfield...\n");
    printf("- Planta Nuclear\n");
    printf("- Taberna de Moe\n");
    printf("- Escuela Primaria de Springfield\n\n");

    printf("Registrando reportes...\n\n");

    printf("[Planta Nuclear]\n");
    printf("-> Reporte confirmado | Riesgo: 8\n");
    printf("-> Reporte confirmado | Riesgo: 9\n");
    printf("-> Reporte NO confirmado | Riesgo: 10\n\n");

    printf("[Taberna de Moe]\n");
    printf("-> Reporte confirmado | Riesgo: 6\n");
    printf("-> Reporte confirmado | Riesgo: 7\n");
    printf("-> Reporte confirmado | Riesgo: 8\n\n");

    printf("[Escuela Primaria de Springfield]\n");
    printf("-> Reporte confirmado | Riesgo: 4\n");
    printf("-> Reporte confirmado | Riesgo: 9\n\n");

    printf("Resumen de reportes criticos (>5 y confirmados):\n");
    printf("- Planta Nuclear: 2 reportes\n");
    printf("- Taberna de Moe: 3 reportes\n");
    printf("- Escuela Primaria: 1 reporte\n\n");

    printf("El jefe Gorgory analiza las zonas conflictivas...\n\n");

    printf("La zona con mayor cantidad de reportes peligrosos es: %s\n", nombre_zona_mas_conflictiva);

    printf("\nGorgory: \"¡Esta ciudad se esta yendo al demonio!\"\n");

    //destruir_zonas(zonas,3);

    return 0;
}
