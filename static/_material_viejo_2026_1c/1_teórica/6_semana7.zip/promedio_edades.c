#include <stdio.h>
#include <stdlib.h>

// Precondiciones: 'descripcion' tiene que ser un string finalizar con '\0').
//                 'cantidad' es un puntero válido (no NULL).
// Postcondiciones: Solicita al usuario mostrando por pantalla 'descripcion' y *cantidad contiene un entero > 0 ingresado por el usuario.
void pedir_cantidad_natural(int* cantidad, char descripcion[]) {
    printf("%s\n", descripcion);
    scanf("%i", cantidad);

    while((*cantidad) <= 0) {
        printf("Cantidad ingresada inválida. Ingrese un valor entero positivo\n%s\n", descripcion);
        scanf("%i", cantidad);
    }
}

// Precondiciones: cantidad_alumnos > 0.
//                 edades_alumnos apunta a un arreglo de al menos cantidad_alumnos elementos.
// Postcondiciones: edades_alumnos queda cargado con las edades de los alumnos.
void pedir_edades_alumnos(int cantidad_alumnos, int* edades_alumnos) {
    for (int i = 0; i < cantidad_alumnos; i++) {
        pedir_cantidad_natural(&edades_alumnos[i], "¿Cuál es la edad del alumno?");
    }
}

// Precondiciones: cantidad_alumnos debe ser > 0. 
// Postcondiciones: promedio_edades contiene el promedio truncado (división entera) de los valores de edades_alumnos
void calcular_promedio_edades(int cantidad_alumnos, int* edades_alumnos, int* promedio_edades) {
    int suma_edades_alumnos = 0;
    for (int i = 0; i < cantidad_alumnos; i++) {
        suma_edades_alumnos += edades_alumnos[i];
    }

    (*promedio_edades) = suma_edades_alumnos / cantidad_alumnos;

}

int main() {
    int cantidad_alumnos = 0;
    pedir_cantidad_natural(&cantidad_alumnos, "¿Cuántos alumnos hay en el aula?");

    int* edades_alumnos = malloc(cantidad_alumnos * sizeof(int));
    if (!edades_alumnos) {
        printf("Ocurrio un error de memoria :/");
        return -1;
    }

    pedir_edades_alumnos(cantidad_alumnos,edades_alumnos);

    int promedio_edades = 0;

    calcular_promedio_edades(cantidad_alumnos,edades_alumnos, &promedio_edades);

    printf("Edad promedio del aula: %i años\n", promedio_edades);

    free(edades_alumnos);
    return 0;
}