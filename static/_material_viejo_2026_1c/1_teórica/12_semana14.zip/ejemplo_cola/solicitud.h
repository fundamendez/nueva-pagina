#ifndef SOLICITUD_H
#define SOLICITUD_H

#include "ticketera.h"

/*
 * EJERCICIO 1
 *
 * Pre: ticketera fue creada correctamente.
 * Post: devuelve la primera solicitud exitosa manteniendo
 *       el contenido original de la ticketera.
 */
solicitud_t primera_solicitud_exitosa(ticketera_t* ticketera);

/*
 * EJERCICIO 2
 *
 * Pre: ticketera fue creada correctamente.
 * Post: devuelve el porcentaje de solicitudes exitosas.
 *       La ticketera queda igual que al inicio.
 */
float porcentaje_solicitudes_exitosas(ticketera_t* ticketera);

/*
 * EJERCICIO 3
 *
 * Pre: ticketera fue creada correctamente.
 * Post: elimina las solicitudes rechazadas manteniendo
 *       el orden de las exitosas.
 */
void eliminar_solicitudes_rechazadas(ticketera_t* ticketera);

#endif
