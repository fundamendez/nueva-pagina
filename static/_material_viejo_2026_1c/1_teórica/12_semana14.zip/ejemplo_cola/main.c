#include <stdio.h>
#include <string.h>

#include "ticketera.h"
#include "solicitud.h"


void imprimir_cola(ticketera_t* ticketera)
{
    ticketera_t* auxiliar = ticketera_crear();

    printf("Contenido de la cola:\n");

    while (!ticketera_esta_vacia(ticketera)) {
        solicitud_t solicitud = ticketera_primero(ticketera);

        printf("  - pago_aprobado: %s, beneficios: %d",
               solicitud.pago_aprobado ? "true" : "false",
               solicitud.cantidad_beneficios_utilizados);

        if (solicitud.cantidad_beneficios_utilizados > 0) {
            printf(", primer beneficio: %s", solicitud.beneficios_utilizados[0]);
        }

        printf("\n");

        ticketera_encolar(auxiliar, solicitud);
        ticketera_descolar(ticketera);
    }

    while (!ticketera_esta_vacia(auxiliar)) {
        ticketera_encolar(ticketera, ticketera_primero(auxiliar));
        ticketera_descolar(auxiliar);
    }

    ticketera_destruir(auxiliar);
}

void cargar_solicitudes(ticketera_t* ticketera)
{
    solicitud_t s1 = {
        .pago_aprobado = false,
        .cantidad_beneficios_utilizados = 5
    };

    solicitud_t s2 = {
        .pago_aprobado = true,
        .cantidad_beneficios_utilizados = 4
    };
    strcpy(s2.beneficios_utilizados[0], "AccesoAnticipado");

    solicitud_t s3 = {
        .pago_aprobado = false,
        .cantidad_beneficios_utilizados = 8
    };

    solicitud_t s4 = {
        .pago_aprobado = true,
        .cantidad_beneficios_utilizados = 6
    };
    strcpy(s4.beneficios_utilizados[0], "AccesoAnticipado");

    ticketera_encolar(ticketera, s1);
    ticketera_encolar(ticketera, s2);
    ticketera_encolar(ticketera, s3);
    ticketera_encolar(ticketera, s4);
}

int main()
{
    ticketera_t* ticketera = ticketera_crear();

    cargar_solicitudes(ticketera);

    printf("=== ESTADO INICIAL ===\n");
    imprimir_cola(ticketera);
    printf("\n");

    printf("=== EJERCICIO 1 ===\n");
    solicitud_t primera = primera_solicitud_exitosa(ticketera);
    printf("Primera solicitud exitosa - pago_aprobado: %s\n",
           primera.pago_aprobado ? "true" : "false");
    imprimir_cola(ticketera);
    printf("\n");

    printf("=== EJERCICIO 2 ===\n");
    float porcentaje = porcentaje_solicitudes_exitosas(ticketera);
    printf("Porcentaje de solicitudes exitosas: %.2f%%\n",
           porcentaje);
    imprimir_cola(ticketera);
    printf("\n");

    printf("=== EJERCICIO 3 ===\n");
    eliminar_solicitudes_rechazadas(ticketera);
    printf("Solicitudes rechazadas eliminadas\n");
    imprimir_cola(ticketera);
    printf("\n");

    ticketera_destruir(ticketera);

    return 0;
}
