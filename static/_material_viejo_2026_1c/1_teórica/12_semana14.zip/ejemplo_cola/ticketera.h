#ifndef TICKETERA_H
#define TICKETERA_H

#include <stdbool.h>

#define MAX_BENEFICIOS 10
#define MAX_NOMBRE_BENEFICIO 50

typedef struct solicitud {
    bool pago_aprobado;
    bool es_miembro_club_fans;
    char beneficios_utilizados[MAX_BENEFICIOS][MAX_NOMBRE_BENEFICIO];
    int cantidad_beneficios_utilizados;
} solicitud_t;

typedef struct ticketera ticketera_t;

/* Pre condiciones:
 * Post condiciones: Crea una cola vacía. Devuelve NULL en caso de error.
 */
ticketera_t* ticketera_crear();

/* Pre condiciones: ticketera debe apuntar a una cola creada con `ticketera_crear`.
 * Post condiciones: Encola una solicitud. Devuelve true si pudo encolar,
 *                   false en caso contrario.
 */
bool ticketera_encolar(ticketera_t* ticketera, solicitud_t nueva_solicitud);

/* Pre condiciones: ticketera debe apuntar a una cola creada con `ticketera_crear`.
 * Post condiciones: Desencola el primer elemento de ticketera.
 *                   Devuelve true si se pudo desencolar,
 *                   false si la cola estaba vacía.
 */
bool ticketera_descolar(ticketera_t* ticketera);

/* Pre condiciones: ticketera debe apuntar a una cola creada con `ticketera_crear`.
 * Post condiciones: Devuelve el primer elemento de ticketera sin desencolarlo.
 *                   O una solicitud inválida en caso de error o cola vacía.
 */
solicitud_t ticketera_primero(const ticketera_t* ticketera);

/* Pre condiciones: ticketera debe apuntar a una cola creada con `ticketera_crear`.
 * Post condiciones: Devuelve true si ticketera está vacía,
 *                   false en caso contrario.
 */
bool ticketera_esta_vacia(const ticketera_t* ticketera);

/* Pre condiciones: ticketera debe apuntar a una cola creada con `ticketera_crear`.
 * Post condiciones: Destruye ticketera y libera la memoria.
 */
void ticketera_destruir(ticketera_t* ticketera);

#endif
