// Marge fue a hacer la compra mensual a Kwik-E-Mart porque se enteró que había descuentos en compras grandes: si gastas más de $100.000, tenés un 20% de descuento pagando en efectivo.
// Crear un programa que le pregunte a Marge el total de su compra en Kwik-E-Mart y qué medio de pago usó (los disponibles son: (E)Efectivo, (C)Crédito o (D)Débito) y calcule cuánto debe pagar finalmente.
#include<stdio.h>
#include<stdbool.h>

const int MIN_GASTO_OFERTA = 100000;
const char EFECTIVO = 'E';
const char DEBITO = 'D';
const char CREDITO = 'C';
const char MEDIO_PAGO_OFERTA = EFECTIVO;
const int DESCUENTO = 20;

bool es_medio_pago_valido(char medio_de_pago){
    return (medio_de_pago == EFECTIVO || medio_de_pago == CREDITO || medio_de_pago == DEBITO);
}

char pedir_medio_de_pago_valido(){
    char medio_de_pago = '-';
    printf("Ingrese su medio de pago ((E)fectivo, (C)rédito o (D)ébito):");
    scanf(" %c", &medio_de_pago);

    while(!es_medio_pago_valido(medio_de_pago)){
        printf("Medio de pago erróneo, ingrese nuevamente ((E)fectivo, (C)rédito o (D)ébito):");
        scanf(" %c", &medio_de_pago);
    }

    return medio_de_pago;
}

void nombre_procedimiento(parametros...){

}

int main(){
    int gasto = 0;
    char medio_de_pago = '-';


    printf("Ingrese cuanto gastó:");
    scanf("%i", &gasto);

    medio_de_pago = pedir_medio_de_pago_valido();

    int gasto_final = 0;

    if(gasto > MIN_GASTO_OFERTA && medio_de_pago == MEDIO_PAGO_OFERTA){
        // Pago reducido
        gasto_final = (gasto*(100-DESCUENTO))/100 ;
    } else {
        // Pago completo
        gasto_final = gasto;
    }

    printf("Se gastó $%i con medio de pago %c", gasto_final, medio_de_pago);
}
