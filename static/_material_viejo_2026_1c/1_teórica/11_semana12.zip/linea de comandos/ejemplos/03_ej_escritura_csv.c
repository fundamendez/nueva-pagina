#include <stdio.h>
#include <string.h>

#define MAX_NOMBRE_ALUMNO 100
#define MAX_CORRECTOR 50

const int POS_ARG_COLAB_RENUNCIA = 1;
const int POS_ARG_COLAB_SUPLANTA = 2;

const int CANT_MIN_ARGUMENTOS = 3;
const int ERROR_CANT_ARGUMENTOS = 4;
const int ERROR_APERTURA = 3;
const int EXITO = 0;

int main (int argc, char* argv[]) {

    if(argc < CANT_MIN_ARGUMENTOS) {
        printf("Cantidad inválida de argumentos\n");
        return ERROR_CANT_ARGUMENTOS; 
    }

    FILE* alumnos = fopen("alumnos.csv", "r");
    if (!alumnos) {
        printf("Error al abrir el archivo\n");
        return ERROR_APERTURA;
    }

    FILE* auxiliar = fopen("temporal.csv", "w");
    if (!auxiliar) {
        printf("Error al abrir el archivo\n");
        fclose(alumnos);
        return ERROR_APERTURA;
    }

    int id_alumno;
    char nombre_alumno[MAX_NOMBRE_ALUMNO];
    char corrector[MAX_CORRECTOR];
    int nro_alumno = 0;

    int leido = fscanf(alumnos, "%i;%[^;];%[^\n]\n", &id_alumno, nombre_alumno, corrector);

    while(leido != EOF) {
        nro_alumno++;

        if (strcmp(corrector, argv[POS_ARG_COLAB_RENUNCIA]) == 0) {
            strcpy(corrector, argv[POS_ARG_COLAB_SUPLANTA]);
        }

        fprintf(auxiliar, "%i;%s;%s\n", id_alumno, nombre_alumno, corrector);

        leido = fscanf(alumnos, "%i;%[^;];%[^\n]\n", &id_alumno, nombre_alumno, corrector);
    }

    fclose(alumnos);
    fclose(auxiliar);

    remove("alumnos.csv");
    rename("temporal.csv", "alumnos.csv");

    return EXITO;
}