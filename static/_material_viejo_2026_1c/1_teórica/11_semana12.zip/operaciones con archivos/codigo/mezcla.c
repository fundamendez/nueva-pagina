#include <stdio.h>

#define FORMATO "%i\n"

/* pre condiciones: los archivos a y b esten abiertos en modo lectura, el archivo resultado debe estar abierto en modo escritura. 
Los archivos a y b deben tener formato correcto y estar ordenados de manera ascendente. */
// post condiciones: devuelve en el contenido de 'resultado' la mezcla ordenada ascentenmente del contenido de 'archivo_a' y 'archivo_b'.
void mezclar_archivos(FILE* archivo_a, FILE* archivo_b, FILE* resultado) {
    int valor_a;
    int leido_a = fscanf(archivo_a, FORMATO, &valor_a);

    int valor_b;
    int leido_b = fscanf(archivo_b, FORMATO, &valor_b);

    while((leido_a != EOF) && (leido_b != EOF)){
        if(valor_a > valor_b){
            fprintf(resultado, FORMATO, valor_b);
            leido_b = fscanf(archivo_b, FORMATO, &valor_b);
        } else if (valor_a < valor_b) {
            fprintf(resultado, FORMATO, valor_a);
            leido_a = fscanf(archivo_a, FORMATO, &valor_a);
        } else { //son iguales
            fprintf(resultado, FORMATO, valor_a);
            fprintf(resultado, FORMATO, valor_b);
            leido_a = fscanf(archivo_a, FORMATO, &valor_a);
            leido_b = fscanf(archivo_b, FORMATO, &valor_b);
        }
    }
    while(leido_a != EOF){
        fprintf(resultado, FORMATO, valor_a);
        leido_a = fscanf(archivo_a, FORMATO, &valor_a);
    }
    while (leido_b != EOF){
        fprintf(resultado, FORMATO, valor_b);
        leido_b = fscanf(archivo_b, FORMATO, &valor_b);
    }

}
