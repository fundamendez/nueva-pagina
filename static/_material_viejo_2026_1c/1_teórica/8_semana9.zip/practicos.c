// 1C2026_practica8 - ejercicio 3

#define COLOR_RIVAL "rojo"
const int MIN_VICTORIAS_RIVAL = 6;

// pre condiciones: 'cantidad_autos' tiene que ser mayor o igual a 0 y menor a MAX_AUTOS.
//                  los campos 'color' de todos los auto_t tiene que terminar en '\0'.
//                  'actual' tiene que ser mayor o igual a 0 y menor a cantidad_autos.
// post condiciones: devuelve la cantidad de autos que se consideran rivales
int cantidad_rivales(auto_t autos[MAX_AUTOS], int cantidad_autos, int actual) {

    if(actual == cantidad_autos) {
        return 0;
    }

    if(es_rival(autos[actual])) {
        return 1 + cantidad_rivales(autos, cantidad_autos, actual + 1);
    }

    return cantidad_rivales(autos, cantidad_autos, actual + 1);
}

// pre condiciones: el campo 'color' debe terminar en '\0'
// post condiciones: devuelve true si el auto es considerado un rival o false en caso constrario
bool es_rival(auto_t auto) {
    return strcmp(auto.color, COLOR_RIVAL) == 0 
        && auto.cantidad_victorias >= MIN_VICTORIAS_RIVAL
        && auto.tiene_neumaticos_nuevos;
}


///////////////////////////////////////////////////////////////////////////////////////////////////


// 1C2026_practica8 - ejercicio 4

// pre condiciones: 'mapa' está inicializado en su totalidad
// post condiciones: devuelve true en caso de que kuzco pueda pasar por alguna fila o false en caso contrario
bool kuzco_puede_pasar(int mapa[MAX_FILS][MAX_COLS], int vida_kuzko) {
    int i = 0;
    int j = 0;
    bool puede_pasar = false;

    int contador_danio = 0;
    while(j < MAX_COLS && !puede_pasar){
        contador_danio = 0;

        while(i < MAX_FILS && !puede_pasar){
            contador_danio += mapa[i][j];
            i++;
        }
        j++;

        if(contador_danio < vida_kuzko){
            puede_pasar = true;
        }
    }

    return puede_pasar;

}


////////////////////////////////////////////////////////////////////////////////


// 1C2026_practica8 - ejercicio 5

#define NOTA_DIFICIL "RE"
#define NOTA_ANTERIOR "LA"
const char CORCHEA = 'C';
const char SEMICORCHEA = 'S';
const int MIN_INTENSIDAD = 6;

// pre condiciones: los campos 'sonido' de los nota_t deben terminar en '\0'
//                  'cantidad_notas' deber ser mayor o igual a 0 y menor a MAX_NOTAS
//                  'actual' deber ser mayor o igual a 0 y menor a 'cantidad_notas'
//                  'sumatoria_promedio' debe valer 0 en el primer llamado
//                  'total_promedio' debe valor 0 en el primer llamado
// post condiciones: devuelve el promedio de duración de la NOTA_DIFICIL si cumple las condiciones del enunciado
float promedio_duracion_nota(nota_t notas[MAX_NOTAS], int cantidad_notas, int actual, int sumatoria_promedio, int total_promedio) {

    if(actual == cantidad_notas) {
        if(total_promedio == 0) {
            return 0;   
        }

        return (float)(sumatoria_promedio / total_promedio);
    }

    if(es_nota_buscada(notas, actual)) {
        sumatoria_promedio += notas[actual].duracion_ms;
        total_promedio++;
    }

    return promedio_duracion_nota(notas, cantidad_notas, actual + 1, sumatoria_promedio total_promedio);
}

// pre condiciones: los campos 'sonido' de los nota_t deben terminar en '\0'.
//                  'actual' deber ser mayor o igual a 0 y menor a 'cantidad_notas'.
// post condiciones: devuelve true si es la nota buscada que cumple las condiciones pedidas o false en caso contrario.
bool es_nota_buscada(nota_t notas[MAX_NOTAS], int actual) {
    nota_t actual = notas[actual];
    if(strcmp(actual.sonido, NOTA_DIFICIL) != 0) {
        return false;
    }

    if(actual.figura_musical == CORCHEA && !actual.es_silencio && actual.intensidad >= MIN_INTENSIDAD) {
        return true;
    }

    if(actual == 0) {
        return false;
    }

    nota_t anterior = notas[actual-1];
    return strcmp(actual.sonido, NOTA_ANTERIOR) == 0 anterior.figura_musical == SEMICORCHEA;
}


////////////////////////////////////////////////////////////////////////////////


// practico_mulan - ejercicio 2

const int COLUMNA_INVALIDA = -1;
const int ENERGIA_INVALIDA = -1;
const char ALIADO = 'M';
#define ARMA_MULTIPLICADORA "ballesta"

// pre condiciones: todas las posiciones de 'campo' están inicializadas.
//                  todos los campos 'armas' de los enemigo_t terminan sus filas con '\0'.
//post condiciones: devuelve el índice de la matriz de la columna por la que mulan puede pasar gastando la mínima enregía.
int columna_pasa_mulan(enemigo_t campo[MAX_FILS][MAX_COLS]) {
    int energia_columna = 0;
    int energia_minima = ENERGIA_INVALIDA;
    int columna_minima = COLUMNA_INVALIDA;
    for (int j = 0; j < MAX_COLS; j++){
        energia_columna = 0;

        for (int i = 0; i < MAX_FILS; i++){
            if(es_enemigo(campo[i][j])) {
                if(tiene_arma_multiplicadora(campo[i][j].armas)) {
                    energia_columna += campo[i][j].fuerza * 2;
                }
                else {
                    energia_columna += campo[i][j].fuerza;
                }
            }
        }

        if (columna_minima == COLUMNA_INVALIDA || energia_columna < energia_minima) {
            energia_minima = energia_columna;
            columna_minima = j;
        }
    }

    return columna_minima;
}

// pre condiciones: -
//post condiciones: devuelve true si realmente es un enemigo y false en caso contrario
bool es_enemigo(enemigo_t enemigo) {
    return !enemigo.vencido && enemigo.letra_cinta != ALIADO;
}

// pre condiciones: todas las fila de 'armas' deben terminar con '\0'.
// post condiciones: devuelve true si en el vector de armas se encuentra el ARMA_MULTIPLICADORA o false en caso contrario.
bool tiene_arma_multiplicadora(char armas[MAX_NOMBRE][MAX_ARMAS]) {
    bool tiene_arma = false;
    int i = 0;

    while(i < MAX_ARMAS && !tiene_arma) {
        if(strcmp(armas[i], ARMA_MULTIPLICADORA) == 0) {
            tiene_arma = true;
        }
        i++;
    }

    return tiene_arma;
}
