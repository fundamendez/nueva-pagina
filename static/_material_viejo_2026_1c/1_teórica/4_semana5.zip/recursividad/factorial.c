#include<stdio.h>

int factorial(int n){
    if(n == 1) {
        return 1;
    }

    return n*factorial(n-1);
}

int factorial2(int n){
    int total = 1;
    for(int i = 1; i <= n; i++){
        total *= i;
    }

    return total;
}

int main(){
    printf("El factorial de 10 es: %i\n", factorial(10));
    printf("El factorial de 10 es: %i\n", factorial2(10));

    return 0;
}
