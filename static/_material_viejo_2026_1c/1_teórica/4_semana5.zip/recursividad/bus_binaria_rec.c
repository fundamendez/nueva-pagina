#include<stdio.h>

const int NO_ENCONTRADO = -1;

int busqueda_binaria_rec(int vector[], int tope, int valor_buscado, int inicio, int fin){
    int centro = (inicio+fin)/2;

    //Caso base
    //Condición de corte

    //Caso donde NO se vuelva a hacer una llamada recursiva
    if (vector[centro] == valor_buscado) {
        return centro;
    }

    if (inicio > fin) {
        return NO_ENCONTRADO;
    }

    //Procesamiento
    //Tiene que achicar el problema
    if (vector[centro] > valor_buscado) {
        fin = centro-1;
    } else {
        inicio = centro+1;
    }

    //Llamada recursiva
    return busqueda_binaria_rec(vector, tope, valor_buscado, inicio, fin);
}

int main(){
    int vector[] = {1,5,6,8,10,12,13,15,20,21,22};
    int tope = 11;

    printf("El valor 5 está en la posición: %i", busqueda_binaria_rec(vector, tope, 5, 0, tope-1));
    return 0;
}
