#ifndef RECOLECTOR_TESOROS_H
#define RECOLECTOR_TESOROS_H

#include <stdbool.h>

#define MAX_FILAS 5
#define MAX_COLUMNAS 5
#define MAX_TESOROS 10

typedef struct coordenada {
  int fil;
  int col;
} coordenada_t;

typedef struct jugador {
  coordenada_t posicion;
  int movimientos_restantes;
  int tesoros_recolectados;
} jugador_t;

typedef struct juego {
  jugador_t jugador;
  coordenada_t tesoros[MAX_TESOROS];
  int tope_tesoros;
} juego_t;

/*
 * Pre: -
 * Post:
 * - Inicializa el jugador en (0,0)
 * - tesoros_recolectados en 0
 * - movimientos_restantes en 100
 * - Inicializa los tesoros de forma aleatoria
 */
void cargar_juego(juego_t *juego);

/*
 * Pre: 'direccion' debe ser:
 * 'W' (arriba), 'S' (abajo), 'A' (izquierda), 'D' (derecha)
 * Post:
 * - Mueve al jugador si la jugada es válida (dentro del tablero)
 * - Si cae en un tesoro:
 *      - lo elimina del vector
 *      - suma 1 a tesoros_recolectados y 10 a movimientos_restantes
 */
void jugar(juego_t *juego, char direccion);

/*
 * Pre: juego inicializado
 * Post: Muestra el terreno por pantalla:
 * - 'J' para jugador
 * - 'T' para tesoros
 */
void imprimir_terreno(juego_t juego);

/*
 * Pre: juego inicializado
 * Post: Devuelve:
 * 1 si el jugador recolectó todos los tesoros (gana)
 * 0 si todavía quedan tesoros (sigue jugando)
 * -1 si el jugador se quedó sin movimientos (pierde)
 */
int estado_juego(juego_t juego);

#endif