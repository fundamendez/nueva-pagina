#include <stdio.h>
#include <string.h>

#define MAX_NOMBRE 10
#define MAX_CESTA 30

#define COLOR_TOMACO "\033[38;5;208m" // Naranja
#define COLOR_TOMATE "\033[0;31m"     // Rojo
#define RESET_COLOR "\033[0m"         // Vuelve al color por defecto

#define FRUTA_NO_DESEADA "Tomate"


typedef struct fruto {
  int peso; // en gramos
  char nombre[MAX_NOMBRE];
} fruto_t;



void cargar_cesta(fruto_t *cesta, int* tope) {
  fruto_t datos_fijos[20] = {{150, "Tomaco"}, {120, "Tomaco"}, {130, "Tomaco"},
                             {140, "Tomaco"}, {160, "Tomaco"}, {110, "Tomate"},
                             {125, "Tomaco"}, {135, "Tomaco"}, {150, "Tomate"},
                             {120, "Tomaco"}, {130, "Tomate"}, {140, "Tomate"},
                             {145, "Tomaco"}, {155, "Tomaco"}, {115, "Tomate"},
                             {105, "Tomaco"}, {160, "Tomate"}, {110, "Tomate"},
                             {125, "Tomaco"}, {135, "Tomate"}

  };

  for (int i = 0; i < 20; i++) {
    cesta[i].peso = datos_fijos[i].peso;
    strcpy(cesta[i].nombre, datos_fijos[i].nombre);
    (*tope)++;
  }
}


void imprimir_cesta(fruto_t* cesta, int cantidad) {
    printf("\nLa cesta de Bart:\n\n");

    for (int i = 0; i < cantidad; i++) {
        if (i % 5 == 0) {
            printf("## ");
        }

        if (strcmp(cesta[i].nombre, "Tomate") == 0) {
            printf("%s%s (%3dg)%s ", COLOR_TOMATE, cesta[i].nombre, cesta[i].peso, RESET_COLOR);
        } else {
            printf("%s%s (%3dg)%s ", COLOR_TOMACO, cesta[i].nombre, cesta[i].peso, RESET_COLOR);
        }


      
      if ((i + 1) % 5 == 0) {
            printf(" ##\n");
        }
    }

    printf("############################################################################\n\n");
}

//PRE: índice tiene que ser 0 en el primer llamado, cesta y su tope inicializados correctamente, cesta tiene que tener solo tomacos y tomates, gramos tiene que ser 0 en el primer llamado
//POST: devuelve los gramos consumidos de tomaco 
int gramos_consumidos_tomaco(fruto_t cesta[MAX_CESTA], int tope, int i, int gramos){
    if(strcmp(cesta[i].nombre, FRUTA_NO_DESEADA) == 0 || i == tope -1){
        return gramos;
    }
    gramos += cesta[i].peso;
    return gramos_consumidos_tomaco(cesta, tope, i+1, gramos);
}




int main() {
  fruto_t cesta[MAX_CESTA];
  int tope_cesta = 0;

  cargar_cesta(cesta, &tope_cesta);
  imprimir_cesta(cesta, tope_cesta);

  int gramos_consumidos = gramos_consumidos_tomaco(cesta, tope_cesta, 0, 0);
  printf("Bart comió %i gramos de tomaco \n", gramos_consumidos);



  return 0;
}