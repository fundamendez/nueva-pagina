#include "pila_latas.h"
#include <stdio.h>
#include <stdlib.h>

const int ERROR = -1;
const int FECHA_ACTUAL = 20261112;

void cargar_latas_ejemplo(pila_latas_t *pila){
    lata_t latas[] = {
        {"Tomates", 20280115, false, false},
        {"Atun", 20270220, false, true},
        {"Arvejas", 20260101, false, false},
        {"Duraznos", 20280510, true, false},
        {"Choclo", 20270110, false, false},
        {"Anana", 20270120, false, true}
    };
    int cantidad = sizeof(latas) / sizeof(latas[0]);
    for (int i = 0; i < cantidad; i++) {
        apilar_lata(pila, latas[i]);
    }
}

/* Muestra las latas desde el tope y deja la pila en el mismo orden. */
void imprimir_latas(pila_latas_t *pila){
    pila_latas_t *auxiliar = pila_latas_crear();
    if (auxiliar == NULL) {
        return;
    }

    printf("Tope:");
    while (!pila_latas_esta_vacia(pila)) {
        lata_t lata;
        desapilar_lata(pila, &lata);
        printf("  %s | vencimiento: %d | %s | %s\n", lata.nombre,
               lata.fecha_vencimiento,
               lata.es_importada ? "importada" : "nacional",
               lata.esta_abollada ? "abollada" : "sin abolladuras");
        apilar_lata(auxiliar, lata);
    }
    while (!pila_latas_esta_vacia(auxiliar)) {
        lata_t lata;
        desapilar_lata(auxiliar, &lata);
        apilar_lata(pila, lata);
    }
    pila_latas_destruir(auxiliar);
}

int procesar_latas(pila_latas_t* pila){
    pila_latas_t* pila_importadas = pila_latas_crear();
    if(!pila_importadas){
        printf("No se pudo crear la pila de importadas");
        return ERROR;
    }
    pila_latas_t* pila_nacionales = pila_latas_crear();
    if(!pila_nacionales){
        printf("No se pudo crear la pila de nacionales");
        pila_latas_destruir(pila_importadas);
        return ERROR;
    }

    while(!pila_latas_esta_vacia(pila)){
        lata_t lata;
        desapilar_lata(pila,&lata);
        if(!lata.esta_abollada && lata.fecha_vencimiento > FECHA_ACTUAL){
            if(lata.es_importada){
                apilar_lata(pila_importadas, lata);
            }else{
                apilar_lata(pila_nacionales, lata);
            }
        }
    }

    while(!pila_latas_esta_vacia(pila_importadas)){
        lata_t lata;
        desapilar_lata(pila_importadas, &lata);
        apilar_lata(pila, lata);
    }
    while(!pila_latas_esta_vacia(pila_nacionales)){
        lata_t lata;
        desapilar_lata(pila_nacionales, &lata);
        apilar_lata(pila, lata);
    }

    pila_latas_destruir(pila_importadas);
    pila_latas_destruir(pila_nacionales);
}

int main(){
    pila_latas_t *pila = pila_latas_crear();
    if (pila == NULL) {
        printf("No se pudo crear la pila.\n", stderr);
        return ERROR;
    }

    cargar_latas_ejemplo(pila);
    printf("Antes de procesar:");
    imprimir_latas(pila);

    printf("\nDespues de procesar (fecha actual: %d):\n", FECHA_ACTUAL);


    
    imprimir_latas(pila);

    pila_latas_destruir(pila);
    return 0;
}
