#ifndef CAJA_H
#define CAJA_H


#include <stdbool.h>


#define MAX_NOMBRE 100


typedef struct {
   char nombre[MAX_NOMBRE];
   bool escondio_mercaderia;
   int paciencia;
} cliente_t;




typedef struct caja caja_t;


/*
Post: Crea una caja vacía. Devuelve un puntero a la caja o NULL en caso de error.
*/
caja_t* caja_crear();


/*
Pre: `caja` fue creada usando caja_crear().
Post: Agrega un cliente al FINAL de la caja. Devuelve true si se pudo encolar, false en caso de error.
*/
bool caja_agregar(caja_t* caja, cliente_t cliente);


/*
Pre: `caja` fue creada usando caja_crear().
Post: Atiende al cliente. Saca de la caja al PRIMER cliente y, si `cliente_atendido` no es NULL, guarda en él una copia del cliente. Devuelve true si se quitó correctamente, false si la caja está vacía o hubo error.
*/
bool caja_quitar(caja_t* caja, cliente_t* cliente_atendido);


/*
Pre: `caja` fue creada usando caja_crear().
Post: Destruye la caja y libera toda la memoria utilizada por los clientes que quedaron esperando.
*/
void caja_destruir(caja_t* caja);


#endif /* CAJA_H */
