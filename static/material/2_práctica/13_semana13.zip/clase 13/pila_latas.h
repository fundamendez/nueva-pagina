#ifndef __PILA_LATAS_H__
#define __PILA_LATAS_H__

#include <stdbool.h>

#define MAX_NOMBRE 100


typedef struct lata {
   char nombre[MAX_NOMBRE];
   int fecha_vencimiento; // Formato AAAAMMDD
   bool esta_abollada;
   bool es_importada;
} lata_t;


struct pila_latas;
typedef struct pila_latas pila_latas_t;


// Pre: -
// Post: Crea una pila vacía en el heap.
//       Devuelve NULL si no pudo crearla.
pila_latas_t* pila_latas_crear();


// Pre: La pila fue creada previamente.
// Post: Apila una lata en el tope de la pila.
void apilar_lata(pila_latas_t* pila, lata_t lata);


// Pre: La pila fue creada previamente.
// Post: Desapila la lata del tope y la devuelve mediante lata_desapilada.
//       Si la pila está vacía, no hace nada.
void desapilar_lata(pila_latas_t* pila, lata_t* lata_desapilada);


// Pre: La pila fue creada previamente.
// Post: Devuelve true si la pila está vacía.
bool pila_latas_esta_vacia(pila_latas_t* pila);


// Pre: La pila fue creada previamente.
// Post: Libera todos los recursos utilizados por la pila.
void pila_latas_destruir(pila_latas_t* pila);

#endif