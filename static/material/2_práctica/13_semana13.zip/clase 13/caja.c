#include "caja.h"

#include <stdlib.h>

typedef struct nodo {
    cliente_t cliente;
    struct nodo* siguiente;
} nodo_t;

struct caja {
    nodo_t* primero;
    nodo_t* ultimo;
};

caja_t* caja_crear(void)
{
    caja_t* caja = malloc(sizeof(caja_t));
    if (caja == NULL)
        return NULL;

    caja->primero = NULL;
    caja->ultimo = NULL;
    return caja;
}

bool caja_agregar(caja_t* caja, cliente_t cliente)
{
    if (caja == NULL)
        return false;

    nodo_t* nuevo = malloc(sizeof(nodo_t));
    if (nuevo == NULL)
        return false;

    nuevo->cliente = cliente;
    nuevo->siguiente = NULL;

    if (caja->ultimo != NULL)
        caja->ultimo->siguiente = nuevo;
    else
        caja->primero = nuevo;

    caja->ultimo = nuevo;
    return true;
}

bool caja_quitar(caja_t* caja, cliente_t* cliente_atendido)
{
    if (caja == NULL || caja->primero == NULL)
        return false;

    nodo_t* atendido = caja->primero;
    caja->primero = atendido->siguiente;
    if (caja->primero == NULL)
        caja->ultimo = NULL;

    if (cliente_atendido != NULL)
        *cliente_atendido = atendido->cliente;

    free(atendido);
    return true;
}

void caja_destruir(caja_t* caja)
{
    if (caja == NULL)
        return;

    while (caja_quitar(caja, NULL)) {
    }
    free(caja);
}
