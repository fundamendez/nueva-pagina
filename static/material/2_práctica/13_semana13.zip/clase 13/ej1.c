#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "caja.h"

#define NOMBRE_ARCHIVO "sospechosos.txt"
#define LECTURA "r" 
#define MAX_SOSPECHOSOS 50
#define FORMATO_DE_LECTURA "%[^\n]\n" 

const int ERROR = -1;
const int EXITO = 0;

void mostrar_caja(caja_t* caja){
    cliente_t cliente;
    while (caja_quitar(caja, &cliente)) {
        printf("%s (paciencia: %d, escondio mercaderia: %s)\n",
               cliente.nombre, cliente.paciencia,
               cliente.escondio_mercaderia ? "si" : "no");
    }
}

bool es_sospechoso(cliente_t cliente,char nombre_sospechosos[MAX_SOSPECHOSOS][MAX_NOMBRE], int tope_sospechosos){
    bool encontrado = false;
    int i = 0;
    while (!encontrado && i<tope_sospechosos)
    {
        if(strcmp(cliente.nombre, nombre_sospechosos[i]) == 0){
            encontrado = true;
        }
        i++;
    }
    return (encontrado && cliente.escondio_mercaderia);
}

int guardo_sospechosos(char nombre_sospechosos[MAX_SOSPECHOSOS][MAX_NOMBRE], int* tope_sospechosos){
    FILE* archivo_sospechosos = fopen(NOMBRE_ARCHIVO,LECTURA);
    if(!archivo_sospechosos){
        printf("Error al abrir el archvio\n");
        return ERROR;
    }

    int leido_sospechoso = fscanf(archivo_sospechosos,FORMATO_DE_LECTURA, nombre_sospechosos[*tope_sospechosos]);
    
    while (leido_sospechoso != EOF){
        (*tope_sospechosos)++;
        leido_sospechoso = fscanf(archivo_sospechosos,FORMATO_DE_LECTURA, nombre_sospechosos[*tope_sospechosos]);
    }
    fclose(archivo_sospechosos);

    return EXITO;
}

int eliminar_sospechosos(caja_t* caja){
    int tope_sospechosos = 0;
    char nombre_sospechosos[MAX_SOSPECHOSOS][MAX_NOMBRE];
    guardo_sospechosos(nombre_sospechosos, &tope_sospechosos);

    cliente_t cliente_aux;
    caja_t* caja_aux = caja_crear();
    if(!caja_aux){
        printf("Error al crear la caja aux");
        return ERROR;
    }
    bool error_al_agregar = false;

    while (caja_quitar(caja, &cliente_aux) && !error_al_agregar){
        if (!es_sospechoso(cliente_aux, nombre_sospechosos, tope_sospechosos)){
            if (!caja_agregar(caja_aux, cliente_aux)){
                printf("Error al agregar a la pila auxiliar");
                error_al_agregar = true;
            }   
        }
    }

    if(error_al_agregar){
        return ERROR;
    }

    while (caja_quitar(caja_aux, &cliente_aux) && !error_al_agregar){
        if(!caja_agregar(caja, cliente_aux)){
            printf("Error al agregar a la pila auxiliar");
            error_al_agregar = true;
        }
    }
    if(error_al_agregar){
        return ERROR;
    }

    caja_destruir(caja_aux);
    return EXITO;
}

int main(int argc, char const *argv[]){
    caja_t* caja = caja_crear();
    if (caja == NULL)
        return ERROR;

    cliente_t clientes[] = {
        {"Homero Simpson", false, 10},
        {"Bart Simpson", true, 8},
        {"Marge Simpson", false, 7},
        {"Moe Szyslak", true, 5},
        {"Lisa Simpson", true, 9},
        {"Ned Flanders", false, 6},
        {"Milhouse Van Houten", true, 4},
        {"Apu Nahasapeemapetilon", false, 10},
    };

    bool no_hubo_error = true;
    int i = 0;
    while (no_hubo_error && i < 8) {
        no_hubo_error = caja_agregar(caja, clientes[i]);
        i++;
    }

    if (!no_hubo_error) {
        printf("Hubo un problema al cargar a los clientes.\n");
        caja_destruir(caja);
        return ERROR;
    }
    if(eliminar_sospechosos(caja) == ERROR){
        printf("Hubo un problema al eliminar a los ladrones.\n");
        caja_destruir(caja);
        return ERROR;
    }
    mostrar_caja(caja);
    caja_destruir(caja);
    return 0;
}
