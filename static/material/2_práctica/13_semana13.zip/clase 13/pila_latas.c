#include "pila_latas.h"

#include <stdlib.h>

typedef struct nodo {
    lata_t lata;
    struct nodo *siguiente;
} nodo_t;

struct pila_latas {
    nodo_t *tope;
};

pila_latas_t *pila_latas_crear(void)
{
    pila_latas_t *pila = malloc(sizeof *pila);
    if (pila == NULL) {
        return NULL;
    }

    pila->tope = NULL;
    return pila;
}

void apilar_lata(pila_latas_t *pila, lata_t lata)
{
    nodo_t *nuevo = malloc(sizeof *nuevo);
    if (nuevo == NULL) {
        abort();
    }

    nuevo->lata = lata;
    nuevo->siguiente = pila->tope;
    pila->tope = nuevo;
}

void desapilar_lata(pila_latas_t *pila, lata_t *lata_desapilada)
{
    if (pila->tope == NULL) {
        return;
    }

    nodo_t *nodo = pila->tope;
    *lata_desapilada = nodo->lata;
    pila->tope = nodo->siguiente;
    free(nodo);
}

bool pila_latas_esta_vacia(pila_latas_t *pila)
{
    return pila->tope == NULL;
}

void pila_latas_destruir(pila_latas_t *pila)
{
    while (pila->tope != NULL) {
        nodo_t *nodo = pila->tope;
        pila->tope = nodo->siguiente;
        free(nodo);
    }

    free(pila);
}