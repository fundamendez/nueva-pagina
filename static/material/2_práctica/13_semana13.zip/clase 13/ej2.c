#include <stdio.h>
#include <string.h>
#include <stdbool.h>


#define RESET "\033[0m"
#define NEGRITA "\033[1m"
#define ROJO "\033[1;31m"
#define VERDE "\033[1;32m"
#define AMARILLO "\033[1;33m"
#define AZUL "\033[1;34m"
#define CIAN "\033[1;36m"

#define MAX_STR 100
#define MAX_INGREDIENTES 3
typedef struct combo {
    char nombre_combo[MAX_STR];
    char hamburguesa[MAX_STR];
    char tamanio;
} combo_t;

typedef struct receta {
    char hamburguesa[MAX_STR];
    char ingredientes[MAX_INGREDIENTES][MAX_STR];
} receta_t;


#define FORMATO_LECTURA_DESCRIPCION "%[^;];%[^;];%c\n"
#define FORMATO_LECTURA_INGREDIENTES "%[^;];%[^;];%[^;];%[^\n]\n"
#define FORMATO_ESCRITURA_COMBOS "%s\n"
#define FORMATO_LECTURA_COMBOS "%[^\n]\n"



#define ARCHIVO_DESCRIPCIONES "descripcion_combos.csv"
#define ARCHIVO_INGREDIENTES "ingredientes.csv"
#define ARCHIVO_COMBOS "combos.txt"

#define CANT_FALTANTES 2
const char INGREDIENTES_FALTANTES[CANT_FALTANTES][MAX_STR] = {"mostaza", "lechuga"};
const int ERROR = 1;
const int EXITO = 0;




/*
- Pre: Los archivos deben existir y estar ordenados por nombre de hamburguesa.
- Post: Imprime por pantalla el contenido de ambos CSV y del archivo de salida
-       de forma independiente sin usar funciones auxiliares del algoritmo.
 */
void mostrar_estado_archivos(char* ruta_combos, char* ruta_ing, char* ruta_salida) {
    FILE* archivo_combos = fopen(ruta_combos, "r");
    if (!archivo_combos) {
        printf(ROJO "Error al abrir %s para mostrar el resumen.\n" RESET, ruta_combos);
        return;
    }

    FILE* archivo_ingredientes = fopen(ruta_ing, "r");
    if (!archivo_ingredientes) {
        printf(ROJO "Error al abrir %s para mostrar el resumen.\n" RESET, ruta_ing);
        fclose(archivo_combos);
        return;
    }

    FILE* archivo_salida = fopen(ruta_salida, "r");
    if (!archivo_salida) {
        printf(ROJO "Error al abrir %s para mostrar el resumen.\n" RESET, ruta_salida);
        fclose(archivo_combos);
        fclose(archivo_ingredientes);
        return;
    }

    printf("\n" AZUL "====================================================================" RESET "\n");
    printf(NEGRITA AZUL "                    MENU KRUSTY BURGER - AUDITORIA                  " RESET "\n");
    printf(AZUL "====================================================================" RESET "\n\n");

    combo_t combo_actual;

    printf(AMARILLO ">>> COMBOS PROPUESTOS (%s):\n" RESET, ruta_combos);
    printf("%-30s | %-25s | %-6s\n", "Nombre Combo", "Hamburguesa", "Tam.");
    printf("--------------------------------------------------------------------\n");

    int leidos_combo = fscanf(archivo_combos, FORMATO_LECTURA_DESCRIPCION,
                              combo_actual.nombre_combo,
                              combo_actual.hamburguesa,
                              &combo_actual.tamanio);
    while (leidos_combo != EOF) {
        printf("%-30s | %-25s | %-6c\n",
               combo_actual.nombre_combo,
               combo_actual.hamburguesa,
               combo_actual.tamanio);
        leidos_combo = fscanf(archivo_combos, FORMATO_LECTURA_DESCRIPCION,
                              combo_actual.nombre_combo,
                              combo_actual.hamburguesa,
                              &combo_actual.tamanio);
    }
    printf("\n");

    receta_t receta_actual;

    printf(CIAN ">>> INGREDIENTES (%s):\n" RESET, ruta_ing);
    printf("%-25s | %-12s | %-12s | %-12s\n", "Hamburguesa", "Ing. 1", "Ing. 2", "Ing. 3");
    printf("--------------------------------------------------------------------\n");

    int leidos_ing = fscanf(archivo_ingredientes, FORMATO_LECTURA_INGREDIENTES,
                            receta_actual.hamburguesa,
                            receta_actual.ingredientes[0],
                            receta_actual.ingredientes[1],
                            receta_actual.ingredientes[2]);
    while (leidos_ing != EOF) {
        printf("%-25s | ", receta_actual.hamburguesa);

        char ingredientes[3][MAX_STR];
        strcpy(ingredientes[0], receta_actual.ingredientes[0]);
        strcpy(ingredientes[1], receta_actual.ingredientes[1]);
        strcpy(ingredientes[2], receta_actual.ingredientes[2]);

        for (int i = 0; i < 3; i++) {
            bool faltante_encontrado = false;
            int j = 0;

            while (j < CANT_FALTANTES && !faltante_encontrado) {
                if (strcmp(ingredientes[i], INGREDIENTES_FALTANTES[j]) == 0) {
                    faltante_encontrado = true;
                }
                j++;
            }

            if (faltante_encontrado) {
                printf(ROJO "%-12s" RESET, ingredientes[i]);
            } else {
                printf("%-12s", ingredientes[i]);
            }

            if (i < 2) {
                printf(" | ");
            }
        }
        printf("\n");

        leidos_ing = fscanf(archivo_ingredientes, FORMATO_LECTURA_INGREDIENTES,
                            receta_actual.hamburguesa,
                            receta_actual.ingredientes[0],
                            receta_actual.ingredientes[1],
                            receta_actual.ingredientes[2]);
    }
    printf("\n");

    char combo_disponible[MAX_STR];
    int cantidad_disponibles = 0;

    printf(VERDE ">>> COMBOS DISPONIBLES (%s):\n" RESET, ruta_salida);
    printf("--------------------------------------------------------------------\n");

    int leidos_salida = fscanf(archivo_salida, FORMATO_LECTURA_COMBOS, combo_disponible);
    while (leidos_salida != EOF) {
        printf("  %s\n", combo_disponible);
        cantidad_disponibles++;
        leidos_salida = fscanf(archivo_salida, FORMATO_LECTURA_COMBOS, combo_disponible);
    }

    if (cantidad_disponibles == 0) {
        printf(ROJO "  (Ningun combo disponible con el stock actual)\n" RESET);
    }
    printf(AZUL "====================================================================" RESET "\n\n");

    fclose(archivo_combos);
    fclose(archivo_ingredientes);
    fclose(archivo_salida);
}




bool tiene_ingrediente_faltante(char ingredientes[MAX_INGREDIENTES][MAX_STR]){
    int i = 0;
    bool faltan_ingredientes = false;
    while (!faltan_ingredientes && i < MAX_INGREDIENTES){
        int j = 0;
        while(!faltan_ingredientes && j < CANT_FALTANTES){
            faltan_ingredientes = (strcmp(ingredientes[i], INGREDIENTES_FALTANTES[j]) == 0);
            j++;
        }
        i++;
    }
    return faltan_ingredientes;
}




int crear_archivo_combos(FILE* archivo_descripciones, FILE* archivo_ingredientes){

    FILE* archivo_combos = fopen(ARCHIVO_COMBOS, "w");
    if(!archivo_combos){
        printf("Error al abrir archivo combos");
        return ERROR;
    }

    combo_t combo;
    receta_t receta;

    int leidos_ingredientes = fscanf(archivo_ingredientes, FORMATO_LECTURA_INGREDIENTES, receta.hamburguesa, receta.ingredientes[0], receta.ingredientes[1], receta.ingredientes[2]);

    int leido_descripciones = fscanf(archivo_descripciones, FORMATO_LECTURA_DESCRIPCION, combo.nombre_combo, combo.hamburguesa, &combo.tamanio);

    while(leidos_ingredientes != EOF && leido_descripciones != EOF){
        if (strcmp(combo.hamburguesa, receta.hamburguesa) == 0){     
            if (!tiene_ingrediente_faltante(receta.ingredientes)){
                fprintf(archivo_combos, FORMATO_ESCRITURA_COMBOS, combo.nombre_combo);
            }
            int leidos_ingredientes = fscanf(archivo_ingredientes, FORMATO_LECTURA_INGREDIENTES, receta.hamburguesa, receta.ingredientes[0], receta.ingredientes[1], receta.ingredientes[2]);

            leido_descripciones = fscanf(archivo_descripciones, FORMATO_LECTURA_DESCRIPCION, combo.nombre_combo, combo.hamburguesa, &combo.tamanio);
        }
        if (strcmp(combo.hamburguesa, receta.hamburguesa) < 0){
            leido_descripciones = fscanf(archivo_descripciones, FORMATO_LECTURA_DESCRIPCION, combo.nombre_combo, combo.hamburguesa, &combo.tamanio);
        } 
        else {
            int leidos_ingredientes = fscanf(archivo_ingredientes, FORMATO_LECTURA_INGREDIENTES, receta.hamburguesa, receta.ingredientes[0], receta.ingredientes[1], receta.ingredientes[2]);
        }
    }

    fclose(archivo_combos);
    return EXITO;
}





int main() {
    FILE* archivo_combos = fopen(ARCHIVO_DESCRIPCIONES, "r");
    if (!archivo_combos) {
        printf("Error al abrir %s", ARCHIVO_DESCRIPCIONES);
        return ERROR;
    }

    FILE* archivo_ingredientes = fopen(ARCHIVO_INGREDIENTES, "r");
    if (!archivo_ingredientes) {
        printf("Error al abrir %s", ARCHIVO_INGREDIENTES);
        fclose(archivo_combos);
        return ERROR;
    }

    if (crear_archivo_combos(archivo_combos, archivo_ingredientes)){
        printf("Hubo un error al crear el archivo de combos\n");
        return ERROR;
    }

    fclose(archivo_combos);
    fclose(archivo_ingredientes);

    mostrar_estado_archivos(ARCHIVO_DESCRIPCIONES, ARCHIVO_INGREDIENTES, ARCHIVO_COMBOS);

    return EXITO;
}