#include <stdio.h>
#include <stdbool.h>

// Ejercicio 1: los dardos en el bar de Moe.
// El blanco es una matriz de letras:
//   V: no hay ningun dardo
//   M: dardo de Moe
//   H: dardo de Homero
// Los puntos de cada dardo se calculan como (indice de fila) * (indice de columna).

#define MAX_FILAS 5
#define MAX_COLUMNAS 5
#define MAX_JUGADORES 4


const char HOMERO = 'H';
const char MOE = 'M';
const char BARNEY = 'B';
const char LENNY = 'L';
const char VACIO = 'V';
const char EMPATE = 'E';

const int POSICION_INVALIDA = -1;

const char JUGADORES[MAX_JUGADORES] = {HOMERO, MOE, BARNEY, LENNY};




// Pre: blanco debe tener MAX_FILAS filas y MAX_COLUMNAS columnas.
// Post: copia los dardos de origen en el blanco.
void copiar_blanco(char blanco[MAX_FILAS][MAX_COLUMNAS], char origen[MAX_FILAS][MAX_COLUMNAS]){
    for(int i = 0; i < MAX_FILAS; i++){
        for(int j = 0; j < MAX_COLUMNAS; j++){
            blanco[i][j] = origen[i][j];
        }
    }
}

// Pre: blanco debe tener MAX_FILAS filas y MAX_COLUMNAS columnas.
// Post: carga un blanco donde solo tiraron Homero (H) y Moe (M).
void cargar_blanco_dos_jugadores(char blanco[MAX_FILAS][MAX_COLUMNAS]){
    char dardos[MAX_FILAS][MAX_COLUMNAS] = {
        {'V', 'V', 'V', 'H', 'V'},
        {'V', 'M', 'V', 'V', 'V'},
        {'V', 'V', 'H', 'V', 'V'},
        {'V', 'V', 'V', 'M', 'V'},
        {'V', 'H', 'V', 'V', 'M'}
    };
    copiar_blanco(blanco, dardos);
}

// Pre: blanco debe tener MAX_FILAS filas y MAX_COLUMNAS columnas.
// Post: carga un blanco donde tambien tiro Barney (B).
void cargar_blanco_tres_jugadores(char blanco[MAX_FILAS][MAX_COLUMNAS]){
    char dardos[MAX_FILAS][MAX_COLUMNAS] = {
        {'B', 'V', 'V', 'H', 'V'},
        {'V', 'M', 'V', 'V', 'B'},
        {'V', 'V', 'H', 'V', 'V'},
        {'B', 'V', 'V', 'M', 'V'},
        {'V', 'H', 'V', 'B', 'M'}
    };
    copiar_blanco(blanco, dardos);
}

// Pre: filas <= MAX_FILAS y columnas <= MAX_COLUMNAS.
// Post: muestra el blanco por pantalla.
void mostrar_blanco(char blanco[MAX_FILAS][MAX_COLUMNAS], int filas, int columnas){
    for(int i = 0; i < filas; i++){
        for(int j = 0; j < columnas; j++){
            printf("%c ", blanco[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

void calcular_puntajes(int puntajes[MAX_JUGADORES], char tiro, int puntaje) {
    for(int i = 0; i < MAX_JUGADORES; i++) {
        if (JUGADORES[i] == tiro){
            puntajes[i] += puntaje;
        }
    }
}

int posicion_mayor_puntaje(int puntajes[MAX_JUGADORES]){
    int posicion_mayor = POSICION_INVALIDA;
    int mayor = 0;
    for(int i = 0; i < MAX_JUGADORES; i++) {
        if (puntajes[i] > mayor) {
            mayor = puntajes[i];
            posicion_mayor = i;
        }
    }
    return posicion_mayor;
}

//Pre: filas y columnas deben corresponderse con el blanco.
//Post: Calcula los puntajes de los jugadores a partir del blanco.
// Devuelve el ganador que puede ser HOMERO o MOE, en caso de empate devuelve EMPATE.
char ganador_dardos(char blanco[MAX_FILAS][MAX_COLUMNAS], int filas, int columnas){
    int puntajes[MAX_JUGADORES] = {0,0,0};
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            char tiro = blanco[i][j];
            calcular_puntajes(puntajes, tiro, i*j);
        }
    }

    int posicion_mayor = posicion_mayor_puntaje(puntajes);
    
    return JUGADORES[posicion_mayor];
}

int main(){
    char blanco[MAX_FILAS][MAX_COLUMNAS];

    printf("=== Blanco con dos jugadores (Homero y Moe) ===\n");
    cargar_blanco_dos_jugadores(blanco);
    mostrar_blanco(blanco, MAX_FILAS, MAX_COLUMNAS);

    return 0;
}
