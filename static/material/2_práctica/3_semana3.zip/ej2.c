#include <stdio.h>
#include <stdbool.h>

// Ejercicio 2: el equipo de softball de la Planta Nuclear.
// Un jugador tiene inicial, numero de camiseta y promedio.
// Un equipo tiene varios jugadores y su posicion en el ranking.

#define MAX_JUGADORES 20
const int NRO_CAMISETA_MIN = 5;

typedef struct jugador{
    char inicial;
    int numero_camiseta;
    float promedio;
} jugador_t;

typedef struct equipo{
    jugador_t jugadores[MAX_JUGADORES];
    int cant_jugadores;
    int pos_ranking;
} equipo_t;

// pre: que cant_jugadores se corresponda con el vector jugadores del equipo 
// post: devuelve el jugador que tiene el mejor promedio y camiseta mayor a 5
jugador_t mejor_jugador(equipo_t equipo){
    jugador_t mejor_jugador;
    mejor_jugador.promedio = 0;
    for(int i = 0; i < equipo.cant_jugadores; i++){
        if(equipo.jugadores[i].numero_camiseta > NRO_CAMISETA_MIN){
            if(equipo.jugadores[i].promedio > mejor_jugador.promedio){
                mejor_jugador = equipo.jugadores[i];
            }
        }
    }
    return mejor_jugador;
}

// pre: -
// post: carga al jugador con los valores recibidos por parametro
void inicializar_jugador(jugador_t* jugador, char inicial, int numero_camiseta, float promedio){
    // (*jugador).inicial = inicial;
    jugador->inicial = inicial;
    jugador->numero_camiseta = numero_camiseta;
    jugador->promedio = promedio;
}   

int main(){

    return 0;
}
