#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>

#define MAX_OBJETOS 20
#define MAX_CUARTO 20

const int MOVIMIENTOS_INICIALES = 100;
const int FIL_INICIAL = 0;
const int COL_INICIAL = 0;
const int ROPA_INICIAL = 10;
const int JUGUETES_INICIAL = 5;
#define ARRIBA 'W'
#define ABAJO'S'
#define DERECHA 'D'
#define IZQUIERDA 'A'

typedef struct coordenada {
 int fil;
 int col;
} coordenada_t;

typedef struct jugador {
 coordenada_t posicion;
 int movimientos_restantes;
} jugador_t;

typedef struct juego {
 jugador_t jugador;
 coordenada_t ropa[MAX_OBJETOS];
 int tope_ropa;
 coordenada_t juguetes[MAX_OBJETOS];
 int tope_jueguetes;
} juego_t;


// Pre: -
// Post: carga los atributos del jugador: sus movimientos iniciles y su posición
void inicializar_jugador(jugador_t* jugador) {
    (*jugador).movimientos_restantes = MOVIMIENTOS_INICIALES;
    (*jugador).posicion.fil = FIL_INICIAL;
    (*jugador).posicion.col = COL_INICIAL;
}

//pre: Tope tiene que corresponderse con el vector de objetos. La cantidad tiene que ser 0 o mayor a 0.
//post: carga en el vector de objetos la cantidad inicial que recibe por parámetros y actualiza el tope 
void inicializar_objetos(coordenada_t objetos[MAX_OBJETOS], int* tope_objetos, int cantidad_inicial){
    for(int i = 0;i < cantidad_inicial;i++){
        objetos[i].fil = rand() % MAX_CUARTO;
        objetos[i].col = rand() % MAX_CUARTO;
        (*tope_objetos)++;
    }
}

// pre: -
// post: inicializa todos los campos del juego.
void inicializar_juego(juego_t* juego){
    inicializar_jugador(&((*juego).jugador));

    (*juego).tope_ropa = 0;
    (*juego).tope_jueguetes = 0;

    inicializar_objetos((*juego).ropa, 
    &((*juego).tope_ropa), ROPA_INICIAL);

    inicializar_objetos(juego->juguetes, 
    &(juego->tope_jueguetes), JUGUETES_INICIAL);
    
    // (con la flechita)
    // inicializar_ropa(juego->ropa, &juego->tope_ropa);
}

// pre: el jugador tiene que estar en una posicion valida del terreno. El movimiento tiene que ser valido (ARRIBA, ABAJO, IZQUIERDA o DERECHA).
// post: mueve al jugador segun el movimiento recibido, siempre que sea a una posicion valida del terreno.
void mover_jugador(juego_t* juego, char movimiento){
   if(movimiento == ARRIBA){
        if(juego->jugador.posicion.fil != 0){
            juego->jugador.posicion.fil --;
            juego->jugador.movimientos_restantes--;
        }
    }else if(movimiento == ABAJO){
        if(juego->jugador.posicion.fil != MAX_CUARTO - 1){
            juego->jugador.posicion.fil ++;
            juego->jugador.movimientos_restantes--;
        }
    }else if(movimiento == DERECHA){
        if(juego->jugador.posicion.col != MAX_CUARTO - 1){
            juego->jugador.posicion.col ++;
            juego->jugador.movimientos_restantes--;
        }
    }else{
        if(juego->jugador.posicion.col != 0){
            juego->jugador.posicion.col --;
            juego->jugador.movimientos_restantes--;
        }
    }
}

bool coordenadas_iguales(coordenada_t posicion_1, coordenada_t posicion_2){
    return posicion_1.fil == posicion_2.fil && posicion_1.col == posicion_2.col;
}

void realizar_accion(juego_t* juego){
    int i = 0;
    bool encontrado = false;
    while(i < juego->tope_ropa && !encontrado){
        if(coordenadas_iguales(juego->jugador.posicion, juego->ropa[i])){
            juego->ropa[i] = juego->ropa[juego->tope_ropa - 1];
            juego->tope_ropa--;
            encontrado = true;
        }
        i++;
    }
    // ... falta la acción para los juguetes
}


int main(){
    srand ((unsigned)time(NULL));
    juego_t juego;
    inicializar_juego(&juego);
    return 0;
}
