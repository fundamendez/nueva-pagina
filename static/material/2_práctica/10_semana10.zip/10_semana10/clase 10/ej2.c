#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "mochila.h"
#include <stdlib.h>

#define C_RESET   "\x1b[0m"
#define C_MOCHILA "\x1b[38;5;172m"
#define C_CORREA  "\x1b[38;5;130m"
#define C_TITULO  "\x1b[1;38;5;86m"
#define C_TEXTO   "\x1b[37m"
#define C_PESO    "\x1b[38;5;118m"
#define C_MATERIA "\x1b[38;5;207m"

#define MAX_NECESARIOS 10
#define CANT_MATERIAS 2
#define MAX_OBJETOS_NECESARIOS 2

const int ERROR = -1;
const int EXITO = 1;
const int CANTIDAD_A_FILTRAR = 1;
const float PESO_MINIMO = 0.8;

const char MATERIAS_A_ELIMINAR[CANT_MATERIAS][MAX_NOMBRE] = {"Fisica", "Literatura"};


void imprimir_mochila(mochila_t* mochila) {
    if (mochila == NULL) return;

    mochila_t* aux = mochila_crear();
    int posicion = 1;

    printf("\n");
    printf(C_CORREA "       _       " C_MOCHILA "_.--\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"--._\n" C_RESET);
    printf(C_CORREA "      / \\    " C_MOCHILA ".'                                                                                        '.\n" C_RESET);
    printf(C_CORREA "     |   |  " C_MOCHILA "/                                     " C_TITULO "M O C H I L A" C_MOCHILA "                                      \\\n" C_RESET);
    printf(C_CORREA "     |   | " C_MOCHILA "|========================================================================================|\n" C_RESET);
    printf(C_CORREA "      \\ /  " C_MOCHILA "|                                                                                        |\n" C_RESET);

    if (mochila_cantidad(mochila) == 0) {
        printf(C_CORREA "       | | " C_MOCHILA "|   " C_TEXTO "%-83s" C_MOCHILA "|\n" C_RESET, "(Mochila vacia)");
    }

    while (mochila_cantidad(mochila) > 0) {
        objeto_t obj = mochila_quitar(mochila);
        
        char materias_str[100] = "";
        for (int i = 0; i < obj.cantidad_materias; i++) {
            strcat(materias_str, "[");
            strcat(materias_str, obj.materias[i]);
            strcat(materias_str, "] ");
        }

        printf(C_CORREA "       | | " C_MOCHILA "|   " C_TEXTO "%2d. %-23s " C_PESO "(%.2f kg)" C_RESET " -> " C_MATERIA "%-41s" C_MOCHILA "   |\n" C_RESET, 
               posicion, obj.nombre, obj.peso, materias_str);
        
        mochila_agregar(aux, obj);
        posicion++;
    }

    printf(C_CORREA "       \\ / " C_MOCHILA "|                                                                                        |\n" C_RESET);
    printf(C_CORREA "        |   " C_MOCHILA "\\________________________________________________________________________________________/\n" C_RESET);
    printf(C_CORREA "       /___/ \n" C_RESET);

    while (mochila_cantidad(aux) > 0) {
        mochila_agregar(mochila, mochila_quitar(aux));
    }

    mochila_destruir(aux);
}

void llenar_mochila(mochila_t* mochila) {
    objeto_t obj1 = {"Libro de Fisica", 1.2f, {"Fisica"}, 1};
    objeto_t obj2 = {"Calculadora Cientifica", 0.3f, {"Fisica", "Matematica", "Quimica"}, 3};
    objeto_t obj3 = {"Antologia Poetica", 0.9f, {"Literatura"}, 1};
    objeto_t obj4 = {"Cuaderno rayado", 0.5f, {"Literatura", "Historia", "Geografia"}, 3};
    objeto_t obj5 = {"Carpeta pesada", 2.1f, {"Historia"}, 1};
    objeto_t obj6 = {"Set de Geometria", 0.4f, {"Matematica", "Dibujo"}, 2};
    objeto_t obj7 = {"Novela Clasica", 0.6f, {"Literatura"}, 1};
    objeto_t obj8 = {"Diccionario Ingles", 1.5f, {"Ingles"}, 1};

    mochila_agregar(mochila, obj1);
    mochila_agregar(mochila, obj2);
    mochila_agregar(mochila, obj3);
    mochila_agregar(mochila, obj4);
    mochila_agregar(mochila, obj5);
    mochila_agregar(mochila, obj6);
    mochila_agregar(mochila, obj7);
    mochila_agregar(mochila, obj8);
}

bool es_de_materia_buscada(objeto_t objeto){
    bool es_objeto_a_eliminar = false;
    if(objeto.cantidad_materias == CANTIDAD_A_FILTRAR){
        for(int i = 0; i < MAX_MATERIAS; i++){
            if(strcmp(objeto.materias[0], MATERIAS_A_ELIMINAR[i]) == 0){
                es_objeto_a_eliminar = true;
            }
        }
    }
    return es_objeto_a_eliminar;
}

int filtrar_mochila(mochila_t* mochila){
    mochila_t* aux = mochila_crear();
    if(!aux){
        printf("Error creando la mochila auxiliar");
        return ERROR;
    }

    while(mochila_cantidad(mochila) > 0){
        objeto_t objeto_a_revisar = mochila_quitar(mochila);
        if(!es_de_materia_buscada(objeto_a_revisar)){
            mochila_agregar(aux, objeto_a_revisar);
        }
    }

    while (mochila_cantidad(aux) > 0) {
        objeto_t objeto = mochila_quitar(aux);
        mochila_agregar(mochila, objeto);
    }
    
    return EXITO;
}

int agregar_objetos_faltantes(mochila_t* mochila, objeto_t objetos_necesarios[MAX_OBJETOS_NECESARIOS], int tope_objetos){
    mochila_t* aux = mochila_crear();
    if(!aux){
        printf("Error al crear la mochila auxiliar");
        return ERROR;
    }

    bool flag_objetos_necesarios[MAX_OBJETOS_NECESARIOS];
    for (int i = 0; i < MAX_OBJETOS_NECESARIOS; i++) {
        flag_objetos_necesarios[i] = false;
    }
    
    while (mochila_cantidad(mochila) > 0){
        objeto_t objeto = mochila_quitar(mochila);
        for(int i = 0; i < tope_objetos; i++){
            if(strcmp(objetos_necesarios[i].nombre,objeto.nombre) == 0){
                flag_objetos_necesarios[i] = true;
            }
        }
        mochila_agregar(aux, objeto);
    }

    while (mochila_cantidad(aux) > 0) {
        objeto_t objeto = mochila_quitar(aux);
        mochila_agregar(mochila, objeto);
    }
    
    for (int i = 0; i < MAX_OBJETOS_NECESARIOS; i++){
        if(flag_objetos_necesarios[i]){
            mochila_agregar(mochila, objetos_necesarios[i]);
        }
    }
    return EXITO;
}

int pasar_al_casillero(mochila_t* mochila, objeto_t* casillero, int* tope_casillero){
    mochila_t* aux = mochila_crear();
    if(!aux){
        printf("Error al crear la mochila auxiliar");
        return ERROR;
    }
    bool error = false;
    while (mochila_cantidad(mochila) > 0 && !error){
        objeto_t objeto = mochila_quitar(mochila);
        if(objeto.peso > PESO_MINIMO){
            objeto_t* casillero_aux = realloc(casillero, sizeof(objeto_t)*(*tope_casillero + 1));
            if(!casillero_aux){
                printf("Error");
                error = true;
            }
            casillero_aux[*tope_casillero] = objeto;
           (*tope_casillero)++;
           casillero = casillero_aux;
        }
    }
    if(error){
        return ERROR;
    }

    while (mochila_cantidad(aux) > 0) {
        objeto_t objeto = mochila_quitar(aux);
        mochila_agregar(mochila, objeto);
    }
    return EXITO;
}

int main(void) {
    mochila_t* mochila = mochila_crear();
    if(!mochila){
        printf("Error creando la mochila");
        return ERROR;
    }

    llenar_mochila(mochila);
    imprimir_mochila(mochila);
    filtrar_mochila(mochila);
    imprimir_mochila(mochila);
    // FALTA HACER mochila_destruir()

    return 0;
}