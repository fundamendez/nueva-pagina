#include "mochila.h"
#include <stdlib.h>
#include <string.h>

/* --- ESTRUCTURAS INTERNAS --- */

typedef struct nodo {
    objeto_t objeto;
    struct nodo* siguiente;
} nodo_t;

struct mochila {
    nodo_t* primer_nodo;
    int cantidad;
};

/* --- IMPLEMENTACIÓN DE FUNCIONES --- */

mochila_t* mochila_crear(void) {
    mochila_t* mochila = malloc(sizeof(mochila_t));
    if (mochila == NULL) {
        return NULL;
    }
    
    mochila->primer_nodo = NULL;
    mochila->cantidad = 0;
    
    return mochila;
}

bool mochila_agregar(mochila_t* mochila, objeto_t objeto) {
    if (mochila == NULL) {
        return false;
    }
    
    nodo_t* nuevo_nodo = malloc(sizeof(nodo_t));
    if (nuevo_nodo == NULL) {
        return false;
    }
    
    nuevo_nodo->objeto = objeto;
    
    // Se inserta en la cima de la pila
    nuevo_nodo->siguiente = mochila->primer_nodo;
    mochila->primer_nodo = nuevo_nodo;
    mochila->cantidad++;
    
    return true;
}

int mochila_cantidad(mochila_t* mochila) {
    if (mochila == NULL) {
        return 0;
    }
    return mochila->cantidad;
}

objeto_t mochila_quitar(mochila_t* mochila) {
    // Si la mochila es inválida o está vacía, devolvemos un struct inicializado en 0
    if (mochila == NULL || mochila->cantidad == 0) {
        objeto_t objeto_vacio = {0};
        return objeto_vacio;
    }
    
    // 1. Apuntamos al nodo de la cima y guardamos el objeto a devolver
    nodo_t* nodo_a_quitar = mochila->primer_nodo;
    objeto_t objeto_extraido = nodo_a_quitar->objeto;
    
    // 2. Actualizamos la mochila para que apunte al siguiente nodo
    mochila->primer_nodo = nodo_a_quitar->siguiente;
    
    // 3. Liberamos la memoria del nodo que sacamos
    free(nodo_a_quitar);
    mochila->cantidad--;
    
    // 4. Devolvemos el objeto para que lo proceses
    return objeto_extraido;
}

void mochila_destruir(mochila_t* mochila) {
    if (mochila == NULL) {
        return;
    }
    
    nodo_t* nodo_actual = mochila->primer_nodo;
    while (nodo_actual != NULL) {
        nodo_t* nodo_auxiliar = nodo_actual;
        nodo_actual = nodo_actual->siguiente;
        free(nodo_auxiliar);
    }
    
    free(mochila);
}