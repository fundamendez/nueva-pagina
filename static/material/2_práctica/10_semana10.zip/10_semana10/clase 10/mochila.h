#ifndef MOCHILA_H
#define MOCHILA_H


#include <stdbool.h>

#define MAX_NOMBRE 50
#define MAX_MATERIAS 10


typedef struct {
   char nombre[MAX_NOMBRE];
   float peso; // En Kilogramos
   char materias[MAX_MATERIAS][MAX_NOMBRE];
   int cantidad_materias;
} objeto_t;


typedef struct mochila mochila_t;


/*
* Post: Crea una mochila vacía.
* Devuelve un puntero a la mochila o NULL si ocurre un error.
*/
mochila_t* mochila_crear(void);


/*
* Pre: La mochila fue creada y no fue destruida.
* Post: Agrega una copia del objeto al inicio de la mochila.
* Devuelve true si pudo agregarlo o false si ocurrió un error.
*/
bool mochila_agregar(mochila_t* mochila, objeto_t objeto);


/*
* Pre: La mochila fue creada y no fue destruida.
* Post: Devuelve la cantidad de objetos guardados.
*/
int mochila_cantidad(mochila_t* mochila);


/*
* Pre: La mochila fue creada y no fue destruida.
* Post: Quita el último objeto agregado de la mochila.
*	 Devuelve una copia del objeto quitado.
*/
objeto_t mochila_quitar(mochila_t* mochila);


/*
* Pre: La mochila fue creada y no fue destruida.
* Post: Libera toda la memoria utilizada por la mochila.
*/
void mochila_destruir(mochila_t* mochila);


#endif
