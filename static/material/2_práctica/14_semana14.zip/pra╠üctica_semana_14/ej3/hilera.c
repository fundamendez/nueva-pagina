#include <stdio.h>
#include <stdlib.h>
#include "hilera.h"

// Definición del struct interno de la hilera
struct hilera {
    alumno_t* primero;
};

hilera_t* hilera_crear() {
    hilera_t* h = malloc(sizeof(hilera_t));
    if (!h) return NULL;

    h->primero = NULL;
    return h;
}

void hilera_destruir(hilera_t* hilera) {
    if (!hilera) return;

    alumno_t* actual = hilera->primero;
    while (actual) {
        alumno_t* prox = actual->siguiente;
        free(actual);
        actual = prox;
    }

    free(hilera);
}

void hilera_agregar_al_inicio(hilera_t* hilera, int id) {
    if (!hilera) return;

    alumno_t* nuevo = malloc(sizeof(alumno_t));
    nuevo->id = id;
    nuevo->siguiente = hilera->primero;

    hilera->primero = nuevo;
}

void hilera_agregar_al_final(hilera_t* hilera, int id) {
    if (!hilera) return;

    alumno_t* nuevo = malloc(sizeof(alumno_t));
    nuevo->id = id;
    nuevo->siguiente = NULL;

    if (hilera->primero == NULL) {
        hilera->primero = nuevo;
        return;
    }

    alumno_t* actual = hilera->primero;
    while (actual->siguiente != NULL) {
        actual = actual->siguiente;
    }

    actual->siguiente = nuevo;
}

int* hilera_quitar_primero(hilera_t* hilera) {
    if (!hilera || !hilera->primero) return NULL;

    alumno_t* borrado = hilera->primero;
    hilera->primero = borrado->siguiente;

    int* id_devuelto = malloc(sizeof(int));
    *id_devuelto = borrado->id;

    free(borrado);
    return id_devuelto;
}

int* hilera_quitar_ultimo(hilera_t* hilera) {
    if (!hilera || !hilera->primero) return NULL;

    alumno_t* actual = hilera->primero;

    if (actual->siguiente == NULL) {
        int* id_devuelto = malloc(sizeof(int));
        *id_devuelto = actual->id;
        free(actual);
        hilera->primero = NULL;
        return id_devuelto;
    }

    while (actual->siguiente->siguiente != NULL) {
        actual = actual->siguiente;
    }

    alumno_t* borrado = actual->siguiente;
    actual->siguiente = NULL;

    int* id_devuelto = malloc(sizeof(int));
    *id_devuelto = borrado->id;

    free(borrado);
    return id_devuelto;
}

alumno_t* hilera_primero(hilera_t* hilera) {
    if (!hilera) return NULL;
    return hilera->primero;
}