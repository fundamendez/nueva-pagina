#ifndef HILERA_H
#define HILERA_H

#include <stdbool.h>

// Nodo de la lista enlazada (alumno en la fila)
typedef struct alumno {
    int id;
    struct alumno* siguiente;   // NULL si es el final de la fila
} alumno_t;

// Tipo abstracto de la hilera de alumnos
typedef struct hilera hilera_t;

/**
 * Pre: -
 * Post: Devuelve una hilera vacía reservada en el heap,
 *       o NULL si la reserva falla.
 */
hilera_t* hilera_crear();

/**
 * Pre: `hilera` fue creada correctamente.
 * Post: Se libera toda la memoria asociada a la hilera.
 */
void hilera_destruir(hilera_t* hilera);

/**
 * Pre: `hilera` fue creada correctamente.
 * Post: Agrega un nuevo alumno con ese id al comienzo de la fila
 *       (el primero en ser atendido).
 */
void hilera_agregar_al_inicio(hilera_t* hilera, int id);

/**
 * Pre: `hilera` fue creada correctamente.
 * Post: Agrega un nuevo alumno con ese id al final de la fila
 *       (el último en ser atendido).
 */
void hilera_agregar_al_final(hilera_t* hilera, int id);

/**
 * Pre: `hilera` fue creada correctamente y no está vacía.
 * Post: Elimina al primer alumno de la fila y devuelve un puntero a su id.
 */
int* hilera_quitar_primero(hilera_t* hilera);

/**
 * Pre: `hilera` fue creada correctamente y no está vacía.
 * Post: Elimina al último alumno de la fila y devuelve un puntero a su id.
 */
int* hilera_quitar_ultimo(hilera_t* hilera);

/**
 * Pre: `hilera` fue creada correctamente.
 * Post: Devuelve un puntero al primer alumno en la fila,
 *       o NULL si está vacía.
 */
alumno_t* hilera_primero(hilera_t* hilera);

#endif // HILERA_H
