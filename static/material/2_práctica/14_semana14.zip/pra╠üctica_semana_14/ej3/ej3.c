#include <stdio.h>
#include <stdlib.h>
#include "hilera.h"

const int ERROR = -1;

// Pre: La hilera tiene que ser creada con crear_hilera()
// Pos: Se retorna la cantidad de alumnos en la hilera
int contar_alumnos_hilera(hilera_t* hilera_alumnos){
    if(!hilera_alumnos){
        printf("La hilera no fue creada correctamente, no se pueden contar los alumnos\n");
        return ERROR;
    }

    int contador = 0;
    alumno_t* alumno_actual = hilera_primero(hilera_alumnos);

    while(alumno_actual != NULL){
        contador++;
        alumno_actual = alumno_actual->siguiente;
    }

    return contador;
}

// Pre: Hilera tiene que ser creada con crear_hilera()
// Pos: Retorna el alumno al cual le pertenece el id_buscado si lo encuentra, o NULL en cualquier otro caso

alumno_t* alumno_buscado(hilera_t* hilera_alumnos, int id_buscado){
    if(!hilera_alumnos){
        printf("No puedo buscar a los alumnos en la hilera\n");
        return NULL;
    }

    bool encontrado = false;
    alumno_t* alumno_actual = hilera_primero(hilera_alumnos);

    while(alumno_actual != NULL && !encontrado){
        if(alumno_actual->id == id_buscado){
            encontrado = true;
        }else{
            alumno_actual = alumno_actual->siguiente;
        }
    }

    return alumno_actual;
}

// Pre: Hilera tiene que ser creada con crear_hilera()
// Pos: Inserta al alumno en la posicion buscada. Si la posicion no es valida (< 0) retorna NULL
void insertar_alumno(hilera_t* hilera_alumnos, int id, int posicion_buscada){
    if(!hilera_alumnos){
        printf("No puedo insertar alumnos en esta hilera \n");
        return;
    }

    if(posicion_buscada < 0){
        printf("Mandame una posicion real!!!\n");
        return;
    }

    if(posicion_buscada == 0){
        hilera_agregar_al_inicio(hilera_alumnos, id);
        return;
    }

    alumno_t* alumno_actual = hilera_primero(hilera_alumnos);
    int pos_actual = 0;

    while(alumno_actual != NULL && pos_actual < posicion_buscada - 1){
        alumno_actual = alumno_actual->siguiente;
        pos_actual++;
    }

    if(alumno_actual == NULL){
        hilera_agregar_al_final(hilera_alumnos, id);
        return;
    }

    alumno_t* nuevo_alumno = malloc(sizeof(alumno_t));
    if(!nuevo_alumno){
        printf("Uy no se pudo crear correctamente el nuevo alumno\n");
        return;
    }

    nuevo_alumno->id = id;

    nuevo_alumno->siguiente = alumno_actual->siguiente;

    alumno_actual->siguiente = nuevo_alumno;

}


void imprimir_hilera(hilera_t* hilera_alumnos) {
    if (!hilera_alumnos) {
        printf("Hilera NULL\n");
        return;
    }
    
    alumno_t* actual = hilera_primero(hilera_alumnos);
    
    if (actual == NULL) {
        printf("Hilera vacía\n");
        return;
    }
    
    printf("Hilera: ");
    while (actual != NULL) {
        printf("[%d] -> ", actual->id);
        actual = actual->siguiente;
    }
    printf("NULL\n");
}

int main() {

    hilera_t* hilera_alumnos = hilera_crear();
    
    hilera_agregar_al_final(hilera_alumnos, 10);
    hilera_agregar_al_final(hilera_alumnos, 20);
    hilera_agregar_al_final(hilera_alumnos, 30);
    imprimir_hilera(hilera_alumnos);

    int cantidad_alumnos = contar_alumnos_hilera(hilera_alumnos);
    printf("La cantidad de alumnos es: %i\n", cantidad_alumnos);

    alumno_t* alumno_encontrado = alumno_buscado(hilera_alumnos, 40);
    if(alumno_encontrado){
        printf("Encontramos al alumno! Su ID: %i\n", alumno_encontrado->id);
    }else{
        printf("No se encontro ese alumno!\n");
    }

    insertar_alumno(hilera_alumnos, 15, 1);
    imprimir_hilera(hilera_alumnos); 
    
    hilera_destruir(hilera_alumnos);
    
    return 0;
}