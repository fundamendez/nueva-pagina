#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "sala.h"

const int ERROR = -1;
const int EXITO = 0;

const char* MOTIVO_INVALIDO = "exceso de facha";


// PRE: recibe una sala correctamente inicializada con sala_crear()
// POST: imprime todos los pacientes de la sala
void imprimir_sala(sala_t* sala) {
    if (!sala) return;

    sala_t* aux = sala_crear();
    if (!aux) return;

    paciente_t p;

    while (atender_paciente(sala, &p)) {
        printf("Nombre: %s | Edad: %d | Motivo: %s | Urgencia: %s\n",
               p.nombre,
               p.edad,
               p.motivo_consulta,
               p.es_urgencia ? "SI" : "NO");

        agregar_paciente(aux, p);
    }

    while (atender_paciente(aux, &p)) {
        agregar_paciente(sala, p);
    }

    sala_destruir(aux);
}

// PRE: recibe una sala correctamente inicializada con sala_crear()
// POST: agrega pacientes a la sala general que recibe por parámetros. 
void inicializar_sala_general(sala_t* sala_general){
    agregar_paciente(sala_general, (paciente_t){"Milhouse", 10, "caida", false});
    agregar_paciente(sala_general, (paciente_t){"Burns", 104, "dolor de pecho", true});
    agregar_paciente(sala_general, (paciente_t){"Homero", 39, "dolor de panza", false});
    agregar_paciente(sala_general, (paciente_t){"Moe", 47, "fiebre", true});
    agregar_paciente(sala_general, (paciente_t){"Disco Stu", 40, "exceso de facha", false});
    agregar_paciente(sala_general, (paciente_t){"Bart", 10, "raspon", false});
}



// PRE: recibe una sala general correctamente inicializada con sala_crear() y una sala de urgencias correctamente inicializada con sala_crear()
// POST: 
int identificar_consultas(sala_t* sala_general, sala_t* sala_urgencias){

    sala_t* sala_aux = sala_crear();
    if(!sala_aux) {
        printf("Hubo un error creando la sala general\n");
        return ERROR;
    }

    paciente_t paciente_aux;

    while(atender_paciente(sala_general, &paciente_aux)){
        if(strcmp(paciente_aux.motivo_consulta, MOTIVO_INVALIDO) != 0){
            if(paciente_aux.es_urgencia) {
                agregar_paciente(sala_urgencias, paciente_aux);
            } else {
                agregar_paciente(sala_aux, paciente_aux);
            }
        }
    }

    // ACLARACION: se puede volcar el contenido de una a otra o usar doble referencia.
    while(atender_paciente(sala_aux, &paciente_aux)){
        agregar_paciente(sala_general, paciente_aux);
    }

    sala_destruir(sala_aux);

    // si usaramos doble puntero
    // sala_destruir(*sala_general);
    // *sala_general = sala_aux;

    return EXITO;

}





int main() {

    sala_t* sala_general = sala_crear();
    if(!sala_general) {
        printf("Hubo un error creando la sala general\n");
        return ERROR;
    }

    sala_t* sala_urgencias = sala_crear();
    if(!sala_urgencias) {
        printf("Hubo un error creando la sala de urgencias\n");
        return ERROR;
    }
    
    inicializar_sala_general(sala_general);
    imprimir_sala(sala_general);

    identificar_consultas(sala_general, sala_urgencias);

    printf("\n\n\nSALA GENERAL\n");
    imprimir_sala(sala_general);



    printf("\n\n\n\nSALA URGENCIAS\n");
    imprimir_sala(sala_urgencias);


    sala_destruir(sala_urgencias);
    sala_destruir(sala_general);

    return 0;
}
