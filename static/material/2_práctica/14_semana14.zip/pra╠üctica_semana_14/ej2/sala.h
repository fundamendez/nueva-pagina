#ifndef SALA_H
#define SALA_H
#include <stdbool.h>

typedef struct paciente {
    char* nombre;
    int edad;
    char* motivo_consulta;   // "dolor de pecho", "fiebre", "exceso de facha", "caída", etc.
    bool es_urgencia;        // true si debe ir directo a urgencias
} paciente_t;

typedef struct sala sala_t;

// Post: Crea un TDA sala. Devuelve un puntero a una sala si se pudo crear o NULL en caso de error.
sala_t* sala_crear();

// Pre: `sala` fue creado usando sala_crear().
// Post: Agrega un paciente a la sala. Devuelve true si se pudo agregar, false en caso contrario.
bool agregar_paciente(sala_t* sala, paciente_t paciente);

// Pre: `sala` fue creado usando sala_crear().
// Post: Devuelve en paciente el primer paciente agregado a la sala, quitándolo de la misma. Devuelve true si se pudo sacar, false en caso contrario.
bool atender_paciente(sala_t* sala, paciente_t* paciente);


// Pre: `sala` fue creado usando sala_crear().
// Post: Destruye la sala creada.
void sala_destruir(sala_t* sala);

#endif