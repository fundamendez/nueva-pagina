#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sala.h"


typedef struct nodo {
    paciente_t paciente;
    struct nodo* siguiente;
} nodo_t;

struct sala {
    nodo_t* primero;  
    nodo_t* ultimo;
};

sala_t* sala_crear() {
    sala_t* sala = malloc(sizeof(sala_t));
    if (!sala) return NULL;

    sala->primero = NULL;
    sala->ultimo = NULL;
    return sala;
}

bool agregar_paciente(sala_t* sala, paciente_t paciente) {
    if (!sala) return false;

    nodo_t* nuevo = malloc(sizeof(nodo_t));
    if (!nuevo) return false;

    nuevo->paciente = paciente;
    nuevo->siguiente = NULL;

    if (sala->ultimo) {
        sala->ultimo->siguiente = nuevo;
    } else {
        sala->primero = nuevo;
    }

    sala->ultimo = nuevo;
    return true;
}

bool atender_paciente(sala_t* sala, paciente_t* paciente) {
    if (!sala || !sala->primero) {
        return false;
    }

    nodo_t* aux = sala->primero;

    if (paciente) {
        *paciente = aux->paciente;
    }

    sala->primero = aux->siguiente;

    if (sala->primero == NULL) {
        sala->ultimo = NULL;
    }

    free(aux);
    return true;
}

void sala_destruir(sala_t* sala) {
    if (!sala) return;

    nodo_t* act = sala->primero;
    while (act) {
        nodo_t* prox = act->siguiente;
        free(act);
        act = prox;
    }

    free(sala);
}
