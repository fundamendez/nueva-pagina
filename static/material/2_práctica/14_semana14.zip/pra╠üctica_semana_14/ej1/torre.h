#ifndef TORRE_H
#define TORRE_H
#include <stdbool.h>

#define MAX_COLOR 10

typedef struct bloque {
    char letra;
    char color[MAX_COLOR];
} bloque_t;

typedef struct torre torre_t;

// Post: Crea un TDA torre. Devuelve un puntero a una torre si se pudo crear o NULL en caso de error.
torre_t* torre_crear();

// Pre: `torre` fue creado usando torre_crear().
// Post: Agrega un bloque a la torre. Devuelve true si se pudo agregar, false en caso contrario.
bool torre_apilar(torre_t* torre, bloque_t bloque);

// Pre: `torre` fue creado usando torre_crear().
// Post: Devuelve en bloque_sacado el último bloque agregado a la torre, quitándolo de la misma. Devuelve true si se pudo sacar, false en caso contrario.
bool torre_desapilar(torre_t* torre, bloque_t* bloque_sacado);

// Pre: `torre` fue creado usando torre_crear().
// Post: Destruye la torre creada.
void torre_destruir(torre_t* torre);

#endif
