#include "torre.h"
#include <stdio.h>
#include <string.h>

const int ERROR = -1;
const int EXITO = 0;


// pre: recibe una torre creada por torre_crear(), color_a_eliminar termina en '\0'.
// post: elimina los bloques que tienen el color color_a_eliminar de la torre, devuelve EXITO si finaliza correctamente, ERROR en caso de que no se pueda crear la torre o no se pueda apilar algun bloque.
int eliminar_bloques_por_color(torre_t* torre, char color_a_eliminar[MAX_COLOR]){
    torre_t* torre_aux = torre_crear();
    if(!torre_aux){
        printf("No se pudo crear la torre auxiliar\n");
        return ERROR;
    }

    bloque_t bloque;
    bool pudo_apilar = true;
    while(torre_desapilar(torre, &bloque) && pudo_apilar){
        if(strcmp(bloque.color, color_a_eliminar) != 0){
            pudo_apilar = torre_apilar(torre_aux, bloque);
        }
    }

    while(torre_desapilar(torre_aux, &bloque) && pudo_apilar){
        pudo_apilar = torre_apilar(torre, bloque);
    }

    torre_destruir(torre_aux);

    if(!pudo_apilar){
        printf("Hubo un error al apilar\n");
        return ERROR;
    }

    return EXITO;
}

int main() {
    torre_t* torre = torre_crear();
    if(!torre){
        return ERROR;
    }

    bloque_t b1 = {'A', "rojo"};
    bloque_t b2 = {'B', "verde"};
    bloque_t b3 = {'C', "rojo"};
    bloque_t b4 = {'D', "azul"};

    torre_apilar(torre, b4);
    torre_apilar(torre, b3);
    torre_apilar(torre, b2);
    torre_apilar(torre, b1);

    eliminar_bloques_por_color(torre, "rojo");

    bloque_t aux;
    printf("Contenido final:\n");
    while (torre_desapilar(torre, &aux)) {
        printf("%c (%s)\n", aux.letra, aux.color);
    }

    torre_destruir(torre);
    return 0;
}