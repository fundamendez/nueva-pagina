#include <stdio.h>
#include <stdlib.h>
#include "torre.h"

typedef struct nodo {
    bloque_t dato;
    struct nodo* sig;
} nodo_t;

struct torre {
    nodo_t* tope;
};

torre_t* torre_crear() {
    torre_t* t = malloc(sizeof(torre_t));
    if (!t) return NULL;
    t->tope = NULL;
    return t;
}

bool torre_apilar(torre_t* torre, bloque_t bloque) {
    if (!torre) return false;

    nodo_t* nuevo = malloc(sizeof(nodo_t));
    if (!nuevo) return false;

    nuevo->dato = bloque;
    nuevo->sig = torre->tope;
    torre->tope = nuevo;
    return true;
}

bool torre_desapilar(torre_t* torre, bloque_t* bloque_sacado) {
    if (!torre || !torre->tope) return false;

    nodo_t* aux = torre->tope;
    *bloque_sacado = aux->dato;
    torre->tope = aux->sig;
    free(aux);
    return true;
}

void torre_destruir(torre_t* torre) {
    if (!torre) return;

    nodo_t* act = torre->tope;
    while (act) {
        nodo_t* sig = act->sig;
        free(act);
        act = sig;
    }
    free(torre);
}