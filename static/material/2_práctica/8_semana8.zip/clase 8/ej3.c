#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cuestionario_invitado.h"

#define MAX_NOMBRE 50

typedef struct invitado {
    char nombre_invitado[MAX_NOMBRE];
    int edad;
    char tipo_acceso; // 'P' (Platea), 'V' (VIP), 'C' (Campo de juego)
} invitado_t;

typedef struct miembro_plantel {
    char nombre_miembro[MAX_NOMBRE];
    char rol; // 'J' (Jugador), 'T' (Cuerpo Técnico), 'S' (Staff/Dirigente)
    invitado_t* invitados;
    int cantidad_invitados;
} miembro_plantel_t;

const int ERROR = -1;
const int EXITO = 0;

// Pre: el tope debe coincidir con la cantidad de miembros en vector.
// Post: Imprime las entradas repartidas de los distintos miembros del plantel. 
void imprimir_plantel(miembro_plantel_t* plantel, int tope) {
    printf("\n ============ Entradas Repartidas ============\n");
    for(int i = 0; i < tope; i++) {
        printf("👤 [%c] %s (%d invitados)\n", plantel[i].rol, plantel[i].nombre_miembro, plantel[i].cantidad_invitados);
        for(int j = 0; j < plantel[i].cantidad_invitados; j++) {
            printf("   🎟️  -> %s (Acceso a: %c)\n", plantel[i].invitados[j].nombre_invitado, plantel[i].invitados[j].tipo_acceso);
        }
    }
    printf("\n");
}

// pre: recibe por referencia el miembro del plantel.
// post: crea el vector de invitados y los inicializa. En caso de exito devuelve EXITO (0), en caso de error reservando memoria devuelve ERROR (-1)
int inicializar_invitados(miembro_plantel_t* persona) {
    int cantidad_invitados = 0;
    int tope_invitados = 0;
    printf("¿Cuantos invitados tenés?\n");
    scanf("%i", &cantidad_invitados);

    invitado_t* invitados = malloc(sizeof(invitado_t) * cantidad_invitados);
    if(!invitados){
        printf("hubo un error inicializando los invitados\n");
        return ERROR;
    }
    for(int i=0; i<cantidad_invitados; i++){
        invitado_t invitado;
        preguntar_nombre_invitado(invitado.nombre_invitado);
        preguntar_edad_invitado(&invitado.edad);
        preguntar_tipo_acceso(&invitado.tipo_acceso);
        invitados[tope_invitados] = invitado;
        tope_invitados++;
    }

    persona->invitados = invitados;
    persona->cantidad_invitados = tope_invitados;

    return EXITO;
}

// Pre: 
// Post: Pide al usuario el nombre para un miembro del plantel.
void preguntar_nombre_miembro_plantel(char nombre[MAX_NOMBRE]){
    printf("como te llamas mi rey o reina o monarca\n");
    scanf("%s", nombre);
}


// Pre: 
// Post: Pide al usuario el rol para un miembro del plantel.
void preguntar_rol(char* rol){
    // Falta validar que el rol sea válido!!!!!
    printf("cual es tu rol?????? 'J' (Jugador), 'T' (Cuerpo Técnico), 'S' (Staff/Dirigente)\n");
    scanf(" %c", rol);
}

// Pre: cantidad_miembros debe corresponderse con la cantidad en el vector, plantel debe ser un puntero no nulo.
// Post: Libera la memoria para el plantel y para cada uno de sus miembros. 
void liberar_plantel(miembro_plantel_t* plantel, int cantidad_miembros){
    for(int i = 0; i < cantidad_miembros; i++){
        free(plantel[i].invitados);
    }
    free(plantel);
}

// pre: Recibe la cantidad de miembros del plantel a inicializar.
// post: devuelve un puntero a un plantel con todos sus miembros inicializados en caso de éxito, y en caso de error devuelve NULL.
miembro_plantel_t* crear_plantel(int cantidad_miembros){
    miembro_plantel_t* plantel = malloc(sizeof(miembro_plantel_t)* cantidad_miembros);
    if(!plantel){
        printf("hubo un error inicializando el plantel\n");
        return NULL;
    }

    int i = 0;
    int resultado = EXITO;
    while(i<cantidad_miembros && resultado != ERROR) {
        preguntar_nombre_miembro_plantel(plantel[i].nombre_miembro);
        preguntar_rol(&plantel[i].rol);
        resultado = inicializar_invitados(&plantel[i]);
        if(resultado == ERROR){
            liberar_plantel(plantel, i);
            plantel = NULL;
        }
        i++;
    }
    return plantel;
}


int main() {
    int cantidad_miembros = 3;
    miembro_plantel_t* plantel = crear_plantel(cantidad_miembros);
    if(!plantel) {
        printf("No se pudo crear el plantel\n");
        return ERROR;
    }
    imprimir_plantel(plantel, cantidad_miembros);
    liberar_plantel(plantel, cantidad_miembros);

    return EXITO;
}

