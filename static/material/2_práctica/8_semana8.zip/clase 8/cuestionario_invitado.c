#include "cuestionario_invitado.h"

const char PLATEA = 'P';
const char VIP = 'V';
const char CAMPO_DE_JUEGO = 'C';

const int EDAD_MINIMA = 0;
const int EDAD_MAXIMA = 100;


// pre: -
// post: se guarda en el invitado el nombre del visitante ingresado por el usuario.
void preguntar_nombre_invitado(char *invitado_nombre) {
    printf("Ingrese el nombre del visitante: ");
    scanf("%s", invitado_nombre);
}

bool es_sector_valido(char tipo_acceso){
    return tipo_acceso == PLATEA || tipo_acceso == VIP || tipo_acceso == CAMPO_DE_JUEGO;
}


void preguntar_tipo_acceso(char *tipo_acceso) {
    printf("Ingrese el tipo de acceso permitido: ");
    scanf(" %c", tipo_acceso);
    while(!es_sector_valido(*tipo_acceso)) {
        printf("El tipo de acceso no es valido. Recuerde que las opciones son: \n(%c), (%c) y (%c). \nIngrese el tipo de acceso nuevamente: ", PLATEA, VIP, CAMPO_DE_JUEGO);
        scanf(" %c", tipo_acceso);
    }
}

bool es_edad_valida(int edad) {
    return edad > EDAD_MINIMA && edad <= EDAD_MAXIMA;
}

void preguntar_edad_invitado(int *edad) {
    printf("Ingrese la edad del invitado: ");
    scanf("%d", edad);
    while(*edad < EDAD_MINIMA || *edad > EDAD_MAXIMA) {
        printf("La edad no puede ser negativa ni mayor a 100. Ingrese la edad nuevamente: ");
        scanf("%d", edad);
    }
}