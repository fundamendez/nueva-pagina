#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define MAX_NOMBRE 50
const int ERROR = -1;
const int EXITO = 0;

typedef struct invitado {
    char nombre[MAX_NOMBRE];
    int altura_cm;
    bool amigable;
} invitado_t;


// pre: cantidad se tiene que corresponder con el vector invitados
// post: imprime por pantalla los invitados
void mostrar_invitados(invitado_t* invitados, int cantidad){
    for(int i = 0; i < cantidad; i++){
        printf("- %s, %i cm, %s\n", invitados[i].nombre, invitados[i].altura_cm,
               invitados[i].amigable ? "amigable" : "no amigable");
    }
}


void inicializar_invitado(invitado_t* invitado,char* nombre, int altura_cm, bool es_amigable){
    strcpy(invitado->nombre, nombre);
    invitado->altura_cm = altura_cm;
    invitado->amigable = es_amigable;
}

invitado_t* agregar_invitado(invitado_t invitado, invitado_t* invitados, int* cantidad){
    invitado_t* invitados_aux = malloc(((*cantidad) + 1) * sizeof(invitado_t));

    if(!invitados_aux){
        printf("Error reasignando la memoria de invitados");
        return invitados;
    }

    for(int i = 0; i < (*cantidad); i++){
        invitados_aux[i] = invitados[i];
    }

    invitados_aux[(*cantidad)] = invitado;
    (*cantidad)++;

    free(invitados);

    return invitados_aux;
}

int main(){
    int cantidad_invitados = 3;
    invitado_t* invitados = malloc(cantidad_invitados * sizeof(invitado_t));

    if(!invitados){
        printf("Error asignando memoria a invitados");
        return ERROR;
    }

    inicializar_invitado(&invitados[0], "Milhouse", 120,true);
    inicializar_invitado(&invitados[1], "Nelson", 160,false);
    inicializar_invitado(&invitados[2], "Bart", 150,true);

    invitado_t invitado = {"Jimbo", 170, false};

    invitados = agregar_invitado(invitado, invitados, &cantidad_invitados);

    free(invitados);

    return EXITO;
}
