#ifndef __CUESTIONARIO_INVITADO_H__
#define __CUESTIONARIO_INVITADO_H__

#include <stdbool.h>
#include <stdio.h>

// pre: -
// post: carga el nombre del invitado con lo que ingresa el usuario
void preguntar_nombre_invitado(char *invitado_nombre);

// pre: -
// post: carga el tipo de acceso con lo que ingresa el usuario
void preguntar_tipo_acceso(char *tipo_acceso);

// pre: -
// post: carga la edad con el valor que ingresa el usuario
void preguntar_edad_invitado(int *edad);

// pre: -
// post: devuelve true si es un sector de la cancha, false si no
bool es_sector_valido(char tipo_acceso);


#endif