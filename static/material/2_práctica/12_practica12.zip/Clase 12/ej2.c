#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

const char* CORTOS_ESCUELA = "cortos_escuela.csv";
const char* CORTOS_CIUDAD = "cortos_ciudad.csv";
const char* PROGRAMA = "programa.csv";
const char* ESCRITURA = "w";
const char* LEER = "r";
const char* PALABRA_BURNS = "Excelente";
const int DURACION_MAXIMA = 8;
const int APROBADO = 'S';

#define FORMATO_LECTURA "%[^;];%[^;];%i;%c\n" 
#define FORMATO_ESCRITURA "%s;%s;%i;%c\n" 
#define ESCRIBIR "w"
#define LEER "r"
#define MAX_NOMBRE 100
const int ERROR = -1;
const int EXITO = 0;


typedef struct {
    char titulo[MAX_NOMBRE];
    char director[MAX_NOMBRE];
    int duracion;
    char aprobado;
} corto_t;

void visualizar_archivo(const char *path, const char *etiqueta) {
    FILE *f = fopen(path, "r");
    if (!f) {
        printf("[-] No se pudo abrir el archivo: %s\n", path);
        return;
    }

    corto_t c;
    printf("=========================================================\n");
    printf(" %s (%s)\n", etiqueta, path);
    printf("=========================================================\n");
    printf("%-35s | %-20s | %-8s | %-8s\n", "Título", "Director", "Duración", "Aprobado");
    printf("---------------------------------------------------------\n");

    while (fscanf(f, FORMATO_LECTURA, c.titulo, c.director, &c.duracion, &c.aprobado) == 4) {
        printf("%-35s | %-20s | %2d min   | %c\n", c.titulo, c.director, c.duracion, c.aprobado);
    }

    printf("=========================================================\n\n");
    fclose(f);
}

void imprimir_cortos_escuela(void) {
    visualizar_archivo("cortos_escuela.csv", "CORTOS DE LA ESCUELA");
}

void imprimir_cortos_ciudad(void) {
    visualizar_archivo("cortos_ciudad.csv", "CORTOS DE LA CIUDAD");
}

void imprimir_todos_los_cortos(void) {
    visualizar_archivo("programa.csv", "PROGRAMA FINAL DEL FESTIVAL");
}

//Pre: -
//Post: Devuelve true si el titulo contiene la PALABRA_BURNS. False en caso contrario
bool tiene_excelente(char* titulo){
    return(strstr(titulo, PALABRA_BURNS) != NULL);
}

//Pre: -
//Post: Devuelve true si aprobado es igual a APROBADO y si duracion es menor a DURACION MAXIMA. False en caso contrario
bool cumple_condiciones(char aprobado, int duracion){
    return (aprobado == APROBADO && duracion <= DURACION_MAXIMA);
}

// ESTA FUNCION LA MENCIONE EN CLASE PERO LA AGREGUE DESPUES! 
//Pre: El archivo tiene que estar abierto y tiene que estar abierto con el formato correspondiente
//Post: Escribe en archivo programa.
void escribir_en_programa(FILE* programa, corto_t corto){
    fprintf(programa, FORMATO_ESCRITURA, corto.titulo, corto.director, corto.duracion, corto.aprobado);
}



//Pre: Los archivos tienen que estar abiertos y tienen que estar abiertos en el formato correspondiente (FORMATO LECTURA).
//Post: Crea el archvio programa y lo escribe con los cortos que cumplan las condiciones pedidas ()
int crear_programa(FILE* archivo_escuela, FILE* archivo_ciudad){
    FILE* programa = fopen(PROGRAMA, ESCRITURA);
    if(!programa){
        printf("No se pudo crear/abrir el archivo programa");
        return ERROR;
    }
    corto_t corto_escuela;
    corto_t corto_ciudad;

    int leidos_escuela = fscanf(archivo_escuela,FORMATO_LECTURA, corto_escuela.titulo, corto_escuela.director, &corto_escuela.duracion, &corto_escuela.aprobado);

    int leidos_ciudad = fscanf(archivo_ciudad,FORMATO_LECTURA, corto_ciudad.titulo, corto_ciudad.director, &corto_ciudad.duracion, &corto_ciudad.aprobado);
    
    while (leidos_ciudad != EOF && leidos_escuela != EOF){
        if(strcmp(corto_escuela.titulo, corto_ciudad.titulo) <= 0){
            if(tiene_excelente(corto_escuela.titulo) || cumple_condiciones(corto_escuela.aprobado, corto_escuela.duracion)){
                escribir_en_programa(programa, corto_escuela);
            }
            leidos_escuela = fscanf(archivo_escuela,FORMATO_LECTURA, corto_escuela.titulo, corto_escuela.director, &corto_escuela.duracion, &corto_escuela.aprobado);
        }
        else{
            if(tiene_excelente(corto_ciudad.titulo) || cumple_condiciones(corto_ciudad.aprobado, corto_ciudad.duracion)){
                escribir_en_programa(programa, corto_ciudad);
            }
            leidos_ciudad = fscanf(archivo_ciudad,FORMATO_LECTURA, corto_ciudad.titulo, corto_ciudad.director, &corto_ciudad.duracion, &corto_ciudad.aprobado);
        }
    }
    
    while(leidos_ciudad != EOF){
        if(tiene_excelente(corto_ciudad.titulo) || cumple_condiciones(corto_ciudad.aprobado, corto_ciudad.duracion)){
            escribir_en_programa(programa, corto_ciudad);
        }
        leidos_ciudad = fscanf(archivo_ciudad,FORMATO_LECTURA, corto_ciudad.titulo, corto_ciudad.director, &corto_ciudad.duracion, &corto_ciudad.aprobado);
    }

    while (leidos_escuela != EOF){
        if(tiene_excelente(corto_escuela.titulo) || cumple_condiciones(corto_escuela.aprobado, corto_escuela.duracion)){
            escribir_en_programa(programa, corto_escuela);
        }
        leidos_escuela = fscanf(archivo_escuela,FORMATO_LECTURA, corto_escuela.titulo, corto_escuela.director, &corto_escuela.duracion, &corto_escuela.aprobado);
    }

    fclose(programa);
    return EXITO;
}



int main() {
    imprimir_cortos_escuela();
    imprimir_cortos_ciudad();

    FILE* archivo_escuela = fopen(CORTOS_ESCUELA, LEER);
    if(!archivo_escuela){
        printf("No se pudo abrir el archivo escuela");
        return ERROR;
    }

    FILE* archivo_ciudad = fopen(CORTOS_CIUDAD, LEER);
    if (!archivo_ciudad){
        fclose(archivo_escuela);
        printf("No se pudo abrir el archivo escuela");
        return ERROR;
    }
    
    crear_programa(archivo_escuela, archivo_ciudad);

    imprimir_todos_los_cortos();
    fclose(archivo_ciudad);
    fclose(archivo_escuela);
    return EXITO;
}