#include <stdio.h>
#include <stdbool.h>

#define ARCH_INCIDENTES "incidentes.csv"
#define ARCH_INCIDENTES_GRAVES "incidentes_graves.csv"

#define ESCRITURA "w"
#define LECTURA "r"

#define FORMATO_INCIDENTE_LECTURA "%[^;];%[^;];%[^;];%i;%c\n"
#define FORMATO_INCIDENTE_ESCRITURA "%s;%s;%s;%i;%c\n"

#define MAX_NOMBRE 60
#define MAX_ESTACION 50
#define MAX_FALLA 150

const int CANT_MIN_AFECTADA = 10;
const char NO_RESUELTO = 'N';

typedef struct incidente {
    char nombre[MAX_NOMBRE];
    char estacion[MAX_ESTACION];
    char tipo_falla[MAX_FALLA];
    int cant_pasajeros;
    char resuelto;
} incidente_t;



// Pre: -
// Post: devuelve si un incidente es grave (más de CANT_MIN_AFECTADA de pasajeros afectados y no está resuelto) o no
bool incidente_grave(incidente_t registro){
    return(registro.cant_pasajeros > CANT_MIN_AFECTADA && registro.resuelto == NO_RESUELTO);
}

// Pre: -
// Post: guarda en ARCH_INCIDENTES_GRAVES aquellos incidentes de ARCH_INCIDENTES que cumplan con las condiciones de ser grave (más de CANT_MIN_AFECTADA de pasajeros afectados y no está resuelto)
void registrar_incidentes_graves(){

    FILE* arch_incidentes = fopen(ARCH_INCIDENTES, LECTURA);
    if(!arch_incidentes){
        printf("No se pudo abrir el archivo %s\n", ARCH_INCIDENTES);
        return;
    }

    FILE* arch_incidentes_graves = fopen(ARCH_INCIDENTES_GRAVES, ESCRITURA);
    if(!arch_incidentes_graves){
        printf("No se pudo abrir el archivo %s\n", ARCH_INCIDENTES_GRAVES);
        fclose(arch_incidentes);
        return;
    }

    incidente_t registro;

    int leidos = fscanf(arch_incidentes, FORMATO_INCIDENTE_LECTURA, registro.nombre, registro.estacion, registro.tipo_falla, &(registro.cant_pasajeros), &(registro.resuelto));
    

    while(leidos != EOF) {

        if(incidente_grave(registro)){
            fprintf(arch_incidentes_graves, FORMATO_INCIDENTE_ESCRITURA, registro.nombre, registro.estacion, registro.tipo_falla, registro.cant_pasajeros, registro.resuelto);
        }

        leidos = fscanf(arch_incidentes, FORMATO_INCIDENTE_LECTURA, registro.nombre, registro.estacion, registro.tipo_falla, &(registro.cant_pasajeros), &(registro.resuelto));
    }

    fclose(arch_incidentes);
    fclose(arch_incidentes_graves);
}


int main() {

    registrar_incidentes_graves();

    return 0;
}
