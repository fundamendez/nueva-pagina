#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define COLOR_AMARILLO "\033[1;33m"
#define COLOR_CIAN     "\033[1;36m"
#define COLOR_VERDE    "\033[1;32m"
#define COLOR_ROJO     "\033[1;31m"
#define COLOR_RESET    "\033[0m"

#define MAX_ALUMNO 100
#define MAX_TITULO 150

typedef struct fecha {
    int anio;
    int mes;
    int dia;
} fecha_t;

typedef struct prestamo {
    int codigo_prestamo;
    char alumno[MAX_ALUMNO];
    char titulo[MAX_TITULO];
    fecha_t vencimiento;
} prestamo_t;

#define ARCHIVO_PRESTAMOS_VENCIDOS "prestamos_vencidos.csv"

#define FORMATO_PRESTAMO "%i;%[^;];%[^;];%i-%i-%i\n"
#define FORMATO_DEVOLUCION "%i\n"
#define FORMATO_VENCIDO "%i;%[^;];%[^;];%i;%i\n"
#define FORMATO_ESCRITURA_VENCIDO "%i;%s;%s;%i;%i\n"

#define VALOR_MULTA_DIARIA 50
#define DIAS_POR_MES 30
#define DIAS_POR_ANIO 360

const int CANTIDAD_ARGUMENTOS = 3;
const int EXITO = 0;
const int ERROR_ARGUMENTOS = -1;
const int ERROR_ARCHIVO = -2;
const int ARGUMENTO_ARCHIVO_PRESTAMOS = 1;
const int ARGUMENTO_ARCHIVO_DEVOLUCIONES = 2;
const fecha_t FECHA_ACTUAL = {2026, 11, 5};

/*
Pre: fecha debe estar inicializada.
Post: Devuelve la cantidad de díaas asumiendo meses fijos de 30 días y anios de 360 días.
*/
int dias_a_la_fecha(fecha_t fecha) {
    return (fecha.anio * DIAS_POR_ANIO) + (fecha.mes * DIAS_POR_MES) + fecha.dia;
}

/*
Pre: 'fecha_desde' y 'fecha_hasta' deben ser fechas inicializadas.
Post: Devuelve la cantidad de días transcurridos entre ambas fechas.
      El resultado es positivo si 'fecha_hasta' es posterior a 'fecha_desde', 
      cero si coinciden, o negativo si 'fecha_hasta' es anterior a 'fecha_desde'.
*/
int diferencia_en_dias(fecha_t fecha_desde, fecha_t fecha_hasta) {
    return dias_a_la_fecha(fecha_hasta) - dias_a_la_fecha(fecha_desde);
}

void mostrar_archivos_entrada(char *ruta_prestamos, char *ruta_devoluciones) {
    FILE *archivo_prestamos = fopen(ruta_prestamos, "r");
    FILE *archivo_devoluciones = fopen(ruta_devoluciones, "r");

    if (!archivo_prestamos) {
        printf("No se pudo abrir el archivo de prestamos: %s\n", ruta_prestamos);
        return;
    }
    if (!archivo_devoluciones) {
        fclose(archivo_prestamos);
        printf("No se pudo abrir el archivo de devoluciones: %s\n", ruta_devoluciones);
        return;
    }

    printf("=========================================================================================\n");
    printf("%s                                  REGISTRO DE PRESTAMOS                                  %s\n", COLOR_AMARILLO, COLOR_RESET);
    printf("=========================================================================================\n");

    prestamo_t prestamo;
    int leidos_prestamo = fscanf(archivo_prestamos, FORMATO_PRESTAMO,
                                 &prestamo.codigo_prestamo,
                                 prestamo.alumno,
                                 prestamo.titulo,
                                 &prestamo.vencimiento.anio,
                                 &prestamo.vencimiento.mes,
                                 &prestamo.vencimiento.dia);

    while (leidos_prestamo != EOF) {
        printf("  [%s#%-3d%s] %s%-20s%s  %-34s  [%s%04d-%02d-%02d%s]\n",
               COLOR_AMARILLO, prestamo.codigo_prestamo, COLOR_RESET,
               COLOR_CIAN, prestamo.alumno, COLOR_RESET,
               prestamo.titulo,
               COLOR_VERDE, prestamo.vencimiento.anio, prestamo.vencimiento.mes, prestamo.vencimiento.dia, COLOR_RESET);

        leidos_prestamo = fscanf(archivo_prestamos, FORMATO_PRESTAMO,
                                 &prestamo.codigo_prestamo,
                                 prestamo.alumno,
                                 prestamo.titulo,
                                 &prestamo.vencimiento.anio,
                                 &prestamo.vencimiento.mes,
                                 &prestamo.vencimiento.dia);
    }
    fclose(archivo_prestamos);
    printf("\n");

    printf("=========================================================================================\n");
    printf("%s                             BUZON DE DEVOLUCIONES DE LIBROS                             %s\n", COLOR_CIAN, COLOR_RESET);
    printf("=========================================================================================\n");

    int codigo_devuelto;
    int leidos_dev = fscanf(archivo_devoluciones, FORMATO_DEVOLUCION, &codigo_devuelto);
    while (leidos_dev != EOF) {
        printf("  Libro devuelto con codigo: %s#%d%s\n", COLOR_VERDE, codigo_devuelto, COLOR_RESET);
        leidos_dev = fscanf(archivo_devoluciones, FORMATO_DEVOLUCION, &codigo_devuelto);
    }
    fclose(archivo_devoluciones);
    printf("=========================================================================================\n\n");
}

void mostrar_resultados() {
    FILE *archivo_salida = fopen(ARCHIVO_PRESTAMOS_VENCIDOS, "r");

    if (!archivo_salida) {
        printf("No se pudo abrir el archivo de prestamos vencidos\n");
        return;
    }

    printf("=====================================================================================================\n");
    printf("%s                           PRESTAMOS VENCIDOS PENDIENTES Y MULTAS A COBRAR                           %s\n", COLOR_ROJO, COLOR_RESET);
    printf("=====================================================================================================\n");

    int codigo, dias_atraso, multa;
    char alumno[MAX_ALUMNO];
    char titulo[MAX_TITULO];
    int total_vencidos = 0;
    int total_multas = 0;

    int leidos = fscanf(archivo_salida, FORMATO_VENCIDO,
                        &codigo, alumno, titulo, &dias_atraso, &multa);

    while (leidos != EOF) {
        printf("  [%s#%-3d%s] %s%-20s%s  %-34s  [%sAtraso: %2d dias%s]  [%sMulta: $%4d%s]\n",
               COLOR_ROJO, codigo, COLOR_RESET,
               COLOR_AMARILLO, alumno, COLOR_RESET,
               titulo,
               COLOR_ROJO, dias_atraso, COLOR_RESET,
               COLOR_VERDE, multa, COLOR_RESET);

        total_vencidos++;
        total_multas += multa;

        leidos = fscanf(archivo_salida, FORMATO_VENCIDO,
                        &codigo, alumno, titulo, &dias_atraso, &multa);
    }
    fclose(archivo_salida);
    printf("=====================================================================================================\n");
    printf("  Total libros vencidos: %s%d%s | Recaudacion esperada: %s$%d%s\n",
           COLOR_ROJO, total_vencidos, COLOR_RESET, COLOR_VERDE, total_multas, COLOR_RESET);
    printf("=====================================================================================================\n\n");
}

/*
Pre: archivo_prestamos y archivo_devoluciones deben estar abiertos en modo lectura y ordenados por codigo_prestamo.
Post: Genera prestamos_vencidos.csv con los prestamos NO devueltos cuyo vencimiento es ANTERIOR a fecha_corte.
      Devuelve EXITO (0) o ERROR_ARCHIVO (-2) si hay un error al abrir el archivo de prestamos_vencidos.
*/
int procesar_archivos(FILE *archivo_prestamos, FILE *archivo_devoluciones, fecha_t fecha_corte) {
    FILE *vencidos = fopen(ARCHIVO_PRESTAMOS_VENCIDOS, "w");
    if (!vencidos) {
        printf("Error al abrir el archivo de prestamos vencidos\n");
        return ERROR_ARCHIVO;
    }

    prestamo_t prestamo;
    int codigo_devuelto;

    int leidos_prestamo = fscanf(archivo_prestamos, FORMATO_PRESTAMO,
                                 &prestamo.codigo_prestamo,
                                 prestamo.alumno,
                                 prestamo.titulo,
                                 &prestamo.vencimiento.anio,
                                 &prestamo.vencimiento.mes,
                                 &prestamo.vencimiento.dia);

    int leidos_devoluciones = fscanf(archivo_devoluciones, FORMATO_DEVOLUCION, &codigo_devuelto);

    while (leidos_prestamo != EOF && leidos_devoluciones != EOF) {
        if (prestamo.codigo_prestamo == codigo_devuelto) {
            leidos_prestamo = fscanf(archivo_prestamos, FORMATO_PRESTAMO,
                                     &prestamo.codigo_prestamo,
                                     prestamo.alumno,
                                     prestamo.titulo,
                                     &prestamo.vencimiento.anio,
                                     &prestamo.vencimiento.mes,
                                     &prestamo.vencimiento.dia);

            leidos_devoluciones = fscanf(archivo_devoluciones, FORMATO_DEVOLUCION, &codigo_devuelto);
        } else if (prestamo.codigo_prestamo > codigo_devuelto) {
            leidos_devoluciones = fscanf(archivo_devoluciones, FORMATO_DEVOLUCION, &codigo_devuelto);
        } else {
            int dias_atraso = diferencia_en_dias(prestamo.vencimiento, fecha_corte);
            if (dias_atraso > 0) {
                int multa = dias_atraso * VALOR_MULTA_DIARIA;
                fprintf(vencidos, FORMATO_ESCRITURA_VENCIDO,
                        prestamo.codigo_prestamo,
                        prestamo.alumno,
                        prestamo.titulo,
                        dias_atraso,
                        multa);
            }

            leidos_prestamo = fscanf(archivo_prestamos, FORMATO_PRESTAMO,
                                     &prestamo.codigo_prestamo,
                                     prestamo.alumno,
                                     prestamo.titulo,
                                     &prestamo.vencimiento.anio,
                                     &prestamo.vencimiento.mes,
                                     &prestamo.vencimiento.dia);
        }
    }

    while (leidos_prestamo != EOF) {
        int dias_atraso = diferencia_en_dias(prestamo.vencimiento, fecha_corte);
        if (dias_atraso > 0) {
            int multa = dias_atraso * VALOR_MULTA_DIARIA;
            fprintf(vencidos, FORMATO_ESCRITURA_VENCIDO,
                    prestamo.codigo_prestamo,
                    prestamo.alumno,
                    prestamo.titulo,
                    dias_atraso,
                    multa);
        }

        leidos_prestamo = fscanf(archivo_prestamos, FORMATO_PRESTAMO,
                                 &prestamo.codigo_prestamo,
                                 prestamo.alumno,
                                 prestamo.titulo,
                                 &prestamo.vencimiento.anio,
                                 &prestamo.vencimiento.mes,
                                 &prestamo.vencimiento.dia);
    }

    fclose(vencidos);
    return EXITO;
}

int main(int argc, char *argv[]) {
    if (argc != CANTIDAD_ARGUMENTOS) {
        printf("Uso: ./%s <archivo_prestamos> <archivo_devoluciones>\n", argv[0]);
        return ERROR_ARGUMENTOS;
    }

    mostrar_archivos_entrada(argv[ARGUMENTO_ARCHIVO_PRESTAMOS], argv[ARGUMENTO_ARCHIVO_DEVOLUCIONES]);

    FILE *archivo_prestamos = fopen(argv[ARGUMENTO_ARCHIVO_PRESTAMOS], "r");
    if (!archivo_prestamos) {
        printf("Error al abrir archivo prestamos: %s\n", argv[ARGUMENTO_ARCHIVO_PRESTAMOS]);
        return ERROR_ARCHIVO;
    }

    FILE *archivo_devoluciones = fopen(argv[ARGUMENTO_ARCHIVO_DEVOLUCIONES], "r");
    if (!archivo_devoluciones) {
        fclose(archivo_prestamos);
        printf("Error al abrir archivo de devoluciones: %s\n", argv[ARGUMENTO_ARCHIVO_DEVOLUCIONES]);
        return ERROR_ARCHIVO;
    }

    if (procesar_archivos(archivo_prestamos, archivo_devoluciones, FECHA_ACTUAL) == ERROR_ARCHIVO) {
        fclose(archivo_prestamos);
        fclose(archivo_devoluciones);
        return ERROR_ARCHIVO;
    }

    mostrar_resultados();

    fclose(archivo_prestamos);
    fclose(archivo_devoluciones);

    return EXITO;
}