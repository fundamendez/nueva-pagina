#include <stdio.h>
#include <stdbool.h>

const char HOMERO = 'H';
const char LENNY = 'L';
const char CARL = 'C';

// Pre: -
// Post: Devuelve true si el empleado es valido, false en caso contrario
bool es_empleado_valido(char empleado){
    return (empleado == HOMERO || empleado == CARL || empleado == LENNY);
}

// Pre: -
// Post: Le pide al usuario que elija un empleado y lo valida.
void elegir_empleado(char* empleado){
    printf("Que empleado vamos a echar?, Podes elegir Homero (H), Lenny(L) y Carl(C)\n");
    scanf(" %c", empleado);

    while (!es_empleado_valido(*empleado)) {
        printf("Presta atencion! Podes elegir Homero (H), Lenny(L) y Carl(C)\n");
        scanf(" %c", empleado);
    }
    
}

int main()
{
    char empleado = '-';
    elegir_empleado(&empleado);
    printf("El empleado que vas a echar %c\n", empleado);
    return 0;
}
