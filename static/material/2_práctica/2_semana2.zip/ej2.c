#include <stdio.h>
#include <stdbool.h>

#define MAX_EDADES 10
const int EDAD_MAXIMA = 8;
const int MES_MINIMO = 1;
const int MES_MAXIMO = 12;
const int ANIO_ACTUAL = 2026;
const int MES_ACTUAL = 8;
const int EDAD_MAX = 10;
const int EDAD_MIN = 7;
const int CANT_PREGUNTAS_LISA = 3;

// pre: mes debe estar entre MES_MINIMO y MES_MAXIMO y anio menor a ANIO_ACTUAL
// post: devuelve la edad 
int edad_ninio(int mes, int anio){
    int edad = -1;
    edad = ANIO_ACTUAL - anio;
    if(mes > MES_ACTUAL){
        edad--;
    }
    return edad;
}

// pre: -
// post: devuelve true si mes esta entre MES_MINIMO y MES_MAXIMO y anio menor a ANIO_ACTUAL, false en caso contrario.
bool es_fecha_valida(int mes, int anio){
    return ((mes >= MES_MINIMO && mes <= MES_MAXIMO) && anio <= ANIO_ACTUAL);
}

// pre: -
// post: almacena en las variables recibidas, el mes y el anio que ingreso el usuario
void pedir_fecha_nacimiento(int* mes, int* anio){
    printf("Por favor ingrese su fecha de nacimiento con el formato MM/AAAA \n");
    scanf("%d/%d", mes, anio);
    while(!es_fecha_valida(*mes, *anio)){
        printf("Por favor ingrese su fecha de nacimiento con el formato MM/AAAA \n");
        scanf("%d/%d", mes, anio);
    }
}

// pre: el tope debe corresponderse con la cantidad de elementos en el vector.
// post: devuelve true si hay un ninio con edad menor a EDAD_MAXIMA, false en caso contrario
bool hay_ninio_menor(int edades[MAX_EDADES], int tope_edades){
    int i = 0;
    bool encontrado = false;
    while(i < tope_edades && !encontrado){
        if(edades[i] <= EDAD_MAXIMA){
            // return o break noOOOOOOOO
            encontrado = true;
        }
        i++;
    }
    return encontrado;
}

void pedir_edad_valida(int* edad){
    int mes;
    int anio;
    pedir_fecha_nacimiento(&mes, &anio);
    (*edad) = edad_ninio(mes, anio);
    while((*edad) < EDAD_MIN || (*edad) > EDAD_MAX){
        printf("La edad no esta en rango \n");
        pedir_fecha_nacimiento(&mes, &anio);
        (*edad) = edad_ninio(mes, anio);
    }
}

// pre: el tope debe corresponderse con la cantidad de elementos en el vector.
// post: llena el vector de edades con las edades que le pregunto Lisa.
void llenar_edades(int edades[MAX_EDADES], int* tope_edades){
    int edad = -1;
    for(int i = 0; i < CANT_PREGUNTAS_LISA; i++){
        pedir_edad_valida(&edad);
        edades[*tope_edades] = edad;
        (*tope_edades)++;
    }
}

// pre: el tope debe corresponderse con la cantidad de elementos en el vector.
// post: devuelve el promedio de las edades de los ninios.
int promedio_edades(int edades[MAX_EDADES], int tope_edades){
    int suma_total = 0;
    for(int i = 0; i < tope_edades; i++){
        suma_total += edades[i];
    }

    return suma_total / tope_edades;
}

int main(){
    int edades[MAX_EDADES];
    int tope = 0;
    llenar_edades(edades, &tope);
    printf("el promedio es: %i \n", promedio_edades(edades, tope));
}