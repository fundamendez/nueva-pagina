#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>

#define MAX_OBJETOS 20
#define MAX_CUARTO 20

const int MOVIMIENTOS_INICIALES = 100;
const int FIL_INICIAL = 0;
const int COL_INICIAL = 0;
const int ROPA_INICIAL = 10;
const int JUGUETES_INICIAL = 5;

typedef struct coordenada {
 int fil;
 int col;
} coordenada_t;

typedef struct jugador {
 coordenada_t posicion;
 int movimientos_restantes;
} jugador_t;

typedef struct juego {
 jugador_t jugador;
 coordenada_t ropa[MAX_OBJETOS];
 int tope_ropa;
 coordenada_t juguetes[MAX_OBJETOS];
 int tope_jueguetes;
} juego_t;


// Pre: -
// Post: carga los atributos del jugador: sus movimientos iniciles y su posición
void inicializar_jugador(jugador_t* jugador) {
    (*jugador).movimientos_restantes = MOVIMIENTOS_INICIALES;
    (*jugador).posicion.fil = FIL_INICIAL;
    (*jugador).posicion.col = COL_INICIAL;
}

//pre: Tope tiene que corresponderse con el vector de objetos. La cantidad tiene que ser 0 o mayor a 0.
//post: carga en el vector de objetos la cantidad inicial que recibe por parámetros y actualiza el tope 
void inicializar_objetos(coordenada_t objetos[MAX_OBJETOS], int* tope_objetos, int cantidad_inicial){
    for(int i = 0;i < cantidad_inicial;i++){
        objetos[i].fil = rand() % MAX_CUARTO;
        objetos[i].col = rand() % MAX_CUARTO;
        (*tope_objetos)++;
    }
}

// pre: -
// post: inicializa todos los campos del juego.
void inicializar_juego(juego_t* juego){
    inicializar_jugador(&((*juego).jugador));

    (*juego).tope_ropa = 0;
    (*juego).tope_jueguetes = 0;

    inicializar_objetos((*juego).ropa, 
    &((*juego).tope_ropa), ROPA_INICIAL);

    inicializar_objetos(juego->juguetes, 
    &(juego->tope_jueguetes), JUGUETES_INICIAL);
    
    // (con la flechita)
    // inicializar_ropa(juego->ropa, &juego->tope_ropa);
}

int main(){
    srand ((unsigned)time(NULL));
    juego_t juego;
    inicializar_juego(&juego);
    return 0;
}
