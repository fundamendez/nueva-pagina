#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include "juego.h"

const char ARRIBA = 'W';
const char ABAJO = 'S';
const char DERECHA = 'D';
const char IZQUIERDA = 'A';

int main(){
    srand((unsigned)time(NULL));

    juego_t juego;
    inicializar_juego(&juego);

    // acá se usan las demás funciones del .h

    return 0;
}
