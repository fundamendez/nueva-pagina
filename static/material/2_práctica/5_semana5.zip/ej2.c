#include <stdio.h>

#define MAX_MAPA 20
#define MAX 50

const char NORTE = 'N';
const char SUR = 'S';
const char ESTE = 'E';

typedef struct posicion {
    int x;
    int y;
} posicion_t;

void cargar_mapa_prueba(char mapa[MAX_MAPA], int *cantidad_pasos) {
    mapa[0] = 'N';
    mapa[1] = 'N';
    mapa[2] = 'E';
    mapa[3] = 'E';
    mapa[4] = 'S';
    mapa[5] = 'O';

    (*cantidad_pasos) = 6;
}





/*
 * PRE: Vector posiciones tiene que tener N, S, E u O. La primera vez posicion_actual debe ser la posicion inicial de Tomy. El índice en la primera llamada debe ser 0. El tope tiene que ser consecuente con el contenido del vector.
 * POST: posicion_actual queda cargado con la posicion donde se encuentra Tomy.
 */
void encontrar_tomy(char posiciones[MAX], int tope_posiciones, posicion_t* posicion_actual, int indice) {
    //caso base / condicion de corte
    if (indice == tope_posiciones) {
        return;
    }
    //procesamiento
    if (posiciones[indice] == NORTE) {
        posicion_actual->y++;
    } else if (posiciones[indice] == SUR) {
        posicion_actual->y--;
    } else if (posiciones[indice] == ESTE) {
        posicion_actual->x++;
    } else {
        posicion_actual->x--;
    }
    //llamada recursiva
    encontrar_tomy(posiciones, tope_posiciones, posicion_actual, indice+1);
}







int main(){

    posicion_t inicial = {0, 0};
    printf("Posicion inicial de Tomy: (%d, %d)\n", inicial.x, inicial.y);
    char posiciones[MAX];
    int tope;
    cargar_mapa_prueba(posiciones, &tope);


    encontrar_tomy(posiciones, tope, &inicial, 0);

    printf("Posicion final de Tomy: (%d, %d)\n", inicial.x, inicial.y);
    return 0;
}