#include <stdlib.h>
#include "juego.h"

const int MOVIMIENTOS_INICIALES = 100;
const int FIL_INICIAL = 0;
const int COL_INICIAL = 0;
const int PENALIDAD_JUGUETE = 5;
const char ARRIBA = 'W';
const char ABAJO = 'S';
const char DERECHA = 'D';
const char IZQUIERDA = 'A';

// pre: -
// post: devuelve true si ambas coordenadas representan la misma posición.
bool coordenadas_iguales(coordenada_t posicion_1, coordenada_t posicion_2){
    // COMPLETAR
    return false;
}

// pre: -
// post: devuelve una coordenada con fila y columna random entre 0 y TAM_CUARTO - 1.
coordenada_t generar_posicion(){
    coordenada_t posicion = {rand() % TAM_CUARTO, rand() % TAM_CUARTO};
    return posicion;
}

void inicializar_juego(juego_t* juego){
    juego->jugador.posicion.fil = FIL_INICIAL;
    juego->jugador.posicion.col = COL_INICIAL;
    juego->jugador.movimientos_restantes = MOVIMIENTOS_INICIALES;

    juego->tope_ropa = 0;
    for(int i = 0; i < MAX_ROPA; i++){
        juego->ropa[i] = generar_posicion();
        juego->tope_ropa++;
    }

    juego->tope_jueguetes = 0;
    for(int i = 0; i < MAX_JUGUETES; i++){
        juego->juguetes[i] = generar_posicion();
        juego->tope_jueguetes++;
    }
}

void mover_jugador(jugador_t* jugador, char movimiento){
    coordenada_t nueva_posicion = jugador->posicion;

    if(movimiento == ARRIBA){
        nueva_posicion.fil--;
    }else if(movimiento == ABAJO){
        nueva_posicion.fil++;
    }else if(movimiento == DERECHA){
        nueva_posicion.col++;
    }else if(movimiento == IZQUIERDA){
        nueva_posicion.col--;
    }

    bool dentro_del_cuarto = nueva_posicion.fil >= 0 && nueva_posicion.fil < TAM_CUARTO &&
                              nueva_posicion.col >= 0 && nueva_posicion.col < TAM_CUARTO;

    if(dentro_del_cuarto){
        jugador->posicion = nueva_posicion;
        jugador->movimientos_restantes--;
    }
}

void realizar_accion(juego_t* juego){
    int i = 0;
    bool ropa_encontrada = false;
    while(i < juego->tope_ropa && !ropa_encontrada){
        if(coordenadas_iguales(juego->jugador.posicion, juego->ropa[i])){
            juego->ropa[i] = juego->ropa[juego->tope_ropa - 1];
            juego->tope_ropa--;
            ropa_encontrada = true;
        }
        i++;
    }

    for(int j = 0; j < juego->tope_jueguetes; j++){
        if(coordenadas_iguales(juego->jugador.posicion, juego->juguetes[j])){
            juego->jugador.movimientos_restantes -= PENALIDAD_JUGUETE;
        }
    }
}
