#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define MAX_TEXTO 30
#define MAX_CHISTES 30
#define PREGUNTA_FILTRAR "Quién es?"
#define MAX_PALABRAS_FILTRAR 3
const char PALABRAS_FILTRAR[MAX_TEXTO][MAX_PALABRAS_FILTRAR] = {"paz", "hambre", "dinero"};

typedef struct chiste {
   char inicio[MAX_TEXTO];
   char pregunta[MAX_TEXTO];
   char remate[MAX_TEXTO];
} chiste_t;


// pre: remate debe ser un string (terminar en \0)
// post: devuelve true si el remate contiene alguna de las 3 palabras a filtrar, false en caso contrario
bool contiene_palabras_filtrar(char remate[MAX_TEXTO]){
    bool contiene = false;
    int i = 0;
    while(i < MAX_PALABRAS_FILTRAR && !contiene){
        if(strstr(remate, PALABRAS_FILTRAR[i]) != NULL){
            contiene = true;
        }
        i++;
    }

    return contiene;
}

// pre: los campos del todos los elementos del repertorio deben ser strings (terminar en \0).
// post: saca del vector repertorio los chistes cuya pregunta contenga PREGUNTA_FILTRAR o su remate contenga alguna de las PALABRAS_FILTRAR.
void filtrar_chistes(chiste_t repertorio[MAX_CHISTES], int* tope_repertorio){
    int tope_aux = 0;
    for (int i=0; i< *tope_repertorio; i++) {
        if (strcmp(repertorio[i].pregunta, PREGUNTA_FILTRAR) != 0 || !contiene_palabras_filtrar(repertorio[i].remate)) {
            repertorio[tope_aux] = repertorio[i];
            tope_aux++;
        } 
    }
    *tope_repertorio = tope_aux;
}
