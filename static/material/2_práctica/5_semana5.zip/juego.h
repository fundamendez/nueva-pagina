#ifndef JUEGO_H
#define JUEGO_H

#include <stdbool.h>

#define MAX_ROPA 10
#define MAX_JUGUETES 5
#define TAM_CUARTO 20

typedef struct coordenada {
    int fil;
    int col;
} coordenada_t;

typedef struct jugador {
    coordenada_t posicion;
    int movimientos_restantes;
} jugador_t;

typedef struct juego {
    jugador_t jugador;
    coordenada_t ropa[MAX_ROPA];
    int tope_ropa;
    coordenada_t juguetes[MAX_JUGUETES];
    int tope_jueguetes;
} juego_t;

// pre: -
// post: inicializa el juego ubicando al jugador en la posición inicial con los
// movimientos iniciales, y coloca 10 prendas de ropa y 5 juguetes en posiciones
// aleatorias del cuarto que no se pisan entre sí ni con el jugador.
void inicializar_juego(juego_t* juego);

// pre: el jugador debe estar en una posición válida del cuarto. El movimiento
// debe ser uno de los válidos ('W', 'A', 'S', 'D').
// post: actualiza la posición del jugador según el movimiento recibido, siempre
// que no lo saque de los límites del cuarto (20x20); si el movimiento lo sacaría
// del cuarto, la posición queda sin cambios. Todo movimiento válido descuenta un
// movimiento disponible.
void mover_jugador(jugador_t* jugador, char movimiento);

// pre: el juego debe estar inicializado.
// post: si el jugador está parado sobre una prenda de ropa, la recoge (deja de
// estar disponible en el terreno, por lo que no vuelve a considerarse en
// movimientos posteriores). Si está parado sobre un juguete, se distrae jugando
// y pierde movimientos adicionales.
void realizar_accion(juego_t* juego);

#endif
