#include <stdio.h>

const char BIG_KRUSTY = 'B';
const char KRUSTYLICIOSA = 'K';
const char KRUNCHY_BURGER = 'U';
const int BIG_KRUSTY_COMBO = 1;
const int KRUSTYLICIOSA_COMBO = 2; 
const int KRUNCHY_BURGER_COMBO = 3;
const int COMBO_INVALIDO = 0;

//Pre: -
//Post: 
// -Devuelve BIG_KRUSTY_COMBO si combo es BIG_KRUSTY.
// -Devuelve KRUSTYLICIOSA_COMBO si combo es KRUSTYLICIOSA.
// -Devuelve KRUNCHY_BURGER_COMBO si combo es KRUNCHY_BURGER.
// -COMBO_INVALIDO en cualquier otro caso.
int combo_elegido(char combo){
    int combo_elegido = COMBO_INVALIDO;
    if(combo == BIG_KRUSTY){
        combo_elegido = BIG_KRUSTY_COMBO;
    }
    else if(combo == KRUSTYLICIOSA){
        combo_elegido = KRUSTYLICIOSA_COMBO;
    }
    else if(combo == KRUNCHY_BURGER){
        combo_elegido = KRUNCHY_BURGER_COMBO;
    }
    return combo_elegido;
}

int main(){
    char combo = ' ';
    printf("Que combo querés comer hoy?\n");
    printf("%c para Big Krusty.\n", BIG_KRUSTY);
    printf("%c para Krustyliciosa.\n", KRUSTYLICIOSA);
    printf("%c para Krunchy Burger.\n", KRUNCHY_BURGER);
    scanf(" %c", &combo);
    int combo_bart = combo_elegido(combo);
    if(combo_bart == COMBO_INVALIDO){
        printf("El combo elegido no existe.\n");
    }
    else{
        printf("El combo elegido es %i\n", combo_bart);
    }
    return 0;
}