#include <stdio.h>

const char RESPUESTA_CORRECTA = 'H';

//Pre: -
//Post: Saluda hasta que la respuesta sea RESPUESTA_CORRECTA.
void saludar_thompson(){
    char respuesta_homero = ' ';
    printf("Hola Sr Thompson\n");
    scanf(" %c", &respuesta_homero);
    while(respuesta_homero != RESPUESTA_CORRECTA){
        printf("Hola Sr THOMPSON!!!!!!!!\n");
        scanf(" %c", &respuesta_homero);
    }
}

int main(){
    saludar_thompson();
    return 0;
}