#include <stdio.h> // incluyo la biblioteca stdio.h

// CONSTANTES (variables con valores fijos durante todo el programa)
const int ANIO_ACTUAL = 2026;
const int MAYORIA_EDAD = 18;
const int ANIO_MINIMO = 2008;
const int MES_ACTUAL = 8;

int pedir_entero(char tipo_de_valor, int valor_minimo, int valor_maximo){
    int ingresado = 0;
    
    printf("Ingrese %c (a = anio y m = mes)", tipo_de_valor);
    scanf("%i", &ingresado);

    while(ingresado > valor_maximo || ingresado < valor_minimo){
        printf("Ingrese un numero mayor a 0 y menor a %i", valor_maximo);
        scanf("%i", &ingresado);
    }
    return ingresado;
}

int calcular_edad(int anio, int mes){
    int edad = ANIO_ACTUAL - anio;
    if(mes != -1 && MES_ACTUAL < mes){
        edad--;
    }
    return edad;
}

int main () { // programa principal
    // declaración de variables
    int edad = 0; // variable que se llama edad y es de tipo entero. Le pongo el valor 0
    int anio = 0;

    int mes = -1;

    // en python era
    // edad = input(¨ingrese su edad¨)
    
    anio = pedir_entero('a', 1950, ANIO_ACTUAL);
    
    if (anio == ANIO_MINIMO){
        mes = pedir_entero('m', 1, 12);
    }

    edad = calcular_edad(anio, mes);

    if (edad >= MAYORIA_EDAD) {
        printf("Podés pasar wachine\n");
    } else {
        printf("Ah no, no no no\n");
    }
}   

/*
int funcion(char parametro) {
    return 3;
}

funcion('e');
*/