#include <stdio.h>

const int ERROR = -1;

#define MAX_LINEA 100

const char* RUTA_ARCHIVO_FRASES = "frases_simpsons.txt";
const char* MODO_APPEND = "a";

int main () {

    FILE* frases_simpsons = fopen(RUTA_ARCHIVO_FRASES, MODO_APPEND);

    if (!frases_simpsons) {
        printf("Error al intentar abrir el archivo '%s'\n", RUTA_ARCHIVO_FRASES);
        return ERROR;
    }

    char linea[MAX_LINEA] = "\nEsta es una línea agregada por nosotros los alumnos el martes 19 de mayo de 2026.\0";

    int escritos = fprintf(frases_simpsons, "%s\n", linea);

    printf("Se escribieron %i elementos\n", escritos);

    fclose(frases_simpsons);

    return 0;
}