#include <stdio.h>

const int ERROR = -1;

#define MAX_LINEA 100

const char* RUTA_ARCHIVO_FRASES = "frases_simpsons.txt";
const char* MODO_LECTURA = "r";

int main () {

    FILE* frases_simpsons = fopen(RUTA_ARCHIVO_FRASES, MODO_LECTURA);

    if (!frases_simpsons) {
        printf("Error al intentar abrir el archivo '%s'\n", RUTA_ARCHIVO_FRASES);
        return ERROR;
    }

    char linea[MAX_LINEA];

    int i = 1;
    int leido = fscanf(frases_simpsons, "%[^\n]\n", linea);
    while(leido != EOF) {
        printf("Línea nro %i:\n%s\n\n", i, linea);
        i++;
        leido = fscanf(frases_simpsons, "%[^\n]\n", linea);
    }

    fclose(frases_simpsons);

    return 0;
}