#include <stdio.h>

const int ERROR = -1;

#define MAX_PALABRA 30

int main () {

    FILE* frases_simpsons = fopen("frases_simpsons.txt", "r");

    if (!frases_simpsons) {
        printf("Error al intentar abrir el archivo 'frases_simpsons.txt'\n");
        return ERROR;
    }

    char palabra[MAX_PALABRA];

    int i = 1;
    int leido = fscanf(frases_simpsons, "%s", palabra);
    while(leido != EOF) {
        
        printf("Palabra nro %i: %s\n", i, palabra);
        i++;
        leido = fscanf(frases_simpsons, "%s", palabra);
    }

    fclose(frases_simpsons);
    
    return 0;
}