#include <stdio.h>

const int ERROR = -1;

#define MAX_NOMBRE_ALUMNO 100
#define MAX_CORRECTOR 50

int main () {

    FILE* alumnos = fopen("alumnos.csv", "r");

    if (!alumnos) {
        printf("Error al intentar abrir el archivo 'alumnos.csv'\n");
        return ERROR;
    }

    int id_alumno;
    char nombre_alumno[MAX_NOMBRE_ALUMNO];
    char corrector[MAX_CORRECTOR];
    int padron;
    int nro_alumno = 0;

    int leido = fscanf(alumnos, "%i;%[^;];%i;%[^\n]\n", &id_alumno, nombre_alumno, &padron, corrector);

    while(leido != EOF) {
        nro_alumno++;
        printf("Alumno %i:\nid:%i\nnombre: %s\npadron: %i\ncorrector: %s\n\n", nro_alumno, id_alumno, nombre_alumno, padron, corrector);
        leido = fscanf(alumnos, "%i;%[^;];%i;%[^\n]\n", &id_alumno, nombre_alumno, &padron, corrector);
    }

    fclose(alumnos);

    return 0;
}