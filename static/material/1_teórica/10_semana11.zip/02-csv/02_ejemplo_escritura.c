#include <stdio.h>
#include <string.h>

#define MAX_NOMBRE_ALUMNO 100
#define MAX_CORRECTOR 50

const int ERROR = -1;

const char* RUTA_ARCHIVO_ALUMNOS = "alumnos.csv";
const char* RUTA_ARCHIVO_AUXILIAR = "temporal.csv";
const char* MODO_LECTURA = "r";
const char* MODO_ESCRITURA = "w";

const char* FORMATO_LECTURA = "%i;%[^;];%i;%[^\n]\n";
const char* FORMATO_ESCRITURA = "%i;%s;%i;%s\n";

const char* CORRECTOR_RENUNCIO = "Berni";

int main () {
    char nuevo_corrector[MAX_CORRECTOR];
    printf("Ingrese el nombre del corrector que reemplazará a '%s': ", CORRECTOR_RENUNCIO);
    scanf("%s", nuevo_corrector);

    FILE* alumnos = fopen(RUTA_ARCHIVO_ALUMNOS, MODO_LECTURA);
    if (!alumnos) {
        printf("Error al intentar abrir el archivo '%s'\n", RUTA_ARCHIVO_ALUMNOS);
        return ERROR;
    }

    FILE* auxiliar = fopen(RUTA_ARCHIVO_AUXILIAR, MODO_ESCRITURA);
    if (!auxiliar) {
        printf("Error al intentar abrir el archivo '%s'\n", RUTA_ARCHIVO_AUXILIAR);
        fclose(alumnos);
        return ERROR;
    }

    int id_alumno;
    char nombre_alumno[MAX_NOMBRE_ALUMNO];
    char corrector[MAX_CORRECTOR];
    int padron;
    int nro_alumno = 0;

    int leido = fscanf(alumnos, FORMATO_LECTURA, &id_alumno, nombre_alumno, &padron, corrector);

    while(leido != EOF) {
        nro_alumno++;

        if (strcmp(corrector, CORRECTOR_RENUNCIO) == 0) {
            strcpy(corrector, nuevo_corrector);
        }

        fprintf(auxiliar, FORMATO_ESCRITURA, id_alumno, nombre_alumno, padron, corrector);

        leido = fscanf(alumnos, FORMATO_LECTURA, &id_alumno, nombre_alumno, &padron, corrector);
    }

    fclose(alumnos);
    fclose(auxiliar);

    remove(RUTA_ARCHIVO_ALUMNOS);
    rename(RUTA_ARCHIVO_AUXILIAR, RUTA_ARCHIVO_ALUMNOS);

    return 0;
}