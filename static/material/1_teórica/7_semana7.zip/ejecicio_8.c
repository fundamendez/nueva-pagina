#include <string.h>

typedef struct trofeo {
    char nombre_competencia[MAX_NOMBRE];
    int fecha; // formato aaaammdd
    int puesto;
} trofeo_t;

/* Pre condiciones: 
        - 'tope_trofeos' debe ser mayor o igual a cero y menor o igual a 'MAX_TROFEOS'.
        - Los campos 'nombre_competencia' de todos los trofeo_t de 'trofeos' deben ser un string (terminar en '\0').
 * Post condiciones: Ordena 'trofeos' por 'nombre_competencia' y subordena por 'fecha'.
 */
void ordenar_trofeos(trofeo_t trofeos[MAX_TROFEOS], int tope_trofeos) {
    trofeo_t auxiliar;

    for(int i = 0; i < (tope_trofeos - 1); i++) {
        for(int j = 0; j < (tope_trofeos - i - 1); j++) {
            if(strcmp(trofeos[j].nombre_competencia, trofeos[j + 1].nombre_competencia) > 0) {
                auxiliar = trofeos[j];
                trofeos[j] = trofeos[j + 1];
                trofeos[j + 1] = auxiliar;
            } else if(strcmp(trofeos[j].nombre_competencia, trofeos[j + 1].nombre_competencia) == 0) {
                if(trofeos[j].fecha < trofeos[j + 1].fecha) {
                    auxiliar = trofeos[j];
                    trofeos[j] = trofeos[j + 1];
                    trofeos[j + 1] = auxiliar;
                }
            }
        }
    }
}
