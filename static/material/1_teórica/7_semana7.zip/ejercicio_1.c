/*Un autógrafo puede ser recolectado si:

En el stand están firmando
y
La suma de las coordenadas del stand es par.

El valor de una firma se calcula como la rareza multiplicado por la popularidad dividido 10.

Se pide
Implementar una función recursiva que reciba la matriz y devuelva el nombre del personaje
con firma de mayor valor que se pueda recolectar.*/

#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX_NOMBRE 50
#define MAX_FILAS 30
#define MAX_COL 30
const int DIVISOR_FIRMA = 10;

typedef struct stand {
    bool estan_firmando;
    char personaje[MAX_NOMBRE];
    int rareza;
    int popularidad;
} stand_t;

//pre: -
//post: devuelve true si en el stand están firmando y la suma de sus coordenadas es par, devuelve false.
bool es_firmada_valida(stand_t stand_actual, int fila_actual, int col_actual){
    return stand_actual.estan_firmando && ((fila_actual + col_actual) % 2 == 0);
}

//pre:  -
//post: devuelve el valor de la firma del stand
int calculo_valor_firma(stand_t stand_actual){
    return (stand_actual.popularidad * stand_actual.rareza) / DIVISOR_FIRMA;
}

//pre: 
//      - todos los campos 'personaje' de los stand_t deben ser un string (terminar en '\0').
//      - 0 <= 'fila_actual' <= 'tope_fil'. 
//      - 0 <= 'col_actual' < 'tope_col' 
//      - 'fila_actual' < 'tope_fil'.
//      - 'tope_fil' <= MAX_FILAS. 
//      - 'tope_col' <= MAX_COL. 
//      - 'nombre_famoso' apunta a un arreglo con espacio suficiente para almacenar un nombre de hasta MAX_NOMBRE caracteres.
//post: Devuelve en 'nombre_famoso' el nombre del personaje cuya firma recolectable tiene el mayor valor encontrado
char* nombre_mejor_firma(stand_t personajes[MAX_FILAS][MAX_COL], int tope_fil, int tope_col, int fila_actual, int col_actual, int valor_firma, char* nombre_famoso){
    //caso base
    if(fila_actual == tope_fil){
        return nombre_famoso;
    }

    //procesamiento
    if(es_firmada_valida(personajes[fila_actual][col_actual], fila_actual, col_actual)){
        int valor_firma_actual = calculo_valor_firma(personajes[fila_actual][col_actual]);

        if(valor_firma_actual > valor_firma){
            valor_firma = valor_firma_actual;
            strcpy(nombre_famoso, personajes[fila_actual][col_actual].personaje);
        }
    }

    //llamado recursivo
    if(col_actual == tope_col - 1){
        return nombre_mejor_firma(personajes, tope_fil, tope_col, fila_actual + 1, 0, valor_firma, nombre_famoso);
    } else {
        return nombre_mejor_firma(personajes, tope_fil, tope_col, fila_actual, col_actual +1, valor_firma, nombre_famoso);
    }
}
