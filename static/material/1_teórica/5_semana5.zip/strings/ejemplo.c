#include <stdio.h>
#include <string.h>

#define MAX_CARACTERES 50

const char* SALUDO_INICIAL = "Hola ";

int main() {
    char saludo[MAX_CARACTERES];
    char nombre[MAX_CARACTERES] = "Homero";
    
    // 1. Función 'strcpy'.
    printf("Copiando '%s' a 'saludo'...\n", SALUDO_INICIAL);
    strcpy(saludo, SALUDO_INICIAL);
    printf("Saludo después de copiar: %s\n", saludo);
    
    // // 2. Función 'strcat'.
    // printf("Concatenando '%s' a 'saludo'...\n", nombre);
    // strcat(saludo, nombre);
    // printf("Saludo después de concatenar: %s\n", saludo);
    
    // // 3. Función 'strlen'.
    // int longitud = strlen(saludo);
    // printf("La longitud del saludo es: %d\n", longitud);
    
    // // 4. Función 'strcmp'.
    // int resultado_comparacion = strcmp(nombre, "Homero");
    // if (resultado_comparacion == 0) {
    //     printf("El nombre coincide.\n");
    // } else {
    //     printf("El nombre no coincide.\n");
    // }

    // printf("Resultado de strcmp: %i\n", resultado_comparacion);
    
    return 0;
}
