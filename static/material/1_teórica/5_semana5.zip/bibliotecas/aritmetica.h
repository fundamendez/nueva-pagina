#ifndef __ARITMETICA_H__
#define __ARITMETICA_H__


// Pre:
// Post: devuelve la suma de a y b
int suma(int a, int b);

// Pre:
// Post: devuelve la resta entre a y b
int resta(int a, int b);

// Pre:
// Post: devuelve la division ENTERA de los dos numeros y si el denominador es 0, devuelve 0.
int division_entera_mejorada(int numerador, int denominador);

#endif
