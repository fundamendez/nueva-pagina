#include<stdio.h>
#include "aritmetica.h"

int main(){
    int n = division_entera_mejorada(10, 0);

    printf("La division mejorada de 10 dividido 0 es %i", n);

    return 0;
}
