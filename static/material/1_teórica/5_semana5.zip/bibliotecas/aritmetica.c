#include"aritmetica.h"
#include<stdbool.h>

int suma(int a, int b){
    return a + b;
}

int resta(int a, int b){
    return a - b;
}

bool es_denominador_valido(int denominador){
    return denominador != 0;
}

int division_entera_mejorada(int numerador, int denominador){
    if(!es_denominador_valido(denominador)){
        return 0;
    }
    return numerador/denominador;
}
