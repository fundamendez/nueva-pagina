
#include <stdio.h>
#include <string.h>
#include "vector_din.h"

#define ERROR 1

#define ACTIVIDAD_BUSCADA "Exámen sorpresa"
const int FECHA_ACTIVIDAD_BUSCADA = 20261020;
#define ALUMNO_MALA_NOTA "Jimbo"
const int MIN_NOTA_PROMEDIO = 6;
const int MAX_NOTA_PROMEDIO = 8;
const int MIN_NOTA_APROBADO = 4;


/* Pre condiciones: el campo 'nombre' de la calificacion_t debe ser un string
 * Post condiciones: devuelve true si es una calificacion de alguien presente en la actividad y fecha buscadas
 */
bool es_calificacion_buscada(calificacion_t calificacion);


/* Pre condiciones: el campo 'nombre' de la calificacion_t debe ser un string
 * Post condiciones: devuelve por retorno de la función la copia de la calificación
 */
calificacion_t copiar_calificacion(calificacion_t calificacion);


/* Pre condiciones: el campo 'nombre' de la calificacion_t debe ser un string
 * Post condiciones: devuelve por retorno de la función la copia de la calificación con sus campos "dibujados" según corresponda
 */
calificacion_t obtener_calificacion_dibujada(calificacion_t calificacion);


/* Pre condiciones: 'calificaciones' debe ser previamente creado con 'vec_crear'.
 * Post condiciones: Llena 'calificaciones_dibujadas' con las calificaciones de 'calificaciones_originales' alterando su '.nota' según su caso.
 */
void dibujar_calificaciones(vector_din_t* *calificaciones) {
    vector_din_t* calificaciones_dibujadas = vec_crear();
    if(calificaciones_dibujadas == NULL) {
        printf("Error al intentar crear una instacia del tda vector dinamico");
        return;
    }

    int tope_originales = vec_largo(*calificaciones);
    for(int i = 0; i < tope_originales; i++) {
        calificacion_t* original_actual = vec_obtener(*calificaciones, i);
        calificacion_t copia = copiar_calificacion(*original_actual);

        if(es_calificacion_buscada(copia)) {
            copia = obtener_calificacion_dibujada(copia);
        }

        vec_guardar(calificaciones_dibujadas, copia);
    }

    vec_destruir(*calificaciones);

    *calificaciones = calificaciones_dibujadas;
}


bool es_calificacion_buscada(calificacion_t calificacion) {
    return calificacion.presente && strcmp(calificacion.actividad, ACTIVIDAD_BUSCADA) == 0 && calificacion.fecha == FECHA_ACTIVIDAD_BUSCADA;
}


calificacion_t copiar_calificacion(calificacion_t calificacion) {
    calificacion_t copia = calificacion;

    strcpy(copia.alumno_nombre, calificacion.alumno_nombre);
    strcpy(copia.actividad, calificacion.actividad);

    return copia;
}


calificacion_t obtener_calificacion_dibujada(calificacion_t calificacion) {
    calificacion_t dibujada = copiar_calificacion(calificacion);

    if(dibujada.nota >= MIN_NOTA_PROMEDIO && dibujada.nota <= MAX_NOTA_PROMEDIO) {
        dibujada.nota++;
    } else if(dibujada.nota >= MIN_NOTA_APROBADO && dibujada.nota < MIN_NOTA_PROMEDIO) {
        dibujada.nota = MIN_NOTA_PROMEDIO;
    } else if(strcmp(dibujada.alumno_nombre, ALUMNO_MALA_NOTA) != 0) {
        dibujada.presente = false;
    }

    return dibujada;
}


int main() {
    vector_din_t* calificaciones = vec_crear();

    if (calificaciones == NULL) {
        printf("Ocurrió un error al intentar crear una instancia del TDA vector dinámico\n");
        return ERROR;
    }

    calificacion_t reales[] = {
        {"Bart", "Exámen sorpresa", 20261020, true, 6},
        {"Lisa", "Otra actividad", 20261020, false, 6},
        {"Milhouse", "Exámen sorpresa", 20261019, true, 6},
        {"Nelson", "Exámen sorpresa", 20261020, true, 7},
        {"Ralph", "Exámen sorpresa", 20261020, false, 7},
        {"Martin", "Exámen sorpresa", 20261019, true, 7},
        {"Sherri", "Otra actividad", 20261020, true, 8},
        {"Terri", "Exámen sorpresa", 20261020, false, 8},
        {"Janey", "Exámen sorpresa", 20261019, true, 8},
        {"Wendell", "Otra actividad", 20261020, true, 4},
        {"Dolph", "Exámen sorpresa", 20261020, true, 5},
        {"Kearney", "Exámen sorpresa", 20261020, false, 4},
        {"Database", "Otra actividad", 20261020, false, 5},
        {"Üter", "Exámen sorpresa", 20261019, true, 4},
        {"Allison", "Otra actividad", 20261019, true, 5},
        {"Todd", "Exámen sorpresa", 20261020, true, 3},
        {"Jimbo", "Exámen sorpresa", 20261020, true, 3}
    };

    for (int i = 0; i < 17; i++) {
        if (!vec_guardar(calificaciones, reales[i])) {
            printf("Ocurrió un error al guardar una calificación\n");
            return ERROR;
        }
    }

    printf("\n\nCalificaciones originales:\n\n");
    vec_mostrar(calificaciones);

    dibujar_calificaciones(&calificaciones);

    printf("\n\nCalificaciones dibujadas:\n\n");
    vec_mostrar(calificaciones);

    vec_destruir(calificaciones);

    return 0;
}