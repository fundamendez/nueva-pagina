#include <stdlib.h>

#define MAX_NOMBRE 100
#define MAX_ACTIVIDAD 100

typedef struct calificacion {
    char alumno_nombre[MAX_NOMBRE];
    char actividad[MAX_ACTIVIDAD];
    int fecha; // aaaammdd
    bool presente;
    int nota;
} calificacion_t;

//	Interfaz de un vector dinámico de calificaciones.
//	Las posiciones del vector se numeran desde 0.

typedef struct vector_din vector_din_t;

// Post: Crea un vector dinámico de calificaciones. Devuelve un puntero a un vector vacío.
//   	Al terminar de usarlo este vector debe ser destruido con vec_destruir().
//   	Devuelve NULL si no se pudo crear el vector.
vector_din_t* vec_crear();


// Pre: `vec` fue creado usando vec_crear().
// Post: Libera los recursos del vector dinámico.
void vec_destruir(vector_din_t* vec);

// Pre: `vec` fue creado usando vec_crear().
// Post: Agrega una calificación al final del vector.
//   	Devuelve true si se pudo agregar, false en caso contrario.
bool vec_guardar(vector_din_t* vec, calificacion_t calificacion);

// Pre: `vec` fue creado usando vec_crear().
// Post: Devuelve un puntero elemento en la posición `pos` del vector.
//   	Si `pos` es inválida, devuelve NULL.
//   	Una posición es inválida si es mayor o igual al largo del vector.
calificacion_t* vec_obtener(vector_din_t* vec, size_t pos);

// Pre: `vec` fue creado usando vec_crear().
// Post: Elimina el elemento en la posición `pos` del vector.
//   	Devuelve true si se pudo eliminar, false en caso contrario.
bool vec_eliminar(vector_din_t* vec, size_t pos);

// Pre: `vec` fue creado usando vec_crear().
// Post: Devuelve la cantidad de elementos en el vector.
size_t vec_largo(vector_din_t* vec);

// Pre: `vec` fue creado usando vec_crear().
// Post: Muestra por pantalla la información de los elementos del vector.
void vec_mostrar(vector_din_t* vec);