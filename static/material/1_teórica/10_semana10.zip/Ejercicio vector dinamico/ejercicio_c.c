
#include <stdio.h>
#include <string.h>
#include "vector_din.h"

#define ERROR 1
#define ALUMNO_ELIMINADO "Üter"


/* Pre condiciones: el campo 'nombre' de la calificacion_t debe ser un string
 * Post condiciones: devuelve por retorno de la función la copia de la calificación
 */
calificacion_t copiar_calificacion(calificacion_t calificacion);


/* Pre condiciones: 'calificaciones' debe ser previamente creada con 'vec_crear'.
 * Post condiciones: Actualiza 'calificaciones' con las calificaciones alterando su '.nota' según su caso.
 */
void dibujar_calificaciones(vector_din_t* *calificaciones) {
    vector_din_t* calificaciones_dibujadas = vec_crear();
    if(calificaciones_dibujadas == NULL) {
        printf("Ocurrió un error al intentar crear una instancia del TDA vector dinámico\n");
        return;
    }
    
    int tope_originales = vec_largo(*calificaciones);

    for(int i = 0; i < tope_originales; i++) {
        calificacion_t* original_actual = vec_obtener(*calificaciones, i);
        
        if(strcmp(original_actual->alumno_nombre, ALUMNO_ELIMINADO) != 0) {
            calificacion_t copia = copiar_calificacion(*original_actual);
            vec_guardar(calificaciones_dibujadas, copia);
        }
    }

    vec_destruir(*calificaciones);
    *calificaciones = calificaciones_dibujadas;
}


calificacion_t copiar_calificacion(calificacion_t calificacion) {
    calificacion_t copia = calificacion;

    strcpy(copia.alumno_nombre, calificacion.alumno_nombre);
    strcpy(copia.actividad, calificacion.actividad);

    return copia;
}


int main() {
    vector_din_t* calificaciones = vec_crear();

    if (calificaciones == NULL) {
        printf("Ocurrió un error al intentar crear una instancia del TDA vector dinámico\n");
        return ERROR;
    }

    calificacion_t reales[] = {
        {"Bart", "Exámen sorpresa", 20261020, true, 6},
        {"Lisa", "Otra actividad", 20261020, false, 6},
        {"Milhouse", "Exámen sorpresa", 20261019, true, 6},
        {"Nelson", "Exámen sorpresa", 20261020, true, 7},
        {"Üter", "Exámen sorpresa", 20261020, false, 7},
        {"Martin", "Exámen sorpresa", 20261019, true, 7},
        {"Sherri", "Otra actividad", 20261020, true, 8},
        {"Üter", "Exámen sorpresa", 20261020, false, 8},
        {"Janey", "Exámen sorpresa", 20261019, true, 8},
        {"Wendell", "Otra actividad", 20261020, true, 4},
        {"Üter", "Exámen sorpresa", 20261020, true, 5},
        {"Üter", "Exámen sorpresa", 20261020, false, 4},
        {"Database", "Otra actividad", 20261020, false, 5},
        {"Üter", "Exámen sorpresa", 20261019, true, 4},
        {"Allison", "Otra actividad", 20261019, true, 5},
        {"Todd", "Exámen sorpresa", 20261020, true, 3},
        {"Üter", "Exámen sorpresa", 20261020, true, 3}
    };

    for (int i = 0; i < 17; i++) {
        if (!vec_guardar(calificaciones, reales[i])) {
            printf("Ocurrió un error al guardar una calificación\n");
            return ERROR;
        }
    }

    printf("\n\nCalificaciones originales:\n\n");
    vec_mostrar(calificaciones);

    dibujar_calificaciones(&calificaciones);

    printf("\n\nCalificaciones dibujadas:\n\n");
    vec_mostrar(calificaciones);

    vec_destruir(calificaciones);

    return 0;
}