
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

const int EXITO = 0;
const int ERROR = 1;

const int CANTIDAD_MINIMA_ARGS_COMANDOS = 2;

#define MAX_COMANDOS 5
const char COMANDOS[MAX_COMANDOS][10] = {"ayuda", "saludar", "despedir", "sumar", "contar"};
const int IDX_CMD_AYUDA = 0;
const int IDX_CMD_SALUDAR = 1;
const int IDX_CMD_DESPEDIR = 2;
const int IDX_CMD_SUMAR = 3;
const int IDX_CMD_CONTAR = 4;

const int IDX_COMANDO = 1;

const int CANT_ARGS_CMD_SALUDAR = 3;
const int CANT_ARGS_CMD_DESPEDIR = 3;
const int CANT_ARGS_CMD_SUMAR = 4;
const int CANT_ARGS_CMD_CONTAR = 3;

const int IDX_ARG_NOMBRE = 2;
const int IDX_PRIMER_SUMANDO = 2;
const int IDX_SEGUNDO_SUMANDO = 3;
const int IDX_ARG_CONTAR = 2;


/* Pre condiciones: -
 * Post condiciones: muestra por pantalla ejemplos de comandos, y devuelve EXITO.
 */
int mostrar_ayuda();

/* Pre condiciones: -
 * Post condiciones: muestra por pantalla un saludo de bienvenida para argv[IDX_ARG_NOMBRE]
 *                      devuelve ERROR en caso de argc no válido para el comando
 */
int saludar(int argc, char* argv[]);

/* Pre condiciones: -
 * Post condiciones: muestra por pantalla un saludo de despedida para argv[IDX_ARG_NOMBRE]
 *                      devuelve ERROR en caso de argc no válido para el comando
 */
int despedir(int argc, char* argv[]);

/* Pre condiciones: argv[IDX_PRIMER_SUMANDO] y argv[IDX_SEGUNDO_SUMANDO] deben ser strings con valores numéricos
 * Post condiciones: devuelve por pantalla la suma entre argv[IDX_PRIMER_SUMANDO] y argv[IDX_SEGUNDO_SUMANDO]
 *                      devuelve ERROR en caso de argc no válido para el comando
 */
int sumar(int argc, char* argv[]);

/* Pre condiciones: -
 * Post condiciones: devuelve por pantalla la sucesión de números desde 1 a argv[IDX_ARG_CONTAR]
 *                      devuelve ERROR en caso de argc no válido para el comando
 */
int contar(int argc, char* argv[]);

/* Pre condiciones: 'comando' debe apuntar a un string (cadena de caracteres que termina en \0).
 * Post condiciones: devuelve true si corresponde a un COMANDO o false en caso contrario.
 */
bool comando_valido(char* comando);


int main(int argc, char* argv[]) {

    if (argc < CANTIDAD_MINIMA_ARGS_COMANDOS) {
        printf("Debes indicar un comando.\n");
        printf("Usa 'ayuda' para ver las opciones.\n");
        return ERROR;
    }

    if (!comando_valido(argv[IDX_COMANDO])) {
        printf("Comando desconocido: %s\n", argv[IDX_COMANDO]);
        printf("Usa 'ayuda' para ver las opciones.\n");
        return ERROR;
    }

    if (strcmp(argv[IDX_COMANDO], COMANDOS[IDX_CMD_AYUDA]) == 0) {
        return mostrar_ayuda();

    } else if (strcmp(argv[IDX_COMANDO], COMANDOS[IDX_CMD_SALUDAR]) == 0) {
        return saludar(argc, argv);

    } else if (strcmp(argv[IDX_COMANDO], COMANDOS[IDX_CMD_DESPEDIR]) == 0) {
        return despedir(argc, argv);

    } else if (strcmp(argv[IDX_COMANDO], COMANDOS[IDX_CMD_SUMAR]) == 0) {
        return sumar(argc, argv);

    } else if (strcmp(argv[IDX_COMANDO], COMANDOS[IDX_CMD_CONTAR]) == 0) {
        return contar(argc, argv);
    } else {
        printf("Error inesperado. Intente de nuevo\n");
        return ERROR;
    }
}


int mostrar_ayuda(void) {
    printf("=== ASISTENTE POR LINEA DE COMANDOS ===\n\n");
    printf("Comandos disponibles:\n");
    printf("  saludar NOMBRE       Saluda a una persona\n");
    printf("  despedir NOMBRE      Despide a una persona\n");
    printf("  sumar NUM1 NUM2      Suma dos numeros enteros\n");
    printf("  contar N             Cuenta desde 1 hasta N\n");
    printf("  ayuda                Muestra esta ayuda\n");

    return EXITO;
}


int saludar(int argc, char* argv[]) {
    if (argc < CANT_ARGS_CMD_SALUDAR) {
        printf("Error: debes indicar un nombre.\n");
        printf("Ejemplo: saludar Ana\n");
        return ERROR;
    }

    if (argc != CANT_ARGS_CMD_SALUDAR) {
        printf("Error: Exceso en cantidad de argumentos para el comando %s.\n", argv[IDX_COMANDO]);
        printf("Ejemplo: saludar Ana\n");
        return ERROR;
    }

    printf("Hola, %s! Bienvenido/a!\n", argv[IDX_ARG_NOMBRE]);

    return EXITO;
}


int despedir(int argc, char* argv[]) {
    if (argc < CANT_ARGS_CMD_DESPEDIR) {
        printf("Error: debes indicar un nombre.\n");
        printf("Ejemplo: despedir Juan\n");
        return ERROR;
    }

    if (argc != CANT_ARGS_CMD_DESPEDIR) {
        printf("Error: Exceso en cantidad de argumentos para el comando %s.\n", argv[IDX_COMANDO]);
        printf("Ejemplo: despedir Juan\n");
        return ERROR;
    }

    printf("Hasta luego, %s! Que tengas un buen dia.\n", argv[IDX_ARG_NOMBRE]);

    return EXITO;
}


int sumar(int argc, char* argv[]) {
    if (argc < CANT_ARGS_CMD_SUMAR) {
        printf("Error: debes indicar dos numeros.\n");
        printf("Ejemplo: sumar 10 20\n");
        return ERROR;
    }

    if (argc != CANT_ARGS_CMD_SUMAR) {
        printf("Error: Exceso en cantidad de argumentos para el comando %s.\n", argv[IDX_COMANDO]);
        printf("Ejemplo: sumar 10 20\n");
        return ERROR;
    }

    int num1 = atoi(argv[IDX_PRIMER_SUMANDO]);
    int num2 = atoi(argv[IDX_SEGUNDO_SUMANDO]);

    printf("Resultado: %d + %d = %d\n",
           num1, num2, num1 + num2);

    return EXITO;
}


int contar(int argc, char* argv[]) {
    if (argc < CANT_ARGS_CMD_CONTAR) {
        printf("Error: debes indicar hasta que numero contar.\n");
        printf("Ejemplo: contar 5\n");
        return ERROR;
    }

    if (argc != CANT_ARGS_CMD_CONTAR) {
        printf("Error: Exceso en cantidad de argumentos para el comando %s.\n", argv[IDX_COMANDO]);
        printf("Ejemplo: contar 5\n");
        return ERROR;
    }

    int limite = atoi(argv[IDX_ARG_CONTAR]);

    if (limite < 1) {
        printf("Error: el numero debe ser mayor que cero.\n");
        return ERROR;
    }

    for (int i = 1; i <= limite; i++) {
        printf("%d ", i);
    }

    printf("\n");

    return EXITO;
}


bool comando_valido(char* comando) {
    int i = 0;
    bool valido = false;

    while(i < MAX_COMANDOS && !valido) {
        valido = strcmp(comando, COMANDOS[i]) == 0;
        i++;
    }

    return valido;
}
