#include <stdio.h>

#define MAX 7

// Esta implementación es la misma que usa el simulador que se encuentra entre las herramientas de la materia.
// La versión de 'seleccion.c' busca y selecciona el índice del máximo valor en el vector y lo coloca al final de los desordenadaos.
// Esta versión busca y selecciona el índica del mínimo valor en el vector y lo coloca al comienzo de los desordenados.
// Ambas implementaciones son válidas. 

/* Pre condiciones: 'tope' debe ser mayor o igual a 0 y menor o igual a MAX.
 * Post condiciones: ordena los elementos de 'vector' de manera ascendente (de menor a mayor).
 */
void ordenar_por_seleccion(int vector[MAX], int tope){
    int auxiliar;
    int indice_del_minimo;

    for(int i = 0; i < (tope - 1); i++) {
        indice_del_minimo = i;
        for (int j = (i + 1); j < tope; j++) {
            if (vector[indice_del_minimo] > vector [j]) {
                indice_del_minimo = j;
            }
        }
        auxiliar = vector [i];
        vector [i] = vector [indice_del_minimo];
        vector [indice_del_minimo] = auxiliar;
    }
}

/* Pre condiciones: 'tope' debe ser mayor o igual a 0 y menor o igual a MAX.
 * Post condiciones: Imprime por pantalla el contenido de 'vector' entre corchetes '[' ']'.
 */
void mostrar_vector(int vector[MAX], int tope){
    for(int i = 0; i < tope; i++) {
        if(i == 0) {
            printf("[");
        }
        
        printf(" %i", vector[i]);

        if(i == (tope - 1)) {
            printf( " ]\n");
        }
    }
}

int main() {
    int vector[MAX] = {14, 54, 12, 34, 45, 23, 11};
    int tope = 7;
    
    printf("Vector antes de ordenar por selección:\n");
    mostrar_vector(vector, tope);
    
    ordenar_por_seleccion(vector, tope);

    printf("Vector después de ordenar por selección:\n");
    mostrar_vector(vector, tope);

    return 0;
}