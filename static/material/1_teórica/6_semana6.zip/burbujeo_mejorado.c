#include <stdio.h>
#include <stdbool.h>

#define MAX 7

/* Pre condiciones: 'tope' debe ser mayor o igual a 0 y menor o igual a MAX.
 * Post condiciones: ordena los elementos de 'vector' de manera ascendente (de menor a mayor).
 */
void ordenar_por_burbujeo_mejorado (int vector[MAX], int tope){
    int i = 0, j, auxiliar;

    bool esta_ordenado = false;

    while((i < (tope - 1)) && (!esta_ordenado)){
        esta_ordenado = true;
        
        for (j = 0; j < (tope - i - 1); j++) {
            if(vector[j] > vector[j+1]) {
                auxiliar = vector[j];
                vector[j] = vector[j + 1];
                vector[j + 1] = auxiliar ;

                esta_ordenado = false;
            }
        }
        
        i++;
    }
}

/* Pre condiciones: 'tope' debe ser mayor o igual a 0 y menor o igual a MAX.
 * Post condiciones: Imprime por pantalla el contenido de 'vector' entre corchetes '[' ']'.
 */
void mostrar_vector(int vector[MAX], int tope){
    for(int i = 0; i < tope; i++) {
        if(i == 0) {
            printf("[");
        }
        
        printf(" %i", vector[i]);

        if(i == (tope - 1)) {
            printf( " ]\n");
        }
    }
}

int main() {
    int vector[MAX] = {100, 11, 22, 44, 55, 77, 99};
    int tope = 7;
    
    printf("Vector antes de ordenar por burbujeo mejorado:\n");
    mostrar_vector(vector, tope);
    
    ordenar_por_burbujeo_mejorado(vector, tope);

    printf("Vector después de ordenar por burbujeo mejorado:\n");
    mostrar_vector(vector, tope);

    return 0;
}