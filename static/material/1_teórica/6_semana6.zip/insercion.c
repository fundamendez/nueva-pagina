#include <stdio.h>

#define MAX 7

/* Pre condiciones: 'tope' debe ser mayor o igual a 0 y menor o igual a MAX.
 * Post condiciones: ordena los elementos de 'vector' de manera ascendente (de menor a mayor).
 */
void ordenar_por_insercion(int vector[MAX] , int tope ){
    int j, a_insertar;

    for (int i = 1; i < tope; i++) {
        j = i;
        a_insertar = vector[i];
        
        while((j > 0) && (a_insertar < vector[j - 1])){
            vector[j] = vector[j - 1];
            j--;
        }

        vector[j] = a_insertar;
    }
}

/* Pre condiciones: 'tope' debe ser mayor o igual a 0 y menor o igual a MAX.
 * Post condiciones: Imprime por pantalla el contenido de 'vector' entre corchetes '[' ']'.
 */
void mostrar_vector(int vector[MAX], int tope){
    for(int i = 0; i < tope; i++) {
        if(i == 0) {
            printf("[");
        }
        
        printf(" %i", vector[i]);

        if(i == (tope - 1)) {
            printf( " ]\n");
        }
    }
}

int main() {
    int vector[MAX] = {14, 54, 12, 34, 45, 23, 11};
    int tope = 7;

    printf("Vector antes de ordenar por inserción:\n");
    mostrar_vector(vector, tope);
    
    ordenar_por_insercion(vector , tope);

    printf("Vector después de ordenar por inserción:\n");
    mostrar_vector(vector, tope);

    return 0;
}
