#include <stdio.h>

#define MAX 7

/* Pre condiciones: 'tope' debe ser mayor o igual a 0 y menor o igual a MAX.
 * Post condiciones: ordena los elementos de 'vector' de manera ascendente (de menor a mayor).
 */
void ordenar_por_seleccion(int vector[MAX], int tope){
    int auxiliar;
    int indice_del_maximo;

    for(int i = 0; i < (tope - 1); i++) {
        indice_del_maximo = 0;
        for (int j = 1; j < (tope - i); j++) {
            if (vector[indice_del_maximo] < vector [j]) {
                indice_del_maximo = j;
            }
        }
        auxiliar = vector [tope - i - 1];
        vector [tope - i - 1] = vector [indice_del_maximo];
        vector [indice_del_maximo] = auxiliar;
    }
}

/* Pre condiciones: 'tope' debe ser mayor o igual a 0 y menor o igual a MAX.
 * Post condiciones: Imprime por pantalla el contenido de 'vector' entre corchetes '[' ']'.
 */
void mostrar_vector(int vector[MAX], int tope){
    for(int i = 0; i < tope; i++) {
        if(i == 0) {
            printf("[");
        }
        
        printf(" %i", vector[i]);

        if(i == (tope - 1)) {
            printf( " ]\n");
        }
    }
}

int main() {
    int vector[MAX] = {14, 54, 12, 34, 45, 23, 11};
    int tope = 7;
    
    printf("Vector antes de ordenar por selección:\n");
    mostrar_vector(vector, tope);
    
    ordenar_por_seleccion(vector, tope);

    printf("Vector después de ordenar por selección:\n");
    mostrar_vector(vector, tope);

    return 0;
}