// PARTE PRÁCTICA
// pre condiciones: 'regalos' tiene que haber sido creado 'pila_regalos_crear' e inicializado.
//                  'ninios' que haber sido creado 'cola_ninios_crear' e inicializado.
// post condiciones: quita los ninios y regalos de la cola y pila respectivamente si hay coincidencia.
void repartir_regalos(pila_regalos_t* regalos, cola_ninios_t* ninios) {
    pila_regalos_t* aux_regalos = pila_regalos_crear();
    cola_ninios_t* aux_ninios = cola_ninios_crear();

    while(!cola_ninios_esta_vacia(ninios)) {
        bool recibio_regalo = false;
        while(!pila_regalos_esta_vacia(regalos) && !recibio_regalo){
            regalo_t regalo_quitado;
            quitar_regalo(regalos, &regalo_quitado);

            if(ninio_pidio_regalo(ninios, regalo_quitado)){
                recibio_regalo = true;
            } else {
                guardar_regalo(aux_regalos, regalo_quitado);
            }
        }

        while(!pila_regalos_esta_vacia(aux_regalos)){
            regalo_t regalo_quitado;
            quitar_regalo(aux_regalos, &regalo_quitado);
            guardar_regalo(regalos, regalo_quitado);
        }

        ninio_t ninio_quitado;
        quitar_ninio(ninios, &ninio_quitado);
        if(!recibio_regalo) {
            guardar_ninio(aux_ninios, ninio_quitado);
        }
    }

    while(!cola_ninios_esta_vacia(aux_ninios)) {
        ninio_t ninio_quitado;
        quitar_ninio(aux_ninios, &ninio_quitado);
        guardar_ninio(ninios, ninio_quitado);
    }

    pila_regalos_destruir(aux_regalos);
    cola_ninios_destruir(aux_ninios);
}


/*
 * Ejercicio 3 parte teórica ¿Qué diferencia hay entre un puntero y una referencia en C?
 * Son lo mismo.
 * Un puntero es: Una variable que apunta a una dirección de memoria.
 * Una referencia es: Una puntero que apunta a una variable de nuestro programa.
 *
 * "Una referencia a NULL" No
 * "Un puntero a NULL" Si
 * "Tengo un puntero a mi variable en el main" Si
 * "Tengo una referencia a mi variable en el main" Si
 */
