// PARTE PRÁCTICA

typedef struct habitacion{
    int numero;
    char ocupantes[MAX_OCUPANTES]; // inicial del nombre
    int cantidad_ocupantes;
} habitacion_t;

const char BART = 'B';
const char LISA = 'L';
const char HOMERO = 'H';
const char MARGE = 'M';
const char TIAS = 'T';

typedef struct posicion{
    int fil;
    int col;
} posicion_t;

// pre condiciones: 'tope_fils' y 'tope_cols' deben ser menor o igual a 0 y menor a sus repesctivos máximos (MAX_FILS y MAX_COLS).
//                  debe haber una y sólo una inicial de cada personaje mencionado en el enunciado en alguna habitacion_t del campo 'hotel'.
//                  todos los 'cantidad_ocupantes' de las habitacion_t deben se menor o igual a 0 y menor MAX_OCUPANTES.
// post condiciones: devuelve true en caso de que la broma sea exitosa o false en caso contrario.
bool broma_exitosa(habitacion_t hotel[MAX_FILS][MAX_COLS], int tope_fils, int tope_cols) {
    posicion_t bart, lisa, homero, marge, tias;

    for(int i = 0; i < tope_fils; i++) {
        for(int j = 0; j < tope_cols; j++) {

            habitacion_t habitacion_actual = hotel[i][j];
            for(int k = 0; k < habitacion_actual.cantidad_ocupantes; k++) {
                if (habitacion_actual.ocupantes[k] == BART){
                    bart.fil = i;
                    bart.col = j;
                }
                else if (habitacion_actual.ocupantes[k] == LISA){
                    lisa.fil = i;
                    lisa.col = j;
                }
                else if (habitacion_actual.ocupantes[k] == MARGE){
                    marge.fil = i;
                    marge.col = j;
                }
                else if (habitacion_actual.ocupantes[k] == HOMERO){
                    homero.fil = i;
                    homero.col = j;
                }
                else if (habitacion_actual.ocupantes[k] == TIAS){
                    tias.fil = i;
                    tias.col = j;
                }
            }
        }
    }

    if(bart.fil != lisa.fil) {
        return false;
    }

    if((bart.fil > marge.fil && bart.fil < tias.fil) || (bart.fil < marge.fil && bart.fil > tias.fil)) {
        return false;
    }

    if(marge.fil == homero.fil && marge.col == homero.col) {
        return false;
    }

    return true;
}


// PARTE TEÓRICA

// a. ¿Qué son las pre condiciones de una función? ¿Qué son las post
// condiciones de una función? Dar ejemplos.

/*
a. Las precondiciones son las condiciones o requisitos necesarios que deben cumplir los valores de los parámetro de entrada de una función antes de se llamada y que no rompa su ejecución.
Las post condiciones son lo QUE hace (y no como lo hace) y/o devuelve la función cuando se cumplen las pre condiciones.

Ejemplo:
// pre condiciones: 'string1' y 'string2' deben terminar en '\0'.
//                  la cantidad máxima de la suma de caracteres de string1 y string2 debe ser menor a MAX.
// post condiciones: devuelve la concatenacion de 'string1' con 'string2' dentro de 'string1'.
void concatenar_strings(char string1[MAX], char string2[MAX]);

*/

// b. Explicar si la siguiente afirmación es Verdadera o Falsa y por qué:
// "Dado un vector y su tope, al acceder al elemento `vector[tope]`
// estoy accediendo a basura".

/*
VERDADERO
Es verdadero porque 'tope' indica la cantidad de elementos válido o inicializados en un vector, y como los vectores comienzan con sus índices a partir del 0 tenemos índices de valores válidos desde el 0 al tope-1, es decir que todo indice mayor a tope-1 es un índice con basura o fuera de rango.
*/


