// PARTE PRÁCTICA

typedef struct supertraje {
    int antiguedad;
    char color[MAX_COLOR];
    bool es_ganador;
} supertraje_t;


// Dado un vector de supertrajes que contiene todos los supertrajes del Hombre
// Pie (Pai) y su tope, crear una función recursiva que devuelva la posición
//de la idea de traje que le va a encargar a su modista.

const int NO_HAY_GANADOR = -1;
#define COLOR_BUSCADO "rojo"

// pre condiciones: el campo 'color' de 'idea' debe terminar en '\0'
// post condiciones: devuelve true si es un traje COLOR_BUSCADO más reciente y false en caso contrario
bool es_posible_ganador(supertraje_t idea, int antiguedad_ganador) {
    return strcmp(idea.color, COLOR_BUSCADO) == 0 && idea.antiguedad < antiguedad_ganador;
}


// pre condiciones: 'idea_actual' debe ser 0 en el primer llamado
//                  'ganador' debe ser NO_HAY_GANADOR en el primer llamado
//                  'cantidad_ideas' tiene que ser >= 0 y < MAX_IDEAS
//                  todos los campos 'color' de los supertraje_t de 'ideas' deben terminar en '\0'
// post condiciones: devuelve el indice de la idea de traje COLOR_BUSCADO más reciente
int obtener_idea_supertraje(supertraje_t ideas[MAX_IDEAS], int cantidad_ideas, int idea_actual, int ganador) {

    // condicion corte
    if(idea_actual >= cantidad_ideas) {
        return ganador;
    }

    // procesamiento
    if ((ganador == NO_HAY_GANADOR && strcmp(ideas[idea_actual].color, COLOR_BUSCADO) == 0) || es_posible_ganador(ideas[idea_actual], ideas[ganador].antiguedad)) {
        ganador = idea_actual;
    }

    // llamado recursivo
    return obtener_idea_supertraje(ideas, cantidad_ideas, idea_actual + 1, ganador);
}


// PARTE TEÓRICA

// a. ¿Qué elementos debe tener una función recursiva?
// b. ¿Qué tipo de dato es el campo color del struct supertraje? ¿Qué particularidad tiene ese tipo de dato?

/*
a. Una función recursiva debe constar de 3 elementos que son, llamado recursivo, procesamiento y condición de corte.
El llamado recursivo es la invocación de la función en misma implementación lo que provoca hambitos anidados.
La condición de corte es la comparación final que nos permite corta el ciclo de llamados recursivos.
El procesamiento es todo lo que no es ni llamado recursivo ni condición de corte de la función. En este se realizan los cálculo y/o operaciones necesarias para cambiar el estado previo al llamado recursivo.

b. El campo 'color' es un string ya que es un vector de caracteres y no tiene un tope asociado en otro campo del struct. También no da a entender eso su nombre.
Como particularidad este tipo de dato debe terminar en '\0' para indicar el fin de la palabra. Esto es porque C no cuenta con un tipo de dato nativo para estos casos pero se provee de una biblioteca para dicha funcionalidad que es string.h.
*/
