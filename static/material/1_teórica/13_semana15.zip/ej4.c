// PARTE PRÁCTICA

#include <string.h>

#define MAX_DESC 100
#define MAX_BARRIO 10

typedef struct edificio {
    char descripcion[MAX_DESC]; // "escuela", "casa de ned", "kiosco", etc
    char movimiento; // 'W', 'S', 'D' o 'A'
    int cantidad_municiones;
} edificio_t;

const char ULTIMO_EDIFICIO[MAX_DESC] = "casa de la familia simpson";
const char ARRIBA = 'W';
const char ABAJO = 'S';
const char IZQUIERDA = 'A';
const char DERECHA = 'D';

// Recursiva
// Pre: Fil_actual y col_actual empiezan en 0, maximo_actual_muninciones en -1.
// Post: Dentro de `descripcion_edificio_munciones_maxima` se guardará la descripción del edificio con la mayor cantidad de municiones que se encontró en el camino.
void llegar_a_casa(edificio_t barrio[MAX_BARRIO][MAX_BARRIO], char descripcion_edificio_munciones_maxima[MAX_DESC], int maximo_actual_muninciones, int fil_actual, int col_actual){

    // Actualizar `descripcion_edificio_munciones_maxima`
    if(barrio[fil_actual][col_actual].cantidad_municiones > maximo_actual_muninciones){
        maximo_actual_muninciones = barrio[fil_actual][col_actual].cantidad_municiones;
        strcpy(descripcion_edificio_munciones_maxima, barrio[fil_actual][col_actual].descripcion);
    }

    // Paro cuando llego a "casa de la familia simpson".
    if (strcmp(barrio[fil_actual][col_actual].descripcion, ULTIMO_EDIFICIO) == 0){
        return; // El valor de `descripcion_edificio_munciones_maxima` ya fue actualizado en una llamada anterior
    }


    // Actualizar posicion
    switch (barrio[fil_actual][col_actual].movimiento) {
       case ARRIBA:
            fil_actual--;
            break;

       case ABAJO:
            fil_actual++;
            break;

       case IZQUIERDA:
            col_actual--;
            break;

       case DERECHA:
            col_actual++;
            break;
    }

    llegar_a_casa(barrio, descripcion_edificio_munciones_maxima, maximo_actual_muninciones, fil_actual, col_actual);
}
