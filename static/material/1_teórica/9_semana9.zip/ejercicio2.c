#include <stdio.h>
#include <stdlib.h>

#define MAX_NOMBRE 100
const char SI = 'S';

typedef struct alumno {
    char nombre[MAX_NOMBRE];
    int padron;
    int edad;
} alumno_t;


#define ERROR_RESERVAR_MEMORIA -1


/* Pre condiciones: El campo 'nombre' de la referencia al alumno_t debe contener un string (terminar en \0).
 * Post condiciones: Muestra por pantalla los datos de los alumnos.
 */
void mostrar_alumnos(alumno_t* alumnos, int tope) {
    for(int i = 0; i < tope; i++){
        printf("Alumno nro %i:\n\tnombre: %s\n\tpadron: %i\n\tedad: %i\n\n", i+1, alumnos[i].nombre, alumnos[i].padron, alumnos[i].edad);        
    }
}


/* Pre condiciones: -
 * Post condiciones: llena los valores del alumno pidiendo los datos por consola.
 */
void pedir_datos_alumno(alumno_t* alumno, int orden_alumno) {
    printf("ALUMNO %i: cómo es su nombre?:\n", orden_alumno);
    scanf("%s", alumno->nombre);

    printf("ALUMNO %i: cómo es su padrón?:\n", orden_alumno);
    scanf("%i", &(alumno->padron));

    printf("ALUMNO %i: cuál es su edad?:\n", orden_alumno);
    scanf("%i", &(alumno->edad));
}


/* Pre condiciones: -
 * Post condiciones: pregunta al usuario si desea ingresar los datos de un nuevo alumno
 */
void preguntar_si_ingresa_un_alumno(char* respuesta) {
    printf("¿Quiere ingresar un alumno? [S] para si [cualquier otra tecla] para no\n");
    scanf(" %c", respuesta);
}


int main () {
    char respuesta;
    preguntar_si_ingresa_un_alumno(&respuesta);

    alumno_t* alumnos;    
    int i = 0;
    bool error = false;
    while(respuesta == SI && !error) {
        i++;
        alumnos = realloc(alumnos, sizeof(alumno_t) * i);
        if(alumnos == NULL) {
            printf("Hubo un error al reservar memoria\n");
            error = true;
        } else {     
            pedir_datos_alumno(&(alumnos[i]), i);
            preguntar_si_ingresa_un_alumno(&respuesta);
        }
    }

    if(!error) {
        mostrar_alumnos(alumnos, i);    
        free(alumnos);
    } else {
        return ERROR_RESERVAR_MEMORIA;
    }

    return 0;
}