#include <stdio.h>
#include <stdlib.h>

#define MAX_NOMBRE 100

typedef struct alumno {
    char nombre[MAX_NOMBRE];
    int padron;
    int edad;
} alumno_t;


#define ERROR_RESERVAR_MEMORIA -1


/* Pre condiciones: El campo 'nombre' de la referencia al alumno_t debe contener un string (terminar en \0).
 * Post condiciones: Muestra por pantalla los datos de los alumnos.
 */
void mostrar_alumnos(alumno_t* alumnos, int tope) {
    for(int i = 0; i < tope; i++){
        printf("Alumno nro %i:\n\tnombre: %s\n\tpadron: %i\n\tedad: %i\n\n", i+1, alumnos[i].nombre, alumnos[i].padron, alumnos[i].edad);        
    }
}


/* Pre condiciones: -
 * Post condiciones: Llena la variable a la que referenecia 'cantidad_alumnos' con un entero mayor a cero.
 */
void pedir_cantidad_alumnos(int *cantidad_alumnos) {
    printf("ingrese la cantidad de alumnos a registrar:\n");
    scanf("%i", cantidad_alumnos);
    while(*cantidad_alumnos <= 0) {
        printf("Cantidad inválid! Intente de nuevo\n");
        printf("ingrese la cantidad de alumnos a registrar:\n");
        scanf("%i", cantidad_alumnos);
    }
}


/* Pre condiciones: -
 * Post condiciones: llena los valores del alumno pidiendo los datos por consola.
 */
void pedir_datos_alumno(alumno_t* alumno, int orden_alumno) {
    printf("ALUMNO %i: cómo es su nombre?:\n", orden_alumno+1);
    scanf("%s", alumno->nombre);

    printf("ALUMNO %i: cómo es su padrón?:\n", orden_alumno+1);
    scanf("%i", &(alumno->padron));

    printf("ALUMNO %i: cuál es su edad?:\n", orden_alumno+1);
    scanf("%i", &(alumno->edad));
}


int main () {
    int cantidad_alumnos;

    pedir_cantidad_alumnos(&cantidad_alumnos);

    alumno_t* alumnos;
    alumnos = malloc(sizeof(alumno_t) * cantidad_alumnos);
    if(alumnos == NULL) {
        printf("Hubo un error al reservar memoria\n");
        return ERROR_RESERVAR_MEMORIA;
    }

    for(int i = 0; i < cantidad_alumnos; i++){        
        pedir_datos_alumno(&(alumnos[i]), i);
    }

    mostrar_alumnos(alumnos, cantidad_alumnos);
    
    free(alumnos);

    return 0;
}