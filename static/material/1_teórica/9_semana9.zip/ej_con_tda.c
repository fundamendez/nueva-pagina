#include <stdio.h>
#include <stdlib.h>

#include "vector_din.h"


#define ERROR_CREAR_TDA -1
const char SI = 'S';


/* Pre condiciones: El tda `alumnos` debe estar previamente creado con `vec_crear` y llenado.
 * Post condiciones: Muestra por pantalla los datos de los alumnos.
 */
void mostrar_alumnos(vector_din_t* alumnos) {
    int tope = vec_largo(alumnos);

    for(int i = 0; i < tope; i++){
        alumno_t* alumno_actual = vec_obtener(alumnos, i);

        printf("Alumno nro %i:\n\tnombre: %s\n\tpadron: %i\n\tedad: %i\n\n", i+1, alumno_actual->nombre, alumno_actual->padron, alumno_actual->edad);        
    }
}


/* Pre condiciones: -
 * Post condiciones: llena los valores del alumno pidiendo los datos por consola.
 */
void pedir_datos_alumno(alumno_t* alumno, int orden_alumno) {
    printf("ALUMNO %i: cómo es su nombre?:\n", orden_alumno);
    scanf("%s", alumno->nombre);

    printf("ALUMNO %i: cómo es su padrón?:\n", orden_alumno);
    scanf("%i", &(alumno->padron));

    printf("ALUMNO %i: cuál es su edad?:\n", orden_alumno);
    scanf("%i", &(alumno->edad));
}

/* Pre condiciones: -
 * Post condiciones: pregunta al usuario si desea ingresar los datos de un nuevo alumno
 */
void preguntar_si_ingresa_un_alumno(char* respuesta) {
    printf("¿Quiere ingresar un alumno? [S] para si [cualquier otra tecla] para no\n");
    scanf(" %c", respuesta);
}


int main () {
    vector_din_t* alumnos = vec_crear();
    if(alumnos == NULL) {
        printf("Error al intentar crear una instancia del TDA vector dinamico\n");
        return ERROR_CREAR_TDA;
    }

    char respuesta;
    preguntar_si_ingresa_un_alumno(&respuesta);
    
    int i = 0;
    while(respuesta == SI) {
        i++;
        alumno_t alumno_actual;
        pedir_datos_alumno(&alumno_actual, i);
        vec_guardar(alumnos, alumno_actual);

        preguntar_si_ingresa_un_alumno(&respuesta);
    }

    mostrar_alumnos(alumnos);

    vec_destruir(alumnos);
    return 0;
}