#include <stdio.h>

int const NO_ENCONTRADO = -1;

int busqueda_binaria(int vector[], int tope, int valor_buscado) {
  int inicio = 0;
  int fin = tope - 1;
  int medio = (inicio + fin) / 2;

  while (vector[medio] != valor_buscado && inicio <= fin) {
    if (vector[medio] < valor_buscado) {
      inicio = medio + 1;
    } else if (vector[medio] > valor_buscado) {
      fin = medio - 1;
    }

    medio = (inicio + fin) / 2;
  }

  if (inicio > fin) {
    return NO_ENCONTRADO;
  }

  return medio;
}

int bus_binaria_recursiva(int vector[], int tope, int valor_buscado, int inicio,
                          int fin) {
  int medio = (inicio + fin) / 2;

  if (inicio > fin) {
    return NO_ENCONTRADO;
  }

  if (vector[medio] == valor_buscado) {
    return medio;
  }

  if (vector[medio] < valor_buscado) {
    inicio = medio + 1;
  } else if (vector[medio] > valor_buscado) {
    fin = medio - 1;
  }

  return bus_binaria_recursiva(vector, tope, valor_buscado, inicio, fin);
}
