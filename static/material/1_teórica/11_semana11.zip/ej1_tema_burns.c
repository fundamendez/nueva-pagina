#include <stdbool.h>
#define MAX_NOMBRE 100
#define MAX_DIRECCION 100

typedef struct propietario {
    char nombre[MAX_NOMBRE];
    int edad;
    bool es_adinerado;
} propietario_t;

typedef struct casa {
    char direccion[MAX_DIRECCION];
    int nieve_cm;
    propietario_t propietario;
} casa_t;

const int CANTIDAD_MINIMA_CM = 0;
const int TARIFA_SIMPLE = 2;
const int TARIFA_EXCEDENTE = 3;
const int COSTO_NAFTA = 5;
const int MAX_CM_TARIFA_SIMPLE = 20;

/* Pre condiciones: 'tope_fils' debe ser mayor o igual a 0 y menor o igual a MAX_FILS.
                    'tope_cols' debe ser mayor o igual a 0 y menor o igual a MAX_COLS.
 * Post condiciones: devuelve por referencia la ganancia neta total obtenida por Don Barredora en 'ganancia_total'.
 */
void contar_ganacia_limpieza(casa_t casas[MAX_FILS][MAX_COLS], int tope_fils, int tope_cols, int* ganancia_total) {
    (*ganancia_total) = 0;

    for(int i = 0; i < tope_fils; i++) {
        for(int j = 0; j < tope_cols; j++) {
            if((casas[i][j].propietario.es_adinerado) && (casas[i][j].nieve_cm > CANTIDAD_MINIMA_CM)) {
                (*ganancia_total) += ganancia_al_limpiar_casa(casa[i][j].nieve_cm);
            }
        }
    }
}

/* Pre condiciones: -
 * Post condiciones: devuelve el calculo de ganancia dependiendo la cantidad de 'nieve_cm'.
 */
int ganancia_al_limpiar_casa(int nieve_cm) {
    int ganancia = 0;
    if(nieve_cm > MAX_CM_TARIFA_SIMPLE) {
        ganancia = MAX_CM_TARIFA_SIMPLE * TARIFA_SIMPLE + (nieve_cm - MAX_CM_TARIFA_SIMPLE) * TARIFA_EXCEDENTE;
    } else {
        ganancia = nieve_cm * TARIFA_SIMPLE;
    }

    return ganancia - COSTO_NAFTA;
}
