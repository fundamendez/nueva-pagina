# Tema Smithers
-------------------------------------------

##### Enunciado
1. Referido a bibliotecas, indicar en las distintas situaciones que archivo debería enviar y por qué.

    a. Compartir una funcionalidad sin que puedan ver la implementación.
    b. Compartir cuáles son las funcionalidades públicas.
    c. Compartir toda mi implementación.

##### Respuesta
a. .o -- el .o es el archivo ejecutable que resulta de la compilacion del archivo .c. Esto permite compartir la funcionalidad a otra persona sin que la misma pueda ver como esta implementada. 
b. .h -- es donde se detallan las firmas de las funciones publicas con sus pre y post por lo que permite darle la informacion a otra persona de QUE funcionalidad publicas tengo y COMO funcionan, pero no permite utilizarlas ni ver como estan implementadas. 
c. .c -- es el que contiene la implementacion de las funcionalidades publicas y las

-------------------------------------------

##### Enunciado
2. Dado el siguiente código, resolver:

```c
    void calc_doble(int o, int* desc) {
        desc = o*2;
    }

    int main() {
        int original;
        int descrifrado = 0;

        calc_doble(original, descrifrado);
        printf("%i", descrifrado)
    }
```

a. El código tiene un error. ¿Cuál es? ¿Qué concepto que vimos en la clase nos ayuda a resolverlo?
b. ¿Cuáles son las buenas prácticas que no está cumpliendo?

##### Respuesta
a. Por parametro pido desc como puntero pero no le paso un int*. El valor de desc nunca se actualiza.

codigo corregido: 
```c
    void calc_doble(int o, int* desc) {
        *desc = o*2;
    }

    int main() {
        int original;
        int descrifrado = 0;

        calc_doble(original, &descrifrado);
        printf("%i", descrifrado);

        return 0;
    }
```
b. Pre y post en calc_doble, inicialización de original, nombres de variables/funcion poco descriptivos

-------------------------------------------

# Tema Sr. Burns

##### Enunciado
1. Referido a bibliotecas, indicar en las distintas situaciones que archivo debería enviar y por qué.
    a. Compartir toda mi implementación.
    b. Compartir cuáles son las funcionalidades públicas.
    c. Compartir una funcionalidad sin que puedan ver la implementación.

##### Respuesta
a. .c
b. .h
c. .o (tambien es valida la respues .o y .h)

Justificación mismo que tema anterior.

-------------------------------------------

##### Enunciado
2. Dado el siguiente código, resolver:

```c
    void aplicar_desc(float o, float f) {
        f = o * 0.80; 
    }

    int main() {
        float original;
        float final = 0;

        aplicar_desc(original, final);

        printf("El total a pagar es: %f\n", final);
        return 0;
    }
```

a. El código tiene un error. ¿Cuál es? ¿Qué concepto que vimos en la clase nos ayuda a resolverlo?
b. ¿Cuáles son las buenas prácticas que no está cumpliendo?

##### Respuesta
a. La funcion aplicar descuento toma dos parametros pero el cambio de la variable f muere en el scope porque se pasa por valor y no por referencia.

codigo corregido:
```c
    void aplicar_desc(float o, float* f) {
        *f = o * 0.80; 
    }

    int main() {
        float original;
        float final = 0;

        aplicar_desc(original, &final);

        printf("El total a pagar es: %f\n", final);
        return 0;
    }
```

b. Pre y post condiciones, nombres descriptivos para funciones y parametros, constante para el valor del descuento, inicializacion de la variable original.

