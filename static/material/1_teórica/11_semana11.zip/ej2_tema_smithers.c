#include <stdbool.h>
#define MAX_TROFEOS 100
#define MAX_MATERIA 100
#define MAX_VITRINAS 100

typedef struct vitrina {
    trofeo_t trofeos[MAX_TROFEOS];
    int cantidad_trofeos;
    bool rota;
    char materia[MAX_MATERIA]; // "química", "física", etc.
} vitrina_t;

typedef struct trofeo {
    int año;
    int posicion;
    char pulido;
} trofeo_t;

const char MATERIA_BUSCADA[MAX_MATERIA] = "quimica";
const int ANIO_BUSCADO = 2014;
const int NO_HAY_VITRINA_BUSCADA = -1;

/* Pre condiciones: el campo 'materia' de los 'trofeo_t' de las 'vitrina_t' debe ser un string.
                    el campo 'cantidad_trofeos' de los 'trofeo_t' de las 'vitrina_t' debe ser mayor o igual a 0 y menor o igual a  MAX_TROFEOS.
                    'tope_vitrinas' debe ser mayor o igual a 0 y menor o igual a MAX_VITRINAS.
                    'cantidad_actual' debe valer 0 en el primer llamado.
                    'hay_al_menos_una_vitrina' debe valer false en el primer llamado.
 * Post condiciones: devuelve la cantidad de trofeos de MATERIA_BUSCADA que Lisa ganó en ANIO_BUSCADO, o NO_HAY_VITRINA_BUSCADA si no hay ninguna vitrina de MATERIA_BUSCADA.
 */
int cantidad_trofeos_buscados(vitrina_t vitrinas[MAX_VITRINAS], int tope_vitrinas, int vitrina_actual, int cantidad_actual, bool hay_al_menos_una_vitrina) {
    if(cantidad_actual == tope_vitrinas) {
        if(hay_al_menos_una_vitrina) {
            return cantidad_actual;
        } else {
            return NO_HAY_VITRINA_BUSCADA;
        }
    }

    if(strcmp(vitrinas[vitrina_actual].materia, MATERIA_BUSCADA) == 0) {
        hay_al_menos_una_vitrina = true;
        cantidad_actual += cantidad_trofeos(vitrinas[vitrina_actual].trofeos, vitrinas[vitrina_actual].cantidad_trofeos);
    }


    return cantidad_trofeos_buscados(vitrinas, tope_vitrinas, vitrina_actual + 1, cantidad_actual,hay_al_menos_una_vitrina);
}

/* Pre condiciones: el parámetro 'cantidad_trofeos' debe ser mayor o igual a 0 y menor o igual a  MAX_TROFEOS.
 * Post condiciones: devuelve la cantidad de trofeos que hay en el vector del año ANIO_BUSCADO.
 */
int cantidad_trofeos(trofeo_t trofeos[MAX_TROFEOS], int cantidad_trofeos) {
    int cantidad = 0;
    for(int i = 0; i < cantidad_trofeos; i++) {
        if(trofeos[i].año == ANIO_BUSCADO) {
            cantidad++;
        }
    }

    return cantidad;
}