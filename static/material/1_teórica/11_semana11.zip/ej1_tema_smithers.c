#include <stdbool.h>
#define MAX_COLOR 100

typedef struct fachada{
    char color[MAX_COLOR]; // "rojo", "amarillo", "verde"
    bool tiene_grafiti;
    int cantidad_ventanas;
} fachada_t;

typedef struct casa {
    int altura;
    fachada_t fachada;
    bool abandonada;
} casa_t;


#define CANTIDAD_COLORES_GRAFITEABLES 2
const char COLORES_GRAFITEABLES[CANTIDAD_COLORES_GRAFITEABLES][MAX_COLOR] = {"blanco", "azul"};

/* Pre condiciones: todos los campos 'color' de los 'fachada_t' de las 'casa_t' deben ser un string.
                    'tope_fils' debe ser mayor o igual a 0 y menor o igual a MAX_FILS.
                    'tope_cols' debe ser mayor o igual a 0 y menor o igual a MAX_COLS.
                    'tope_alturas' debe referenciar a una variable con valor mayor o igual a 0 y menor o igual a MAX_ALTURAS.
 * Post condiciones: llena el vector 'alturas_grafiteables' con las alturas de casas grafiteables.
*/
void cargar_alturas_casas_grafiteables(casa_t casas[MAX_FILS][MAX_COLS], int tope_fils, int tope_cols, int alturas_grafiteables[MAX_ALTURAS], int* tope_alturas) {
    for(int i = 0; i < tope_fils; i++) {
        for(int j = 0; j < tope_cols; j++) {
            if(es_grafiteable(casa[i][j])) {
                alturas_grafiteables[*tope_alturas] = casas[i][j].altura;
                (*tope_alturas)++;
            }
        }
    }
}

/* Pre condiciones: el campo 'color' de la 'fachada_t' de la 'casa_t' debe ser un string.
 * Post condiciones: devuelve true si la casa es grafiteable o false en caso contrario.
*/
bool es_grafiteable(casa_t casa) {
    bool es_color_grafiteable = false;

    for(int i = 0; i < CANTIDAD_COLORES_GRAFITEABLES; i++) {
        if(strcmp(casa.facha.color, COLORES_GRAFITEABLES[i]) == 0) {
            es_color_grafiteable = true;
        }
    }

    return es_color_grafiteable && casa.abandonada && !casa.fachada.tiene_grafiti;
}