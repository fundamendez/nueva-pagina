#include <stdbool.h>

#define MAX_NOMBRE 100
#define MAX_ALUMNOS 100
#define MAX_BANDAS 100

typedef struct banda {
    int identificación;
    char nombre_banda[MAX_NOMBRE];
    alumno_t alumnos[MAX_ALUMNOS];
    int cantidad_alumnos;
    char ciudad[MAX_NOMBRE];
} banda_t;

typedef struct alumno{
    char nombre[MAX_NOMBRE];
    int notas_erradas;
    char instrumento[MAX_NOMBRE];
} alumno_t;

const char ALUMNO_BUSCADO[MAX_NOMBRE] = "Nelson";
#define CANTIDAD_INSTRUMENTOS_NO_TRAMPOSOS 2
const char INSTRUMENTOS_NO_TRAMPOSOS[CANTIDAD_INSTRUMENTOS_NO_TRAMPOSOS][MAX_NOMBRE] = {"triangulo", "clarinete"};
const int BANDA_NO_ENCONTRADA = -1;

/* Pre condiciones: 'tope_bandas' debe ser mayor o igual a 0 y menor o igual a MAX_BANDAS.
                    'banda_actual' debe valer 0 en el primer llamado.
                    los campos 'cantidad_alumnos' de los alumno_t de las banda_t deben ser strings, y los campos 'instrumento' de los alumno_t de las banda_t deben ser strings.
                    el campo 'cantidad_alumnos' de las banda_t debe mayor o igual a 0 y menor o igual a MAX_ALUMNOS.
 * Post condiciones: devuelve la identificacion de la banda tramposa o BANDA_NO_ENCONTRADA si no la encuentra.
 */
int identificacion_banda_tramposa(banda_t bandas[MAX_BANDAS], int tope_bandas, int banda_actual) {
    if(banda_actual == tope_bandas) {
        return BANDA_NO_ENCONTRADA;
    }

    if(es_banda_tramposa(bandas[banda_actual])) {
        return bandas[banda_actual].identificación;
    }

    return identificacion_banda_tramposa(bandas, tope_bandas, banda_actual + 1);
}

/* Pre condiciones: el campo 'cantidad_alumnos' debe ser un string, y el campo 'instrumento' debe ser un string.
                    el campo 'cantidad_alumnos' debe mayor o igual a 0 y menor o igual a MAX_ALUMNOS.
 * Post condiciones: devuelve true si es una banda tramposa (esta NELSON y no hay triangulos ni clarinete) o false en caso contrario.
 */
bool es_banda_tramposa(banda_t banda) {
    bool esta_nelson = false;
    bool usa_instrumento_tramposo = true;

    int i = 0;
    while(i < banda.cantidad_alumnos && (!esta_nelson || usa_instrumento_tramposo)){
        if(strcmp(banda.alumnos[i].nombre, ALUMNO_BUSCADO) == 0) {
            esta_nelson = true;
        }

        for(int j = 0; j < CANTIDAD_INSTRUMENTOS_NO_TRAMPOSOS; j++) {
            if(strcmp(banda.alumnos[i].instrumento, INSTRUMENTOS_NO_TRAMPOSOS[j]) == 0) {
                usa_instrumento_tramposo = false;
            }
        }

        i++;
    }

    return esta_nelson && usa_instrumento_tramposo;
}