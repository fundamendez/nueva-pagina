#include <stdio.h>
#include <stdbool.h>

#define MAX_CLIENTES 3

typedef struct cliente {
    char inicial_nombre;
    int edad;
    bool tiene_deuda;
} cliente_t;

int main() {
    cliente_t clientes[MAX_CLIENTES] = {
        {'H', 39, true},
        {'L', 40, true},
        {'M', 35, false}
    };

    for (int i = 0; i < MAX_CLIENTES; i++) {
        printf("Cliente: %c\n", clientes[i].inicial_nombre);

        if (clientes[i].tiene_deuda) {
            printf("Tiene deuda\n");
        } else {
            printf("No tiene deuda\n");
        }
    }

    return 0;
}