#include <stdio.h>
#include <stdbool.h>

typedef struct monoplaza {
    int numero;
    int potencia;
    bool tiene_drs;
} monoplaza_t;

typedef struct piloto {
    char inicial;
    int edad;
    monoplaza_t monoplaza;
} piloto_t;

int main() {
    piloto_t piloto;

    printf("Ingrese la inicial del piloto: ");
    scanf(" %c", &piloto.inicial);

    printf("Ingrese la edad: ");
    scanf("%i", &piloto.edad);

    printf("Ingrese el numero del auto: ");
    scanf("%i", &piloto.monoplaza.numero);

    printf("Ingrese la potencia del auto: ");
    scanf("%i", &piloto.monoplaza.potencia);

    int tiene_drs;

    printf("¿Tiene DRS? (1 = si, 0 = no): ");
    scanf("%d", &tiene_drs);

    piloto.monoplaza.tiene_drs = (tiene_drs != 0);

    printf("\n--- Piloto ingresado ---\n");
    printf("Piloto: %c\n", piloto.inicial);
    printf("Edad: %d\n", piloto.edad);
    printf("Numero del auto: %d\n", piloto.monoplaza.numero);
    printf("Potencia: %d CV\n", piloto.monoplaza.potencia);

    if (piloto.monoplaza.tiene_drs) {
        printf("Tiene DRS\n");
    } else {
        printf("No tiene DRS\n");
    }

    return 0;
}