#include<stdio.h>



int main(){
    int notas[100];

    for (int i = 0; i < 100; i++){
        notas[i] = i;
    }
    printf("%p\n", notas);
    printf("%i\n", *notas);
    return 0;
}
