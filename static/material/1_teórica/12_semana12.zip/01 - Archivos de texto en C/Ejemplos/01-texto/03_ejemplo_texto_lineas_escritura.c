#include <stdio.h>

const int ERROR = -1;

#define MAX_LINEA 100

const char* RUTA_ARCHIVO_FRASES = "frases_simpsons.txt";
const char* MODO_APPEND = "a";

int main () {

    FILE* archivo_frases_simpsons = fopen(RUTA_ARCHIVO_FRASES, MODO_APPEND);

    if (!archivo_frases_simpsons) {
        printf("Error al intentar abrir el archivo '%s'\n", RUTA_ARCHIVO_FRASES);
        return ERROR;
    }

    char linea[MAX_LINEA] = "Esta es una línea agregada por nosotros los alumnos el martes 3 de noviembre de 2026."; // 85 letras peron son 86 por la 'í' de "línea" ocupa 2 bytes

    int escritos = fprintf(archivo_frases_simpsons, "%s\n", linea); // 87 + el '\n'

    printf("Se escribieron %i elementos\n", escritos);

    fclose(archivo_frases_simpsons);

    return 0;
}