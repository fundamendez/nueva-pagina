#include <stdio.h>

const int ERROR = -1;

#define MAX_PALABRA 30

int main () {

    FILE* frases_simpsons = fopen("frases_simpsons.txt", "r");

    if (!frases_simpsons) {
        printf("Error al intentar abrir el archivo 'frases_simpsons.txt'\n");
        return ERROR;
    }

    char palabra[MAX_PALABRA];

    int cantidad_palabras_leidas = 0;
    int leido = fscanf(frases_simpsons, "%s", palabra);
    while(leido != EOF) {
        cantidad_palabras_leidas++;
        printf("Palabra nro %i: %s\n", cantidad_palabras_leidas, palabra);
        leido = fscanf(frases_simpsons, "%s", palabra);
    }

    fclose(frases_simpsons);
    
    return 0;
}