#include <stdio.h>

#define MAX_NOMBRE 100

// Pre: recibo todos los archivos abiertos correctamente, archivo 1 y 2 abiertos
// para lectura y resultado para escritura. Ambos archivos están ordenados con
// el mismo criterio.
// Post: Devuelve la intersección entre los archivos, en el archivo resultado,
// guardando de manera ordenada.
void interseccion(FILE *archivo1, FILE *archivo2, FILE *resultado) {
  int id1, padron1;
  char nombre1[MAX_NOMBRE];
  int leidos_1 = fscanf(archivo1, "%i;%[^;];%i\n", &id1, nombre1, &padron1);

  int id2, padron2;
  char nombre2[MAX_NOMBRE];
  int leidos_2 = fscanf(archivo2, "%i;%[^;];%i\n", &id2, nombre2, &padron2);

  while (leidos_1 != EOF && leidos_2 != EOF) {
    if (id1 > id2) {
      leidos_2 = fscanf(archivo2, "%i;%[^;];%i\n", &id2, nombre2, &padron2);
    } else if (id1 < id2) {
      leidos_1 = fscanf(archivo1, "%i;%[^;];%i\n", &id1, nombre1, &padron1);
    } else {
      fprintf(resultado, "%i;%s;%i\n", id2, nombre2, padron2);
      leidos_1 = fscanf(archivo1, "%i;%[^;];%i\n", &id1, nombre1, &padron1);
      leidos_2 = fscanf(archivo2, "%i;%[^;];%i\n", &id2, nombre2, &padron2);
    }
  }
}
