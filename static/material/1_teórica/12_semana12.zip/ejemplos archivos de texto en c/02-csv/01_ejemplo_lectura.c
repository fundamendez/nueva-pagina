#include <stdio.h>

const int ERROR = -1;

#define MAX_NOMBRE_ALUMNO 100
#define MAX_CORRECTOR 50

int main () {

    FILE* alumnos = fopen("alumnos.csv", "r");

    if (!alumnos) {
        printf("Error al intentar abrir el archivo 'alumnos.csv'\n");
        return ERROR;
    }

    int id_alumno;
    char nombre_alumno[MAX_NOMBRE_ALUMNO];
    int padron;
    char corrector[MAX_CORRECTOR];
    int cantidad_alumnos_leidos = 0;

    int leido = fscanf(alumnos, "%i;%[^;];%i;%[^\n]\n", &id_alumno, nombre_alumno, &padron, corrector);

    while(leido != EOF) {
        cantidad_alumnos_leidos++;
        printf("Alumno %i:\nid:%i\nnombre: %s\npadron: %i\ncorrector: %s\n\n", cantidad_alumnos_leidos, id_alumno, nombre_alumno, padron, corrector);
        leido = fscanf(alumnos, "%i;%[^;];%i;%[^\n]\n", &id_alumno, nombre_alumno, &padron, corrector);
    }

    fclose(alumnos);

    return 0;
}