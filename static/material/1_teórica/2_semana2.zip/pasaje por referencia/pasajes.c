#include <stdio.h>

// ===================
// 1. PASAJE POR VALOR
// ===================
void modificar_por_valor(int donas) {
    printf("   [Valor] Recibi una copia con %d donas.\n", donas);
    donas = donas + 5; 
    printf("   [Valor] Le sume 5 a mi copia. Ahora mi copia tiene %d donas.\n", donas);
}

// ========================
// 2. PASAJE POR REFERENCIA 
// ========================
void modificar_por_referencia(int *ref_donas) {
    printf("   [Referencia] Viaje a la direccion de memoria de la cajita original.\n");
    printf("   [Referencia] Encontre %d donas adentro.\n", *ref_donas);
    *ref_donas = *ref_donas + 10;
    printf("   [Referencia] Agregue 10 donas a la cajita original!\n");
}

// =======================================
// 3. PASANDO LA REFERENCIA A OTRA FUNCiÓN
// =======================================
void agregar_glaseado(int *ref_donas_final) {
    *ref_donas_final = *ref_donas_final + 100;
    printf("   [Glaseado] Llegue a la cajita final y le sume 100 donas extra!\n");
}

void intermediario(int *ref_donas) {
    printf("   [Intermediario] Recibi la direccion. Se la paso INTACTA a la proxima funcion...\n");
    agregar_glaseado(ref_donas); 
}

int main() {
    int mis_donas = 5;
    
    printf("=== INICIO DEL PROGRAMA ===\n");
    printf("Cajita original 'mis_donas': %d\n\n", mis_donas);

    // --- CASO 1 ---
    printf("--- Caso 1: Pasaje por VALOR ---\n");
    modificar_por_valor(mis_donas);
    printf(">> Resultado en main despues de VALOR: %d donas\n\n", mis_donas);

    // --- CASO 2 ---
    printf("--- Caso 2: Pasaje por REFERENCIA ---\n");
    modificar_por_referencia(&mis_donas); // Le pasamos la direccion con &
    printf(">> Resultado en main despues de REFERENCIA: %d donas\n\n", mis_donas);

    // --- CASO 3 ---
    printf("--- Caso 3: El Intermediario ---\n");
    intermediario(&mis_donas);
    printf(">> Resultado en main despues del INTERMEDIARIO: %d donas\n\n", mis_donas);

    return 0;
}
