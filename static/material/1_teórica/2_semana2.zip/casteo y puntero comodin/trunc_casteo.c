#include <stdio.h>

int truncar (float valor) {
    int truncado = (int) valor;
    return truncado;
}

int main() {
    float valor_antes = 3.1415;

    int valor_truncado = truncar(valor_antes);
    printf("\nValor antes %f y valor truncado %i\n\n", valor_antes, valor_truncado);

    return 0;
}
