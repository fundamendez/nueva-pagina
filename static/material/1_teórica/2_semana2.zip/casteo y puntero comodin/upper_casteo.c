#include <stdio.h>

char upper (char minuscula) {
    int minus_ascii = (int) minuscula;
    int mayus_ascii = minus_ascii - 32;
    char mayuscula = (char) mayus_ascii ;
    return mayuscula;
}

// char upper (char minuscula) {
//     return (char) (((int) minuscula) - 32);
// }

// char upper (char minuscula) {
//     if (minuscula < 'a' || minuscula >'z') {
//         return minuscula;
//     }
//     return (char) (((int) minuscula) - 32);
// }

// char upper (char minuscula) {
//     if ((int) minuscula < 97 || (int) minuscula > 122) {
//         return minuscula;
//     }
//     return (char) (((int) minuscula) - 32);
// }

int main() {
    char letra;
    printf("\nIngrese una letra:");
    scanf(" %c", &letra);

    char letra_nueva = upper(letra);
    printf("\nLa letra era %c y ahora es %c\n\n", letra, letra_nueva);

    return 0;
}
