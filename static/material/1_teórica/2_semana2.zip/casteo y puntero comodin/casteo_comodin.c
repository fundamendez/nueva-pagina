#include <stdio.h>

const char ENTERO = 'i';
const char CARACTER = 'c';

void mostrar_dato_como (void* ptr_dato, char tipo) {
	if (tipo == ENTERO) {
        printf("\nEl valor del dato es %i\n\n", *((int*)ptr_dato));
    } else if (tipo == CARACTER) {
        printf("\nEl valor del dato es %c\n\n", *((char*)ptr_dato));
    } // …
}

int main() {
    int dato = 97;

    mostrar_dato_como(&dato, ENTERO);

    return 0;
}
