#include <stdio.h>

int main() {
    // Defino un vector de 4 elementos.
    int vector[4] = {10, 20, 30, 40};

    // Imprimo la dirección del vector.
    printf("%p\n", vector);

    // Imprimo la dirección del primer elemento del vector.
    printf("%p\n", &vector[0]);

    return 0;
}
