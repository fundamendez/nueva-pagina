#include <stdio.h>

int main() {
    // Declaramos una variable entera.
    int numero = 10;
    
    // Declaramos un puntero que guarda la dirección de memoria de 'número'.
    int *puntero = &numero;

    // Imprimimos el valor de la variable.
    printf("El valor de la variable es: %d\n", numero);
    
    // Imprimimos el puntero usando el formato %p (pointer).
    printf("La direccion en memoria es: %p\n", puntero);

    return 0;
}
