#include <stdio.h>

struct Persona_1 {
    char inicial_apellido;
    int edad;
    char inicial_nombre;
};

struct Persona_2 {
    char inicial_apellido;
    char inicial_nombre;
    int edad;
};

int main() {
    // Declaración de variables
    int vector[4] = {10, 20, 30, 40};
    int entero = 42;
    char caracter = 'A';
    int* puntero_entero = &entero;
    char* puntero_caracter = &caracter;
    struct Persona_1 persona1 = {'A', 23, 'F'};
    struct Persona_2 persona2 = {'A', 'F', 23};

    // Tamaño de los tipos primitivos.
    printf("--- Tamaño de los tipos primitivos ---\n");
    printf("sizeof(int): %zu bytes\n", sizeof(entero));
    printf("sizeof(char): %zu bytes\n", sizeof(caracter));

    // Tamaño de los punteros.
    printf("\n--- Tamaño de los punteros---\n");
    printf("sizeof(int*): %zu bytes\n", sizeof(puntero_entero));
    printf("sizeof(char*): %zu bytes\n", sizeof(puntero_caracter));

    // Tamaño del vector.
    printf("\n--- Tamaño del vector ---\n");
    printf("sizeof(vector): %zu bytes\n", sizeof(vector));
    size_t cantidad_elementos = sizeof(vector) / sizeof(vector[0]);
    printf("Cantidad de elementos en el vector: %zu\n", cantidad_elementos);

    // Tamaño de los structs.
    printf("\n--- Tamaño de Structs ---\n");
    printf("sizeof(struct Persona_1): %zu bytes\n", sizeof(persona1));
    printf("sizeof(struct Persona_2): %zu bytes\n", sizeof(persona2));

    return 0;
}
