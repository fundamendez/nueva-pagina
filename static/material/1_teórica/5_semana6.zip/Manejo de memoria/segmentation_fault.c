#include <stdio.h>

int main() {
    printf("Iniciando el programa...\n");

    // Creamos un puntero que no apunta a ningún lugar válido (NULL).
    int *puntero_peligroso = NULL;

    printf("A punto de cometer un delito de memoria...\n");

    // EL ERROR CRÍTICO: 
    // Intentamos ir a la dirección "nada" y guardar el número 42.
    // El Sistema Operativo (Linux) detecta esto y aniquila el proceso.
    *puntero_peligroso = 42;

    // Esta línea jamás llegará a ejecutarse.
    printf("Mision cumplida (Esto nunca se imprimira).\n");

    return 0;
}
