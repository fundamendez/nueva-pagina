#include <stdio.h>
#include "algotron.h"
#include <string.h>

const int ERROR = 1;

const int CANT_MIN_BUENAS_PRACTICAS = 4;
#define BUENA_PRACTICA_FUNDAMENTAL "Modularizacion"


/* Pre condiciones: 'buenas_practicas_utilizadas' tiene que contener un string en cada fila (cada fila debe terminar con '\O').
                    'cantidad_buenas_practicas_utilizadas' debe ser menor a MAX_BUENAS_PRACTICAS y mayor o igual a 0.
 * Post condiciones: devuelve true si cumple la buena práctica fundamental y false en caso contrario.
 */
bool cumple_bp_fundamental(char buenas_practicas_utilizadas[MAX_BUENAS_PRACTICAS][MAX_NOMBRE_BUENA_PRACTICA], int cantidad_buenas_practicas_utilizadas) {
    int i = 0;
    bool encontrada = false;

    while(!encontrada && i < cantidad_buenas_practicas_utilizadas) {
        if (strcmp(buenas_practicas_utilizadas[i], BUENA_PRACTICA_FUNDAMENTAL) == 0) {
            encontrada = true;
        } else {
            i++;
        }
    }

    return encontrada;
}


/* Pre condiciones: El campo 'buenas_practicas_utilizadas' del entrega_t tiene que contener un string en cada fila (cada fila debe terminar con '\O').
                    El campo 'cantidad_buenas_practicas_utilizadas' debe ser menor a MAX_BUENAS_PRACTICAS y mayor o igual a 0.
 * Post condiciones: Devuelve true si la entrega está aprobada y false en caso contrario.
 */
bool entrega_aprobada(entrega_t entrega) {
    return entrega.pasan_todas_pruebas && entrega.cantidad_buenas_practicas_utilizadas >= CANT_MIN_BUENAS_PRACTICAS && cumple_bp_fundamental(entrega.buenas_practicas_utilizadas, entrega.cantidad_buenas_practicas_utilizadas);
}


/* Pre condiciones: 'algotron' debe apuntar a una cola creada con algotron_crear.
                    Además 'algotron' debe ser distinto de NULL.
 * Post condiciones: Devuelve el porcentaje de entregas aprobadas.
 */

int porcentaje_tps_aprobados(algotron_t* algotron) {
    int total = 0;
    int aprobados = 0;

    while(!algotron_esta_vacio(algotron)) {
        // 1) miramos el primer elemento
        entrega_t entrega = algotron_primero(algotron);
        
        // 2) desencolamos el elemento
        bool desencolo = algotron_desencolar(algotron);
        if(desencolo) {
            // 3) aumentamos el contador total si desencoló
            total++;
        }

        // 4) nos fijamos si apruebó o no
        if(entrega_aprobada(entrega)) {
            // 5) aumentamos el contador de aprobados
            aprobados++;
        }
    }

    return (aprobados * 100) /total;
}
