#!/bin/bash
gcc ejercicio_simple.c pila.o -o donas -std=c99 -Wall -Wconversion -Werror -lm
