#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pila.h"

#define FIN "FIN"
#define MAX_CHAR_SABOR_DONA 100

/* 
 * Pre: el puntero a la pila de donas apunta a una pila creada correctamente
 * Post: Se cargan a la pila las donas ingresadas por el usuario hasta escribir "FIN"
 */
void apilar_donas(Pila* donas) {
    char buffer[MAX_CHAR_SABOR_DONA];

    printf("Ingresá sabores de donas para Homero (escribí '%s' para terminar):\n", FIN);

    scanf("%s", buffer);
    while (strcmp(buffer, FIN) != 0) {
        apilar(donas, buffer);
        scanf("%s", buffer);
    }

    printf("\nHomero ha apilado %d donas.\n\n", donas->tope);
}

/*
 * Pre: la pila fue creada correctamente
 * Post: Homero come todas las donas y la pila queda vacía
 */
void homero_come_donas(Pila* donas) {
    while (!esta_vacia(donas)) {
        char* dona = desapilar(donas);
        printf("Homero se come: %s\n", dona);
        free(dona);   // liberar el string
    }
}

int main() {
    printf("=== Pila de Donas de Homero Simpson ===\n\n");

    Pila* donas = crear();

    printf("Homero está apilando donas...\n");
    apilar_donas(donas);

    printf("Homero empieza a comer donas...\n\n");
    homero_come_donas(donas);

    printf("\nHomero se quedó sin donas :(\n");

    destruir(donas);
    return 0;
}
