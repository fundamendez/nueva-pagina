#ifndef PILA_H
#define PILA_H

#include <stdbool.h>

typedef struct pila {
    char** datos;     // Arreglo dinámico de strings
    int tope;         // Cantidad de elementos en la pila
    int capacidad;    // Capacidad máxima actual
} Pila;

/*
 * Pre: -
 * Post: Devuelve un puntero a una pila vacía, con memoria reservada.
 *       Si no se puede reservar memoria, devuelve NULL.
 */
Pila* crear();

/*
 * Pre: p debe ser un puntero válido a una pila creada previamente.
 * Post: Devuelve true si la pila no contiene elementos; false en caso contrario.
 */
bool esta_vacia(Pila* p);

/*
 * Pre: p debe ser un puntero válido a una pila.
 * Post: Si la pila está vacía devuelve NULL.
 *       De lo contrario devuelve un puntero al string del tope sin modificar la pila.
 *       El string NO debe ser liberado por el usuario.
 */
char* tope(Pila* p);

/*
 * Pre: p debe ser un puntero válido a una pila.
 *      str debe ser un puntero válido a un string terminado en '\0'.
 * Post: Apila una copia del string.
 *       Si tuvo éxito devuelve true.
 *       Si falla la reserva de memoria devuelve false y la pila queda sin cambios.
 */
bool apilar(Pila* p, const char* str);

/*
 * Pre: p debe ser un puntero válido a una pila.
 * Post: Si la pila está vacía devuelve NULL.
 *       Si no, remueve el elemento del tope y devuelve una copia del string desapilado.
 *       El usuario es responsable de hacer free al string devuelto.
 */
char* desapilar(Pila* p);

/*
 * Pre: p debe ser un puntero válido a una pila creada con crear().
 * Post: Libera toda la memoria asociada a la pila:
 *       - Los strings almacenados
 *       - El arreglo dinámico
 *       - La estructura misma
 */
void destruir(Pila* p);

#endif
