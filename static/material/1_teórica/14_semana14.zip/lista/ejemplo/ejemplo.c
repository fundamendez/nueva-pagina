#include <stdio.h>
#include "lista.h"

int main() {

    // 1. Crear playlist
    lista_t* playlist = lista_crear();

    // 2. Verificar que está vacía
    if (lista_esta_vacia(playlist))
        printf("La playlist está vacía.\n");

    // 3. Agregar canciones al final
    lista_insertar_final(playlist, "Song A");
    lista_insertar_final(playlist, "Song B");
    lista_insertar_final(playlist, "Song C");

    // 4. Agregar una canción al inicio
    lista_insertar_primero(playlist, "Intro Track");

    // 5. Insertar en una posición específica
    //    (posición 2 → entre Intro Track y Song A)
    lista_insertar_en_pos(playlist, "Nueva Canción", 2);

    // printf("Reproduciendo playlist completa antes de eliminar:\n");

    lista_iter_t* iter = lista_iter_crear(playlist);
    while (!lista_iter_al_final(iter)) {
        const char* actual = lista_iter_ver_actual(iter);
        printf(" - %s\n", actual);
        lista_iter_avanzar(iter);
    }

    // 6. Mostrar cuántas canciones hay
    printf("La playlist tiene %zu canciones.\n",
           lista_largo(playlist));

    // 7. Obtener una canción (por ejemplo la de posición 3)
    const char* track = lista_obtener(playlist, 3);
    printf("La canción en la posición 3 es: %s\n", track);

    // 8. Buscar una canción por nombre
    size_t pos = lista_buscar(playlist, "Song B");
    if (pos != (size_t)-1)
        printf("Song B está en la posición %zu.\n", pos);

    // 9. Eliminar una canción específica
    lista_eliminar(playlist, 1);   // elimina la canción en la posición 1

    // 10. Recorrer la playlist completa
    printf("Reproduciendo playlist completa:\n");

    iter = lista_iter_crear(playlist);
    while (!lista_iter_al_final(iter)) {
        const char* actual = lista_iter_ver_actual(iter);
        printf(" - %s\n", actual);
        lista_iter_avanzar(iter);
    }
    lista_iter_destruir(iter);

    // 11. Destruir la playlist
    lista_destruir(playlist);

    return 0;
}
