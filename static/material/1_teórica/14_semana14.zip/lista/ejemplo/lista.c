#include "lista.h"
#include <stdlib.h>

/*** Función auxiliar para crear nodo ***/
static nodo_t* nodo_crear(void* dato) {
    nodo_t* nodo = malloc(sizeof(nodo_t));
    if (!nodo) return NULL;
    nodo->dato = dato;
    nodo->siguiente = NULL;
    return nodo;
}

/*** Primitivas de la lista ***/

lista_t* lista_crear(void) {
    lista_t* lista = malloc(sizeof(lista_t));
    if (!lista) return NULL;

    lista->head = NULL;
    lista->largo = 0;
    return lista;
}

bool lista_esta_vacia(const lista_t* lista) {
    return lista->head == NULL;
}

bool lista_insertar_primero(lista_t* lista, void* dato) {
    nodo_t* nuevo = nodo_crear(dato);
    if (!nuevo) return false;

    nuevo->siguiente = lista->head;
    lista->head = nuevo;
    lista->largo++;
    return true;
}

bool lista_insertar_final(lista_t* lista, void* dato) {
    nodo_t* nuevo = nodo_crear(dato);
    if (!nuevo) return false;

    // Si la lista está vacía
    if (!lista->head) {
        lista->head = nuevo;
        lista->largo++;
        return true;
    }

    nodo_t* actual = lista->head;
    while (actual->siguiente)
        actual = actual->siguiente;

    actual->siguiente = nuevo;
    lista->largo++;
    return true;
}

bool lista_insertar_en_pos(lista_t* lista, void* dato, size_t pos) {
    if (pos > lista->largo) return false;

    if (pos == 0)
        return lista_insertar_primero(lista, dato);

    nodo_t* nuevo = nodo_crear(dato);
    if (!nuevo) return false;

    nodo_t* actual = lista->head;
    for (size_t i = 0; i < pos - 1; i++)
        actual = actual->siguiente;

    nuevo->siguiente = actual->siguiente;
    actual->siguiente = nuevo;
    lista->largo++;
    return true;
}

void* lista_obtener(const lista_t* lista, size_t pos) {
    if (pos >= lista->largo) return NULL;

    nodo_t* actual = lista->head;
    for (size_t i = 0; i < pos; i++)
        actual = actual->siguiente;

    return actual->dato;
}

bool lista_eliminar(lista_t* lista, size_t pos) {
    if (pos >= lista->largo) return false;

    nodo_t* borrar;

    // Caso: eliminar primero
    if (pos == 0) {
        borrar = lista->head;
        lista->head = borrar->siguiente;
        free(borrar);
        lista->largo--;
        return true;
    }

    // Buscar nodo anterior
    nodo_t* actual = lista->head;
    for (size_t i = 0; i < pos - 1; i++)
        actual = actual->siguiente;

    borrar = actual->siguiente;
    actual->siguiente = borrar->siguiente;

    free(borrar);
    lista->largo--;
    return true;
}

size_t lista_buscar(const lista_t* lista, void* dato) {
    nodo_t* actual = lista->head;
    size_t pos = 0;

    while (actual) {
        if (actual->dato == dato)
            return (size_t)pos;
        actual = actual->siguiente;
        pos++;
    }

    return -1;
}

size_t lista_largo(const lista_t* lista) {
    return lista->largo;
}

void lista_destruir(lista_t* lista) {
    nodo_t* actual = lista->head;

    while (actual) {
        nodo_t* prox = actual->siguiente;
        free(actual);
        actual = prox;
    }

    free(lista);
}

/*** Iterador externo ***/

lista_iter_t* lista_iter_crear(lista_t* lista) {
    lista_iter_t* iter = malloc(sizeof(lista_iter_t));
    if (!iter) return NULL;

    iter->lista = lista;
    iter->actual = lista->head;
    iter->anterior = NULL;
    return iter;
}

bool lista_iter_avanzar(lista_iter_t* iter) {
    if (lista_iter_al_final(iter)) return false;
    iter->anterior = iter->actual;
    iter->actual = iter->actual->siguiente;
    return true;
}

void* lista_iter_ver_actual(const lista_iter_t* iter) {
    if (lista_iter_al_final(iter)) return NULL;
    return iter->actual->dato;
}

bool lista_iter_al_final(const lista_iter_t* iter) {
    return iter->actual == NULL;
}

void lista_iter_destruir(lista_iter_t* iter) {
    free(iter);
}
