#ifndef LISTA_H
#define LISTA_H

#include <stdbool.h>
#include <stddef.h>

/*** Estructuras del TDA ***/

typedef struct nodo {
    void* dato;
    struct nodo* siguiente;
} nodo_t;

typedef struct lista {
    nodo_t* head;
    size_t largo;
} lista_t;

/*** Primitivas básicas ***/

// Crear una lista vacía
lista_t* lista_crear(void);

// Retorna true si la lista no tiene elementos
bool lista_esta_vacia(const lista_t* lista);

// Insertar al inicio
bool lista_insertar_primero(lista_t* lista, void* dato);

// Insertar al final
bool lista_insertar_final(lista_t* lista, void* dato);

// Insertar en una posición específica (0 <= pos <= largo)
bool lista_insertar_en_pos(lista_t* lista, void* dato, size_t pos);

// Obtener un elemento por posición
void* lista_obtener(const lista_t* lista, size_t pos);

// Eliminar un elemento por posición
bool lista_eliminar(lista_t* lista, size_t pos);

// Buscar un dato (comparación por puntero, no por contenido)
size_t lista_buscar(const lista_t* lista, void* dato);

// Largo de la lista
size_t lista_largo(const lista_t* lista);

// Destruir la lista
void lista_destruir(lista_t* lista);

/*** Iterador externo ***/

typedef struct lista_iter {
    nodo_t* actual;
    nodo_t* anterior;
    lista_t* lista;
} lista_iter_t;

lista_iter_t* lista_iter_crear(lista_t* lista);
bool lista_iter_avanzar(lista_iter_t* iter);
void* lista_iter_ver_actual(const lista_iter_t* iter);
bool lista_iter_al_final(const lista_iter_t* iter);
void lista_iter_destruir(lista_iter_t* iter);

#endif        // LISTA_H
